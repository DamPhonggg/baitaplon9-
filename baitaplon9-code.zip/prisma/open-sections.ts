/**
 * Mở lớp học phần cho tất cả HP trong CTĐT (theo học kỳ dự kiến).
 * Chạy: npm run db:open-sections
 */
import { PrismaClient } from "@prisma/client";
import { ensureOpenSectionsForCurriculum } from "../src/lib/open-sections";

const prisma = new PrismaClient();

async function main() {
  const result = await ensureOpenSectionsForCurriculum();
  console.log(`Mở lớp: ${result.created} lớp mới, ${result.skipped} đã có sẵn / ${result.total} HP trong CTĐT`);
}

main().catch(console.error).finally(() => prisma.$disconnect());

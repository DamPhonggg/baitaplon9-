export type CourseCategory = "THE_CHAT" | "KIEN_THUC" | "CHUYEN_NGANH";

export type CurriculumItem = {
  orderIndex: number;
  code: string;
  name: string;
  knowledgeBlock: string;
  courseCategory: CourseCategory;
  credits: number;
  tuitionCredits: number;
  prerequisites?: string;
  /** Format: Y{1-4}_HK{1|2|3} */
  plannedSemester: string;
};

export const CATEGORY_LABELS: Record<CourseCategory, string> = {
  THE_CHAT: "Thể chất",
  KIEN_THUC: "Kiến thức",
  CHUYEN_NGANH: "Chuyên ngành",
};

export const SEMESTER_LABELS: Record<string, string> = {
  Y1_HK1: "Năm 1 — Học kỳ 1",
  Y1_HK2: "Năm 1 — Học kỳ 2",
  Y1_HK3: "Năm 1 — Học kỳ hè",
  Y2_HK1: "Năm 2 — Học kỳ 1",
  Y2_HK2: "Năm 2 — Học kỳ 2",
  Y2_HK3: "Năm 2 — Học kỳ hè",
  Y3_HK1: "Năm 3 — Học kỳ 1",
  Y3_HK2: "Năm 3 — Học kỳ 2",
  Y3_HK3: "Năm 3 — Học kỳ hè",
  Y4_HK1: "Năm 4 — Học kỳ 1",
  Y4_HK2: "Năm 4 — Học kỳ 2",
  Y4_HK3: "Năm 4 — Học kỳ hè",
};

export const SEMESTER_ORDER = Object.keys(SEMESTER_LABELS);

export const MIN_CREDITS_PER_SEMESTER = 8;
export const MAX_CREDITS_PER_SEMESTER = 16;

/** Map khối kiến thức → nhóm CTĐT */
export function categoryFromBlock(block: string): CourseCategory {
  if (block.startsWith("D") || block.startsWith("E")) return "CHUYEN_NGANH";
  if (block === "TC" || block.startsWith("F1") || block.startsWith("F2")) return "THE_CHAT";
  return "KIEN_THUC";
}

/** Chuyển Y1_HK1 → 2023_2024_HK1 (theo năm nhập học 2023) */
export function plannedToExpected(planned: string, entryYear = 2023): string {
  const match = planned.match(/^Y(\d)_HK(\d)$/);
  if (!match) return planned;
  const yearOffset = parseInt(match[1]) - 1;
  const hk = match[2];
  const startYear = entryYear + yearOffset;
  return `${startYear}_${startYear + 1}_HK${hk}`;
}

export const CURRICULUM_CSE: CurriculumItem[] = [
  // ── NĂM 1 HK1 (14 TC) ──
  { orderIndex: 1, code: "FFS702001", name: "Pháp luật đại cương", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 2, tuitionCredits: 2, plannedSemester: "Y1_HK1" },
  { orderIndex: 2, code: "FEL702075", name: "Tiếng anh cơ bản 1", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 2, tuitionCredits: 3, plannedSemester: "Y1_HK1" },
  { orderIndex: 3, code: "FFS703013", name: "Vật lý 1", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3.25, plannedSemester: "Y1_HK2" },
  { orderIndex: 4, code: "FFS703007", name: "Đại số tuyến tính", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3, plannedSemester: "Y1_HK2" },
  { orderIndex: 5, code: "FEL703076", name: "Tiếng anh cơ bản 2", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 4.5, prerequisites: "Học trước(Tiếng anh cơ bản 1)", plannedSemester: "Y1_HK2" },
  { orderIndex: 6, code: "FFS703080", name: "Giải tích 1", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3, plannedSemester: "Y1_HK2" },
  { orderIndex: 7, code: "FEL703077", name: "Tiếng anh cơ bản 3", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 4.5, prerequisites: "Học trước(Tiếng anh cơ bản 2)", plannedSemester: "Y1_HK3" },
  { orderIndex: 8, code: "FFS703014", name: "Vật lý 2", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3.25, prerequisites: "Tiên quyết(Vật lý 1)", plannedSemester: "Y2_HK1" },
  { orderIndex: 9, code: "FFS703064", name: "Giải tích 2", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3, prerequisites: "Tiên quyết(Giải tích 1)", plannedSemester: "Y2_HK1" },
  { orderIndex: 10, code: "FEL703078", name: "Tiếng anh nâng cao 1", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 4.5, prerequisites: "Học trước(Tiếng anh cơ bản 3)", plannedSemester: "Y2_HK2" },
  { orderIndex: 11, code: "FFS703010", name: "Lý thuyết xác suất thống kê", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3, plannedSemester: "Y2_HK2" },
  { orderIndex: 12, code: "FEL703079", name: "Tiếng anh nâng cao 2", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 4.5, prerequisites: "Học trước(Tiếng anh nâng cao 1)", plannedSemester: "Y2_HK3" },
  { orderIndex: 13, code: "FEL702080", name: "Tiếng anh nâng cao 3", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 2, tuitionCredits: 3, prerequisites: "Học trước(Tiếng anh nâng cao 2)", plannedSemester: "Y2_HK3" },
  { orderIndex: 14, code: "FFS703002", name: "Triết học Mác - Lênin", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3, plannedSemester: "Y3_HK1" },
  { orderIndex: 15, code: "FFS702003", name: "Kinh tế chính trị Mác - Lênin", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 2, tuitionCredits: 2, prerequisites: "Học trước(Triết học Mác - Lênin)", plannedSemester: "Y3_HK1" },
  { orderIndex: 16, code: "FFS702004", name: "Chủ nghĩa xã hội khoa học", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 2, tuitionCredits: 2, prerequisites: "Học trước(Kinh tế chính trị Mác - Lênin)", plannedSemester: "Y3_HK2" },
  { orderIndex: 17, code: "FFS702005", name: "Lịch sử Đảng cộng sản Việt Nam", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 2, tuitionCredits: 2, prerequisites: "Học trước(Chủ nghĩa xã hội khoa học)", plannedSemester: "Y4_HK1" },
  { orderIndex: 18, code: "FFS702006", name: "Tư tưởng Hồ Chí Minh", knowledgeBlock: "A1", courseCategory: "KIEN_THUC", credits: 2, tuitionCredits: 2, prerequisites: "Học trước(Lịch sử Đảng cộng sản Việt Nam)", plannedSemester: "Y4_HK2" },

  // ── Thể chất ──
  { orderIndex: 51, code: "GDTC702001", name: "Giáo dục thể chất 1", knowledgeBlock: "TC", courseCategory: "THE_CHAT", credits: 2, tuitionCredits: 2, plannedSemester: "Y1_HK1" },
  { orderIndex: 52, code: "GDTC702002", name: "Giáo dục thể chất 2", knowledgeBlock: "TC", courseCategory: "THE_CHAT", credits: 2, tuitionCredits: 2, prerequisites: "Học trước(Giáo dục thể chất 1)", plannedSemester: "Y1_HK3" },

  // ── Kiến thức cơ sở ngành (B1) ──
  { orderIndex: 19, code: "CSE703107", name: "Cơ sở lập trình", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3.5, plannedSemester: "Y1_HK1" },
  { orderIndex: 20, code: "CSE703029", name: "Lập trình hướng đối tượng", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3.5, prerequisites: "Tiên quyết(Cơ sở lập trình)", plannedSemester: "Y1_HK2" },
  { orderIndex: 21, code: "CSE703024", name: "Toán rời rạc", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3, plannedSemester: "Y1_HK1" },
  { orderIndex: 22, code: "CSE703006", name: "Cấu trúc dữ liệu và thuật toán", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3.5, prerequisites: "Tiên quyết(Cơ sở lập trình)", plannedSemester: "Y1_HK3" },
  { orderIndex: 23, code: "CSE703008", name: "Cơ sở dữ liệu", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3.5, plannedSemester: "Y2_HK1" },
  { orderIndex: 24, code: "CSE703023", name: "Kiến trúc máy tính", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3.5, plannedSemester: "Y2_HK1" },
  { orderIndex: 25, code: "CSE702017", name: "Hệ điều hành", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 2, tuitionCredits: 2.25, plannedSemester: "Y2_HK2" },
  { orderIndex: 26, code: "CSE702036", name: "Mạng máy tính", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 2, tuitionCredits: 2, plannedSemester: "Y2_HK2" },
  { orderIndex: 27, code: "CSE703057", name: "Tối ưu hóa", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3, prerequisites: "Tiên quyết(Đại số tuyến tính, Giải tích 2)", plannedSemester: "Y2_HK3" },
  { orderIndex: 28, code: "CSE703016", name: "Giao diện người máy", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3.5, prerequisites: "Tiên quyết(Giới thiệu ngành)", plannedSemester: "Y3_HK1" },
  { orderIndex: 29, code: "CSE703052", name: "Thuật toán ứng dụng", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3.5, prerequisites: "Học trước(Toán rời rạc), Tiên quyết(Cấu trúc dữ liệu và thuật toán)", plannedSemester: "Y3_HK1" },
  { orderIndex: 33, code: "CSE703031", name: "Phân tích thiết kế hệ thống", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3.5, prerequisites: "Tiên quyết(Cơ sở dữ liệu)", plannedSemester: "Y2_HK3" },
  { orderIndex: 34, code: "CSE703045", name: "An toàn thông tin", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3.5, prerequisites: "Tiên quyết(Mạng máy tính)", plannedSemester: "Y3_HK2" },
  { orderIndex: 35, code: "CSE702028", name: "Trí tuệ nhân tạo", knowledgeBlock: "B1", courseCategory: "KIEN_THUC", credits: 2, tuitionCredits: 2.5, prerequisites: "Học trước(Toán rời rạc)", plannedSemester: "Y3_HK2" },

  // ── Kiến thức bổ trợ (C1, C2) ──
  { orderIndex: 30, code: "FBE702001", name: "Quản trị học", knowledgeBlock: "C1", courseCategory: "KIEN_THUC", credits: 2, tuitionCredits: 2, plannedSemester: "Y2_HK2" },
  { orderIndex: 31, code: "FBE703044", name: "Kinh tế vi mô", knowledgeBlock: "C1", courseCategory: "KIEN_THUC", credits: 3, tuitionCredits: 3, plannedSemester: "Y4_HK1" },
  { orderIndex: 32, code: "FTS702003", name: "Kỹ năng đàm phán, thương lượng", knowledgeBlock: "C2", courseCategory: "KIEN_THUC", credits: 2, tuitionCredits: 2.5, plannedSemester: "Y3_HK2" },

  // ── Chuyên ngành (D1, D2.1) ──
  { orderIndex: 36, code: "CSE702106", name: "Giới thiệu ngành", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 2, tuitionCredits: 4, plannedSemester: "Y1_HK1" },
  { orderIndex: 37, code: "CSE703064", name: "Xây dựng ứng dụng web", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 3.5, prerequisites: "Học trước(Giới thiệu ngành)", plannedSemester: "Y2_HK1" },
  { orderIndex: 38, code: "CSE703055", name: "Phân tích và thiết kế phần mềm", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 3.5, prerequisites: "Tiên quyết(Lập trình hướng đối tượng)", plannedSemester: "Y2_HK2" },
  { orderIndex: 39, code: "CSE702115", name: "Các hệ thống thông minh", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 2, tuitionCredits: 2.5, prerequisites: "Học trước(Cấu trúc dữ liệu và thuật toán)", plannedSemester: "Y3_HK1" },
  { orderIndex: 40, code: "CSE703094", name: "Phát triển ứng dụng di động", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 3.5, prerequisites: "Học trước(Cơ sở lập trình), Tiên quyết(Lập trình hướng đối tượng)", plannedSemester: "Y3_HK1" },
  { orderIndex: 41, code: "CSE703095", name: "Kiểm thử phần mềm", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 3.5, prerequisites: "Tiên quyết(Phân tích và thiết kế phần mềm)", plannedSemester: "Y3_HK2" },
  { orderIndex: 42, code: "CSE702042", name: "Quản lý dự án phần mềm", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 2, tuitionCredits: 2.5, prerequisites: "Học trước(Phân tích và thiết kế phần mềm)", plannedSemester: "Y4_HK2" },
  { orderIndex: 43, code: "CSE703096", name: "Đồ án chuyên ngành", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 6, prerequisites: "Tiên quyết(Phân tích và thiết kế phần mềm, Cơ sở dữ liệu)", plannedSemester: "Y3_HK3" },
  { orderIndex: 44, code: "CSE702034", name: "Lập trình web nâng cao", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 2, tuitionCredits: 2.5, prerequisites: "Học trước(Xây dựng ứng dụng web)", plannedSemester: "Y3_HK3" },
  { orderIndex: 45, code: "CSE702035", name: "DevOps cơ bản", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 2, tuitionCredits: 2.5, plannedSemester: "Y4_HK1" },
  { orderIndex: 46, code: "CSE702037", name: "Big Data cơ bản", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 2, tuitionCredits: 2.5, prerequisites: "Tiên quyết(Cơ sở dữ liệu)", plannedSemester: "Y4_HK1" },
  { orderIndex: 47, code: "CSE702038", name: "Cloud Computing", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 2, tuitionCredits: 2.5, plannedSemester: "Y3_HK3" },
  { orderIndex: 48, code: "CSE702039", name: "Blockchain cơ bản", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 2, tuitionCredits: 2.5, plannedSemester: "Y4_HK2" },
  { orderIndex: 49, code: "CSE702033", name: "Lập trình trò chơi", knowledgeBlock: "D2.1", courseCategory: "CHUYEN_NGANH", credits: 2, tuitionCredits: 2.5, prerequisites: "Học trước(Phát triển ứng dụng di động)", plannedSemester: "Y3_HK3" },
  { orderIndex: 50, code: "CSE702040", name: "Thực tập doanh nghiệp", knowledgeBlock: "D1", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 6, prerequisites: "Tiên quyết(Đồ án chuyên ngành)", plannedSemester: "Y4_HK2" },

  // ── Chuyên ngành tự chọn nâng cao (D2.2) — Năm 4 HK1 ──
  { orderIndex: 53, code: "CSE703112", name: "Bảo mật hệ thống", knowledgeBlock: "D2.2", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 3.5, prerequisites: "Học trước(Mạng máy tính)", plannedSemester: "Y4_HK1" },
  { orderIndex: 54, code: "CSE703099", name: "Các hệ nhúng", knowledgeBlock: "D2.2", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 3.5, prerequisites: "Học trước(Kiến trúc máy tính), Tiên quyết(Cơ sở lập trình)", plannedSemester: "Y4_HK1" },
  { orderIndex: 55, code: "CSE703097", name: "Công nghệ chuỗi khối", knowledgeBlock: "D2.2", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 3.5, prerequisites: "Học trước(Mạng máy tính)", plannedSemester: "Y4_HK1" },
  { orderIndex: 56, code: "CSE703098", name: "Lập trình phân tán", knowledgeBlock: "D2.2", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 3.5, prerequisites: "Học trước(Lập trình hướng đối tượng)", plannedSemester: "Y4_HK1" },
  { orderIndex: 57, code: "CSE703032", name: "Lập trình song song", knowledgeBlock: "D2.2", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 3.5, prerequisites: "Học trước(Lập trình hướng đối tượng)", plannedSemester: "Y4_HK1" },
  { orderIndex: 58, code: "CSE703113", name: "Phương pháp số cho học máy", knowledgeBlock: "D2.2", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 3.5, prerequisites: "Tiên quyết(Tối ưu hóa)", plannedSemester: "Y4_HK1" },
  { orderIndex: 59, code: "CSE703102", name: "Thương mại điện tử", knowledgeBlock: "D2.2", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 3.5, prerequisites: "Học trước(Xây dựng ứng dụng web)", plannedSemester: "Y4_HK1" },
  { orderIndex: 60, code: "CSE703054", name: "Tích hợp và phân tích dữ liệu lớn", knowledgeBlock: "D2.2", courseCategory: "CHUYEN_NGANH", credits: 3, tuitionCredits: 3.5, prerequisites: "Học trước(Cấu trúc dữ liệu và thuật toán), Tiên quyết(Cơ sở dữ liệu)", plannedSemester: "Y4_HK1" },

  // ── Thực tập & đồ án tốt nghiệp (E1, E2) ──
  { orderIndex: 61, code: "CSE704067", name: "Thực tập tốt nghiệp", knowledgeBlock: "E1", courseCategory: "CHUYEN_NGANH", credits: 4, tuitionCredits: 10, plannedSemester: "Y4_HK1" },
  { orderIndex: 62, code: "CSE710111", name: "Đồ án tốt nghiệp", knowledgeBlock: "E2", courseCategory: "CHUYEN_NGANH", credits: 10, tuitionCredits: 25, prerequisites: "Tiên quyết(Đồ án chuyên ngành)", plannedSemester: "Y4_HK1" },

  // ── GDQP, thể dục tự chọn, ngoại ngữ bổ trợ (F1–F3) ──
  { orderIndex: 63, code: "FFS708066", name: "Giáo dục quốc phòng - an ninh", knowledgeBlock: "F1", courseCategory: "THE_CHAT", credits: 8, tuitionCredits: 8, plannedSemester: "Y1_HK2" },
  { orderIndex: 64, code: "FFS701072", name: "Chạy 1", knowledgeBlock: "F2.1", courseCategory: "THE_CHAT", credits: 1, tuitionCredits: 1.5, plannedSemester: "Y1_HK1" },
  { orderIndex: 65, code: "FFS701073", name: "Aerobic", knowledgeBlock: "F2.2", courseCategory: "THE_CHAT", credits: 1, tuitionCredits: 1.5, plannedSemester: "Y1_HK1" },
  { orderIndex: 66, code: "FFS701068", name: "Bóng chuyền", knowledgeBlock: "F2.2", courseCategory: "THE_CHAT", credits: 1, tuitionCredits: 1.5, plannedSemester: "Y1_HK1" },
  { orderIndex: 67, code: "FFS701069", name: "Bóng đá", knowledgeBlock: "F2.3", courseCategory: "THE_CHAT", credits: 1, tuitionCredits: 1.5, plannedSemester: "Y1_HK1" },
  { orderIndex: 68, code: "FFS701067", name: "Bóng rổ", knowledgeBlock: "F2.3", courseCategory: "THE_CHAT", credits: 1, tuitionCredits: 1.5, plannedSemester: "Y1_HK1" },
  { orderIndex: 69, code: "FFS701070", name: "Cầu lông", knowledgeBlock: "F2.3", courseCategory: "THE_CHAT", credits: 1, tuitionCredits: 1.5, plannedSemester: "Y1_HK1" },
  { orderIndex: 70, code: "FEL704000", name: "Tiếng Anh bổ trợ", knowledgeBlock: "F3", courseCategory: "KIEN_THUC", credits: 4, tuitionCredits: 4, plannedSemester: "Y1_HK2" },
];

export const KNOWLEDGE_BLOCKS = [
  "A1", "B1", "C1", "C2", "D1", "D2.1", "D2.2", "E1", "E2",
  "F1", "F2.1", "F2.2", "F2.3", "F3", "TC",
] as const;

export type SemesterSummary = {
  key: string;
  label: string;
  credits: number;
  courses: CurriculumItem[];
  byCategory: Record<CourseCategory, number>;
  valid: boolean;
};

export function buildSemesterPlan(courses: CurriculumItem[] = CURRICULUM_CSE): SemesterSummary[] {
  return SEMESTER_ORDER.map((key) => {
    const semesterCourses = courses.filter((c) => c.plannedSemester === key);
    const credits = semesterCourses.reduce((s, c) => s + c.credits, 0);
    const byCategory: Record<CourseCategory, number> = {
      THE_CHAT: 0,
      KIEN_THUC: 0,
      CHUYEN_NGANH: 0,
    };
    for (const c of semesterCourses) {
      byCategory[c.courseCategory] += c.credits;
    }
    return {
      key,
      label: SEMESTER_LABELS[key],
      credits,
      courses: semesterCourses,
      byCategory,
      valid: credits >= MIN_CREDITS_PER_SEMESTER && credits <= MAX_CREDITS_PER_SEMESTER,
    };
  });
}

export function buildCategorySummary(courses: CurriculumItem[] = CURRICULUM_CSE) {
  const groups: Record<CourseCategory, { count: number; credits: number }> = {
    THE_CHAT: { count: 0, credits: 0 },
    KIEN_THUC: { count: 0, credits: 0 },
    CHUYEN_NGANH: { count: 0, credits: 0 },
  };
  for (const c of courses) {
    groups[c.courseCategory].count++;
    groups[c.courseCategory].credits += c.credits;
  }
  return groups;
}

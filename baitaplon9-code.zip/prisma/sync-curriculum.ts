import { PrismaClient } from "@prisma/client";
import { syncCurriculumFromSource } from "../src/lib/sync-curriculum";

const prisma = new PrismaClient();

async function main() {
  const result = await syncCurriculumFromSource();
  console.log(`Đồng bộ CTĐT: ${result.total} HP (${result.created} mới, ${result.updated} cập nhật), ${result.categories} danh mục khối KT`);
}

main().catch(console.error).finally(() => prisma.$disconnect());

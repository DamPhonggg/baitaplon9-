/**
 * Xóa toàn bộ lịch sử đăng ký của sinh viên (giữ CTĐT, lớp học phần, điểm đã hoàn thành).
 * Chạy: npm run db:clear-enrollments
 */
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const payments = await prisma.tuitionPayment.deleteMany();
  const invoices = await prisma.tuitionInvoice.deleteMany();
  const enrollments = await prisma.enrollment.deleteMany();

  const resetPlans = await prisma.studentStudyPlan.updateMany({
    where: { status: "IN_PROGRESS" },
    data: { status: "PLANNED", actualSemester: null },
  });

  console.log(`Đã xóa ${enrollments.count} đăng ký`);
  console.log(`Đã xóa ${invoices.count} hóa đơn học phí, ${payments.count} thanh toán`);
  console.log(`Đã reset ${resetPlans.count} môn IN_PROGRESS → PLANNED`);
}

main().catch(console.error).finally(() => prisma.$disconnect());

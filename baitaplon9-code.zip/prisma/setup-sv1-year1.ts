/**
 * Thiết lập SV001 đã hoàn thành 3 kỳ Năm 1 (13 TC/kỳ, ĐHP 6.5).
 * Chạy: npm run db:setup-sv1-y1
 */
import { PrismaClient } from "@prisma/client";
import { setupSv1Year1Completed, SV1_YEAR1_SEMESTERS } from "../src/lib/demo-student-year1";

const prisma = new PrismaClient();

async function main() {
  const result = await setupSv1Year1Completed();
  console.log(`Đã thiết lập ${result.studentCode} (${result.studentEmail}):`);
  console.log(`  • ${result.enrollmentCount} môn đã hoàn thành (${result.creditTotal} tín chỉ)`);
  console.log(`  • GPA: ${result.gpa}`);
  for (const [sem, codes] of Object.entries(SV1_YEAR1_SEMESTERS)) {
    console.log(`  • ${sem}: ${codes.join(", ")}`);
  }
}

main().catch(console.error).finally(() => prisma.$disconnect());

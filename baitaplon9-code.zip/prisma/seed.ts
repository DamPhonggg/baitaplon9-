import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";
import { CURRICULUM_CSE, plannedToExpected } from "./curriculum-data";

const prisma = new PrismaClient();

const CATEGORIES = [
  { code: "A1", name: "Giáo dục đại cương", groupType: "KIEN_THUC", minCredits: 45, description: "Môn đại cương, chính trị, ngoại ngữ" },
  { code: "B1", name: "Cơ sở ngành", groupType: "KIEN_THUC", minCredits: 40, description: "Kiến thức cơ sở CNTT" },
  { code: "C1", name: "Bổ trợ kinh tế - xã hội", groupType: "KIEN_THUC", minCredits: 5, description: "Quản trị, kinh tế" },
  { code: "C2", name: "Kỹ năng mềm", groupType: "KIEN_THUC", minCredits: 2, description: "Kỹ năng đàm phán" },
  { code: "D1", name: "Chuyên ngành cốt lõi", groupType: "CHUYEN_NGANH", minCredits: 30, description: "Môn chuyên ngành chính" },
  { code: "D2.1", name: "Chuyên ngành tự chọn", groupType: "CHUYEN_NGANH", minCredits: 2, description: "Môn tự chọn" },
  { code: "D2.2", name: "Chuyên ngành tự chọn nâng cao", groupType: "CHUYEN_NGANH", minCredits: 3, description: "Môn tự chọn chuyên sâu" },
  { code: "E1", name: "Thực tập tốt nghiệp", groupType: "CHUYEN_NGANH", minCredits: 4, description: "Thực tập tốt nghiệp" },
  { code: "E2", name: "Đồ án tốt nghiệp", groupType: "CHUYEN_NGANH", minCredits: 10, description: "ĐATN" },
  { code: "F1", name: "Giáo dục quốc phòng - an ninh", groupType: "THE_CHAT", minCredits: 8, description: "GDQP-AN" },
  { code: "F2.1", name: "Thể dục tự chọn — Chạy", groupType: "THE_CHAT", minCredits: 1, description: "Chạy 1" },
  { code: "F2.2", name: "Thể dục tự chọn — Aerobic, bóng chuyền", groupType: "THE_CHAT", minCredits: 1, description: "Aerobic, bóng chuyền" },
  { code: "F2.3", name: "Thể dục tự chọn — Bóng đá, bóng rổ, cầu lông", groupType: "THE_CHAT", minCredits: 1, description: "Bóng đá, bóng rổ, cầu lông" },
  { code: "F3", name: "Ngoại ngữ bổ trợ", groupType: "KIEN_THUC", minCredits: 4, description: "Tiếng Anh bổ trợ" },
  { code: "TC", name: "Giáo dục thể chất", groupType: "THE_CHAT", minCredits: 4, description: "GDTC 1, 2" },
];

async function main() {
  await prisma.tuitionPayment.deleteMany();
  await prisma.tuitionInvoice.deleteMany();
  await prisma.enrollment.deleteMany();
  await prisma.studentStudyPlan.deleteMany();
  await prisma.courseSection.deleteMany();
  await prisma.course.deleteMany();
  await prisma.knowledgeCategory.deleteMany();
  await prisma.user.deleteMany();

  const passwordHash = await bcrypt.hash("123456", 10);

  for (const cat of CATEGORIES) {
    await prisma.knowledgeCategory.create({ data: cat });
  }

  const registrar = await prisma.user.create({
    data: { email: "giaovu@university.edu", passwordHash, name: "Nguyễn Văn Giáo Vụ", role: "REGISTRAR", department: "Phòng Đào tạo" },
  });

  const finance = await prisma.user.create({
    data: { email: "taichinh@university.edu", passwordHash, name: "Trần Thị Tài Chính", role: "FINANCE", department: "Phòng Tài chính" },
  });

  const prof1 = await prisma.user.create({
    data: { email: "gv1@university.edu", passwordHash, name: "TS. Trần Minh Đức", role: "PROFESSOR", department: "CNTT" },
  });

  const prof2 = await prisma.user.create({
    data: { email: "gv2@university.edu", passwordHash, name: "PGS.TS. Lê Thị Hoa", role: "PROFESSOR", department: "Toán" },
  });

  const student1 = await prisma.user.create({
    data: { email: "sv1@university.edu", passwordHash, name: "Phạm Anh Tuấn", role: "STUDENT", studentCode: "SV001", department: "CNTT" },
  });

  const student2 = await prisma.user.create({
    data: { email: "sv2@university.edu", passwordHash, name: "Hoàng Thị Mai", role: "STUDENT", studentCode: "SV002", department: "CNTT" },
  });

  const courses = [];
  for (const item of CURRICULUM_CSE) {
    const course = await prisma.course.create({
      data: {
        code: item.code, name: item.name, credits: item.credits, tuitionCredits: item.tuitionCredits,
        knowledgeBlock: item.knowledgeBlock, courseCategory: item.courseCategory,
        plannedSemester: item.plannedSemester, expectedSemester: plannedToExpected(item.plannedSemester),
        prerequisites: item.prerequisites ?? null, orderIndex: item.orderIndex, department: "CNTT",
      },
    });
    courses.push(course);
  }

  for (const student of [student1, student2]) {
    for (const course of courses) {
      await prisma.studentStudyPlan.create({ data: { studentId: student.id, courseId: course.id, status: "PLANNED" } });
    }
  }

  const registrationPlanned = "Y3_HK1";

  const { ensureOpenSectionsForCurriculum } = await import("../src/lib/open-sections");
  await ensureOpenSectionsForCurriculum();

  const { setupSv1Year1Completed } = await import("../src/lib/demo-student-year1");
  await setupSv1Year1Completed(student1.email);

  const openCourses = CURRICULUM_CSE.filter((c) => c.plannedSemester === registrationPlanned);

  console.log(`Seed: ${courses.length} HP, ${openCourses.length} lớp, ${CATEGORIES.length} danh mục`);
  console.log("\nTài khoản demo (mật khẩu: 123456):");
  console.log(`  Phòng Đào tạo:   ${registrar.email}`);
  console.log(`  Phòng Tài chính: ${finance.email}`);
  console.log(`  Giảng viên:      ${prof1.email}`);
  console.log(`  Sinh viên:       ${student1.email}`);
}

main().catch(console.error).finally(() => prisma.$disconnect());

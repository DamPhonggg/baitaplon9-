"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell, Alert, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";

const GROUP_TYPES = [
  { value: "KIEN_THUC", label: "Kiến thức" },
  { value: "CHUYEN_NGANH", label: "Chuyên ngành" },
  { value: "THE_CHAT", label: "Thể chất" },
];

type Category = { id: string; code: string; name: string; description: string | null; groupType: string; minCredits: number; courseCount: number };

export function CategoriesPage({ user }: { user: SessionUser }) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ text: string; type: "error" | "success" } | null>(null);
  const [form, setForm] = useState<Record<string, string>>({});
  const [showForm, setShowForm] = useState(false);

  const nav = navLinksForRole(user.role);

  const load = useCallback(async () => {
    const res = await fetch("/api/registrar/categories");
    const data = await res.json();
    if (res.ok) setCategories(data.categories);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/registrar/categories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    if (res.ok) {
      setMessage({ text: "Đã thêm danh mục", type: "success" });
      setShowForm(false);
      setForm({});
      load();
    } else setMessage({ text: data.error, type: "error" });
  }

  return (
    <AppShell user={user} title="Phòng Đào tạo — Danh mục môn học" nav={nav}>
      {message && <Alert message={message.text} type={message.type} />}
      <p className="text-sm text-slate-600 mb-4">Quản lý khối kiến thức, nhóm môn học trong CTĐT (Actor: Quản trị viên)</p>
      <button className="btn-primary text-sm mb-4" onClick={() => setShowForm(!showForm)}>{showForm ? "Đóng" : "+ Thêm danh mục"}</button>
      {showForm && (
        <form onSubmit={handleSubmit} className="card p-4 mb-4 grid sm:grid-cols-2 gap-3">
          <div><label className="label">Mã khối</label><input className="input" required value={form.code || ""} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="A1" /></div>
          <div><label className="label">Tên danh mục</label><input className="input" required value={form.name || ""} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><label className="label">Nhóm</label>
            <select className="input" value={form.groupType || "KIEN_THUC"} onChange={(e) => setForm({ ...form, groupType: e.target.value })}>
              {GROUP_TYPES.map((g) => <option key={g.value} value={g.value}>{g.label}</option>)}
            </select>
          </div>
          <div><label className="label">Tín chỉ tối thiểu</label><input className="input" type="number" value={form.minCredits || ""} onChange={(e) => setForm({ ...form, minCredits: e.target.value })} /></div>
          <div className="sm:col-span-2"><label className="label">Mô tả</label><input className="input" value={form.description || ""} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
          <div><button type="submit" className="btn-primary">Lưu</button></div>
        </form>
      )}
      {loading ? <p>Đang tải...</p> : (
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="table-head">
              <tr>
                <th className="px-4 py-2 text-left">Mã</th>
                <th className="px-4 py-2 text-left">Tên danh mục</th>
                <th className="px-4 py-2 text-left">Nhóm</th>
                <th className="px-4 py-2 text-center">Min TC</th>
                <th className="px-4 py-2 text-center">Số HP</th>
              </tr>
            </thead>
            <tbody>
              {categories.map((c) => (
                <tr key={c.id} className="border-b hover:bg-slate-50">
                  <td className="px-4 py-2 font-mono font-medium">{c.code}</td>
                  <td className="px-4 py-2">{c.name}<p className="text-xs text-slate-400">{c.description}</p></td>
                  <td className="px-4 py-2"><Badge color="blue">{GROUP_TYPES.find((g) => g.value === c.groupType)?.label ?? c.groupType}</Badge></td>
                  <td className="px-4 py-2 text-center">{c.minCredits}</td>
                  <td className="px-4 py-2 text-center">{c.courseCount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}

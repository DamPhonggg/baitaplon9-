"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell, Alert, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";

type Check = {
  studentId: string; studentName: string; studentCode: string | null;
  totalCredits: number; requiredCredits: number; creditsMet: boolean;
  gpa: number; minGpa: number; gpaMet: boolean;
  completedCourses: number; totalCourses: number; coursesMet: boolean;
  eligible: boolean; missingCourses: { code: string; name: string }[];
};

export function GraduationPage({ user }: { user: SessionUser }) {
  const [checks, setChecks] = useState<Check[]>([]);
  const [rules, setRules] = useState({ minCredits: 120, minGpa: 2.0 });
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<Check | null>(null);

  const nav = navLinksForRole(user.role);

  const load = useCallback(async () => {
    const res = await fetch("/api/registrar/graduation");
    const data = await res.json();
    if (res.ok) { setChecks(data.checks); setRules(data.rules); }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <AppShell user={user} title="Phòng Đào tạo — Xét điều kiện tốt nghiệp" nav={nav}>
      <p className="text-sm text-slate-600 mb-4">
        Xét tốt nghiệp: ≥ {rules.minCredits} tín chỉ, GPA ≥ {rules.minGpa} (Actor: Phòng Đào tạo)
      </p>
      {loading ? <p>Đang tải...</p> : (
        <div className="grid lg:grid-cols-2 gap-6">
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="table-head">
                <tr>
                  <th className="px-3 py-2 text-left">MSSV</th>
                  <th className="px-3 py-2 text-left">Họ tên</th>
                  <th className="px-3 py-2 text-center">TC</th>
                  <th className="px-3 py-2 text-center">GPA</th>
                  <th className="px-3 py-2 text-center">KQ</th>
                </tr>
              </thead>
              <tbody>
                {checks.map((c) => (
                  <tr key={c.studentId} className="border-b hover:bg-slate-50 cursor-pointer" onClick={() => setSelected(c)}>
                    <td className="px-3 py-2 font-mono">{c.studentCode}</td>
                    <td className="px-3 py-2">{c.studentName}</td>
                    <td className="px-3 py-2 text-center">{c.totalCredits}/{c.requiredCredits}</td>
                    <td className="px-3 py-2 text-center">{c.gpa.toFixed(2)}</td>
                    <td className="px-3 py-2 text-center">
                      <Badge color={c.eligible ? "green" : "yellow"}>{c.eligible ? "Đủ ĐK" : "Chưa đủ"}</Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {selected && (
            <div className="card p-5">
              <h3 className="font-semibold mb-4">{selected.studentName} ({selected.studentCode})</h3>
              <ul className="space-y-2 text-sm mb-4">
                <li className={selected.creditsMet ? "text-green-700" : "text-red-600"}>
                  Tín chỉ: {selected.totalCredits}/{selected.requiredCredits} {selected.creditsMet ? "✓" : "✗"}
                </li>
                <li className={selected.gpaMet ? "text-green-700" : "text-red-600"}>
                  GPA: {selected.gpa.toFixed(2)}/{selected.minGpa} {selected.gpaMet ? "✓" : "✗"}
                </li>
                <li className={selected.coursesMet ? "text-green-700" : "text-red-600"}>
                  Hoàn thành CTĐT: {selected.completedCourses}/{selected.totalCourses} {selected.coursesMet ? "✓" : "✗"}
                </li>
              </ul>
              {selected.missingCourses.length > 0 && (
                <>
                  <p className="text-xs font-medium text-slate-500 mb-2">Môn chưa hoàn thành:</p>
                  <ul className="text-xs space-y-1 max-h-48 overflow-y-auto">
                    {selected.missingCourses.map((m) => (
                      <li key={m.code} className="text-slate-600">{m.code} — {m.name}</li>
                    ))}
                  </ul>
                </>
              )}
              <div className={`mt-4 p-3 rounded-lg text-center font-semibold ${selected.eligible ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`}>
                {selected.eligible ? "ĐỦ ĐIỀU KIỆN TỐT NGHIỆP" : "CHƯA ĐỦ ĐIỀU KIỆN"}
              </div>
            </div>
          )}
        </div>
      )}
    </AppShell>
  );
}

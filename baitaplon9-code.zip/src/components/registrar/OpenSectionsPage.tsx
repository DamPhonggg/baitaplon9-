"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { AppShell, Alert, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";
import { SEMESTER_LABELS, SEMESTER_ORDER, plannedToExpected } from "@/lib/curriculum-plan";

type Professor = { id: string; name: string; email: string };

type Course = { id: string; code: string; name: string; credits: number; plannedSemester: string | null };

type Section = {
  id: string;
  semester: string;
  isOpen: boolean;
  schedule: string;
  room: string | null;
  capacity: number;
  professorId: string | null;
  course: { code: string; name: string };
  _count: { enrollments: number };
  professor: { id: string; name: string } | null;
};

type AddForm = {
  plannedSemester: string;
  courseCode: string;
  schedule: string;
  room: string;
  professorId: string;
  capacity: string;
  isOpen: string;
};

const EMPTY_FORM: AddForm = {
  plannedSemester: "Y3_HK1",
  courseCode: "",
  schedule: "",
  room: "",
  professorId: "",
  capacity: "40",
  isOpen: "open",
};

export function OpenSectionsPage({ user }: { user: SessionUser }) {
  const [sections, setSections] = useState<Section[]>([]);
  const [allCourses, setAllCourses] = useState<Course[]>([]);
  const [professors, setProfessors] = useState<Professor[]>([]);
  const [filterPlanned, setFilterPlanned] = useState("Y3_HK1");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ text: string; type: "error" | "success" } | null>(null);
  const [addForm, setAddForm] = useState<AddForm>(EMPTY_FORM);
  const [showAddForm, setShowAddForm] = useState(true);

  const nav = navLinksForRole(user.role, "sections");

  const filterSemester = useMemo(
    () => plannedToExpected(filterPlanned),
    [filterPlanned]
  );

  const addSemester = useMemo(
    () => plannedToExpected(addForm.plannedSemester),
    [addForm.plannedSemester]
  );

  const load = useCallback(async () => {
    setLoading(true);
    const [sectionsRes, profRes] = await Promise.all([
      fetch(`/api/registrar/sections?planned=${filterPlanned}`),
      fetch("/api/registrar/professors"),
    ]);
    const sectionsJson = await sectionsRes.json();
    const profJson = await profRes.json();
    if (sectionsRes.ok) {
      setSections(sectionsJson.sections);
      setAllCourses(sectionsJson.allCourses ?? []);
    }
    if (profRes.ok) setProfessors(profJson.professors);
    setLoading(false);
  }, [filterPlanned]);

  useEffect(() => { load(); }, [load]);

  async function handleAddSection(e: React.FormEvent) {
    e.preventDefault();
    setMessage(null);

    if (!addForm.courseCode || !addForm.schedule.trim()) {
      setMessage({ text: "Vui lòng chọn mã HP và nhập lịch học", type: "error" });
      return;
    }

    const res = await fetch("/api/registrar/sections", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        courseCode: addForm.courseCode,
        semester: addSemester,
        schedule: addForm.schedule.trim(),
        room: addForm.room.trim() || null,
        capacity: addForm.capacity || "40",
        professorId: addForm.professorId || null,
        isOpen: addForm.isOpen === "open",
      }),
    });
    const json = await res.json();
    if (res.ok) {
      setMessage({ text: "Đã thêm lớp học phần", type: "success" });
      setAddForm({ ...EMPTY_FORM, plannedSemester: addForm.plannedSemester });
      if (addForm.plannedSemester !== filterPlanned) {
        setFilterPlanned(addForm.plannedSemester);
      } else {
        load();
      }
    } else {
      setMessage({ text: json.error, type: "error" });
    }
  }

  async function updateSection(sectionId: string, data: Record<string, unknown>) {
    const res = await fetch("/api/registrar/sections", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sectionId, ...data }),
    });
    const json = await res.json();
    if (res.ok) {
      setMessage({ text: "Đã cập nhật lớp", type: "success" });
      load();
    } else {
      setMessage({ text: json.error, type: "error" });
    }
  }

  return (
    <AppShell user={user} title="Phòng Đào tạo — Mở lớp học phần dự kiến" nav={nav}>
      {message && <Alert message={message.text} type={message.type} />}

      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <p className="text-sm text-slate-600">
          Quản lý lớp học phần theo học kỳ — đồng bộ với sinh viên và giảng viên.
        </p>
        <button
          type="button"
          className="btn-primary text-sm"
          onClick={() => setShowAddForm((v) => !v)}
        >
          {showAddForm ? "Ẩn form thêm" : "+ Thêm lớp học phần"}
        </button>
      </div>

      {showAddForm && (
        <form onSubmit={handleAddSection} className="card p-5 mb-6">
          <h3 className="font-semibold mb-4">Thêm lớp học phần mới</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="label">Học kỳ</label>
              <select
                className="input"
                value={addForm.plannedSemester}
                onChange={(e) => setAddForm({ ...addForm, plannedSemester: e.target.value })}
              >
                {SEMESTER_ORDER.map((key) => (
                  <option key={key} value={key}>{SEMESTER_LABELS[key]}</option>
                ))}
              </select>
              <p className="text-xs text-slate-400 mt-1">{addSemester.replace(/_/g, " ")}</p>
            </div>

            <div>
              <label className="label">Mã HP</label>
              <select
                className="input"
                value={addForm.courseCode}
                onChange={(e) => setAddForm({ ...addForm, courseCode: e.target.value })}
                required
              >
                <option value="">— Chọn học phần ({allCourses.length} HP) —</option>
                {allCourses.map((c) => (
                  <option key={c.id} value={c.code}>
                    {c.code} — {c.name}
                    {c.plannedSemester ? ` · ${SEMESTER_LABELS[c.plannedSemester] ?? c.plannedSemester}` : ""}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="label">Lịch học</label>
              <input
                className="input"
                placeholder="T2 07:00-09:00"
                value={addForm.schedule}
                onChange={(e) => setAddForm({ ...addForm, schedule: e.target.value })}
                required
              />
            </div>

            <div>
              <label className="label">Phòng</label>
              <input
                className="input"
                placeholder="A101"
                value={addForm.room}
                onChange={(e) => setAddForm({ ...addForm, room: e.target.value })}
              />
            </div>

            <div>
              <label className="label">Giảng viên</label>
              <select
                className="input"
                value={addForm.professorId}
                onChange={(e) => setAddForm({ ...addForm, professorId: e.target.value })}
              >
                <option value="">Chưa phân công</option>
                {professors.map((p) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="label">Sĩ số tối đa (SV)</label>
              <input
                className="input"
                type="number"
                min="1"
                max="200"
                value={addForm.capacity}
                onChange={(e) => setAddForm({ ...addForm, capacity: e.target.value })}
              />
            </div>

            <div>
              <label className="label">Trạng thái</label>
              <select
                className="input"
                value={addForm.isOpen}
                onChange={(e) => setAddForm({ ...addForm, isOpen: e.target.value })}
              >
                <option value="open">Mở đăng ký</option>
                <option value="closed">Đóng</option>
              </select>
            </div>
          </div>

          <div className="mt-4 flex gap-2">
            <button type="submit" className="btn-primary">Thêm lớp</button>
            <button type="button" className="btn-secondary" onClick={() => setAddForm(EMPTY_FORM)}>
              Xóa form
            </button>
          </div>
        </form>
      )}

      <div className="flex flex-wrap items-center gap-3 mb-4">
        <label className="text-sm font-medium text-slate-700">Lọc theo học kỳ:</label>
        <select
          className="input w-auto min-w-[200px]"
          value={filterPlanned}
          onChange={(e) => setFilterPlanned(e.target.value)}
        >
          {SEMESTER_ORDER.map((key) => (
            <option key={key} value={key}>{SEMESTER_LABELS[key]}</option>
          ))}
        </select>
        <span className="text-xs text-slate-500">{filterSemester.replace(/_/g, " ")}</span>
      </div>

      {loading ? (
        <p className="text-slate-500">Đang tải...</p>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm min-w-[900px]">
            <thead className="table-head">
              <tr>
                <th className="px-3 py-2 text-left">Học kỳ</th>
                <th className="px-3 py-2 text-left">Mã HP</th>
                <th className="px-3 py-2 text-left">Lịch</th>
                <th className="px-3 py-2 text-left">Phòng</th>
                <th className="px-3 py-2 text-left">Giảng viên</th>
                <th className="px-3 py-2 text-center">SV</th>
                <th className="px-3 py-2 text-center">Trạng thái</th>
                <th className="px-3 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {sections.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-3 py-8 text-center text-slate-500">
                    Chưa có lớp nào trong học kỳ này
                  </td>
                </tr>
              ) : (
                sections.map((s) => (
                  <tr key={s.id} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="px-3 py-2 text-xs whitespace-nowrap">
                      {s.semester.replace(/_/g, " ")}
                    </td>
                    <td className="px-3 py-2">
                      <span className="font-mono font-medium">{s.course.code}</span>
                      <p className="text-xs text-slate-500 truncate max-w-[180px]">{s.course.name}</p>
                    </td>
                    <td className="px-3 py-2">{s.schedule}</td>
                    <td className="px-3 py-2">{s.room || "—"}</td>
                    <td className="px-3 py-2">
                      <select
                        className="input text-xs py-1 min-w-[140px]"
                        value={s.professorId || ""}
                        onChange={(e) => updateSection(s.id, { professorId: e.target.value || null })}
                      >
                        <option value="">Chưa phân công</option>
                        {professors.map((p) => (
                          <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                      </select>
                    </td>
                    <td className="px-3 py-2 text-center whitespace-nowrap">
                      <span className="font-medium">{s._count.enrollments}</span>
                      <span className="text-slate-400">/{s.capacity}</span>
                    </td>
                    <td className="px-3 py-2 text-center">
                      <Badge color={s.isOpen ? "green" : "gray"}>
                        {s.isOpen ? "Mở ĐK" : "Đóng"}
                      </Badge>
                    </td>
                    <td className="px-3 py-2">
                      <button
                        type="button"
                        className="text-xs text-primary-600 hover:underline"
                        onClick={() => updateSection(s.id, { isOpen: !s.isOpen })}
                      >
                        {s.isOpen ? "Đóng lớp" : "Mở lớp"}
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}

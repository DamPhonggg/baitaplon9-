"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell, Alert, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";
import { CURRENT_REGISTRATION } from "@/lib/enrollment-rules";

type Tab = "students" | "professors" | "courses";

export function RegistrarDashboard({ user }: { user: SessionUser }) {
  const [tab, setTab] = useState<Tab>("students");
  const [students, setStudents] = useState<Record<string, string>[]>([]);
  const [professors, setProfessors] = useState<Record<string, string>[]>([]);
  const [courses, setCourses] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ text: string; type: "error" | "success" } | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    setLoading(true);
    if (tab === "students") {
      const res = await fetch("/api/registrar/students");
      const data = await res.json();
      if (res.ok) setStudents(data.students);
    } else if (tab === "professors") {
      const res = await fetch("/api/registrar/professors");
      const data = await res.json();
      if (res.ok) setProfessors(data.professors);
    } else {
      const res = await fetch("/api/registrar/courses");
      const data = await res.json();
      if (res.ok) setCourses(data.courses);
    }
    setLoading(false);
  }, [tab]);

  useEffect(() => { load(); }, [load]);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setMessage(null);

    const endpoints: Record<Tab, string> = {
      students: "/api/registrar/students",
      professors: "/api/registrar/professors",
      courses: "/api/registrar/courses",
    };

    const body =
      tab === "courses"
        ? {
            code: form.code,
            name: form.name,
            credits: form.credits,
            department: form.department,
            description: form.description,
            section: form.schedule
              ? { semester: CURRENT_REGISTRATION.sectionSemester, schedule: form.schedule, room: form.room, capacity: form.capacity || "40" }
              : undefined,
          }
        : form;

    const res = await fetch(endpoints[tab], {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (res.ok) {
      setMessage({ text: "Thêm mới thành công!", type: "success" });
      setShowForm(false);
      setForm({});
      load();
    } else {
      setMessage({ text: data.error, type: "error" });
    }
  }

  async function handleDelete(id: string) {
    if (!confirm("Xác nhận xóa?")) return;
    const endpoints: Record<Tab, string> = {
      students: `/api/registrar/students?id=${id}`,
      professors: `/api/registrar/professors?id=${id}`,
      courses: `/api/registrar/courses?id=${id}`,
    };
    const res = await fetch(endpoints[tab], { method: "DELETE" });
    if (res.ok) {
      setMessage({ text: "Đã xóa", type: "success" });
      load();
    }
  }

  const tabs: { key: Tab; label: string }[] = [
    { key: "students", label: "Sinh viên" },
    { key: "professors", label: "Giảng viên" },
    { key: "courses", label: "Chương trình đào tạo" },
  ];

  return (
    <AppShell
      user={user}
      title="Giáo vụ — Quản trị hệ thống"
      nav={navLinksForRole(user.role)}
    >
      {message && <Alert message={message.text} type={message.type} />}

      <div className="flex gap-2 mb-6">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => { setTab(t.key); setShowForm(false); }}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              tab === t.key ? "bg-primary-500 text-white" : "bg-white border border-amber-200 text-amber-800 hover:bg-amber-50"
            }`}
          >
            {t.label}
          </button>
        ))}
        <button className="btn-primary ml-auto text-sm" onClick={() => setShowForm(!showForm)}>
          {showForm ? "Đóng" : "+ Thêm mới"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="card p-4 mb-6 grid sm:grid-cols-2 gap-4">
          {tab === "students" && (
            <>
              <div><label className="label">Email</label><input className="input" type="email" placeholder="sv3@university.edu" required value={form.email || ""} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
              <div><label className="label">Mật khẩu</label><input className="input" type="password" placeholder="123456" required value={form.password || ""} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
              <div><label className="label">Họ tên</label><input className="input" required value={form.name || ""} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div><label className="label">MSSV</label><input className="input" placeholder="SV003" required value={form.studentCode || ""} onChange={(e) => setForm({ ...form, studentCode: e.target.value })} /></div>
              <div><label className="label">Khoa</label><input className="input" placeholder="CNTT" value={form.department || ""} onChange={(e) => setForm({ ...form, department: e.target.value })} /></div>
              <p className="sm:col-span-2 text-xs text-slate-500">
                Sinh viên đăng nhập bằng <strong>email</strong> hoặc <strong>MSSV</strong> kèm mật khẩu vừa tạo.
              </p>
            </>
          )}
          {tab === "professors" && (
            <>
              <div><label className="label">Email</label><input className="input" required value={form.email || ""} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
              <div><label className="label">Mật khẩu</label><input className="input" type="password" required value={form.password || ""} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
              <div><label className="label">Họ tên</label><input className="input" required value={form.name || ""} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div><label className="label">Khoa</label><input className="input" value={form.department || ""} onChange={(e) => setForm({ ...form, department: e.target.value })} /></div>
            </>
          )}
          {tab === "courses" && (
            <>
              <div><label className="label">Mã HP</label><input className="input" required value={form.code || ""} onChange={(e) => setForm({ ...form, code: e.target.value })} /></div>
              <div><label className="label">Tên học phần</label><input className="input" required value={form.name || ""} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
              <div><label className="label">Tín chỉ</label><input className="input" type="number" required value={form.credits || ""} onChange={(e) => setForm({ ...form, credits: e.target.value })} /></div>
              <div><label className="label">Khoa</label><input className="input" required value={form.department || ""} onChange={(e) => setForm({ ...form, department: e.target.value })} /></div>
              <div><label className="label">Lịch học (T2 07:00-09:00)</label><input className="input" value={form.schedule || ""} onChange={(e) => setForm({ ...form, schedule: e.target.value })} /></div>
              <div><label className="label">Phòng</label><input className="input" value={form.room || ""} onChange={(e) => setForm({ ...form, room: e.target.value })} /></div>
            </>
          )}
          <div className="sm:col-span-2">
            <button type="submit" className="btn-primary">Lưu</button>
          </div>
        </form>
      )}

      {loading ? (
        <p className="text-slate-500">Đang tải...</p>
      ) : tab === "students" ? (
        <DataTable
          headers={["MSSV", "Họ tên", "Email", "Khoa", ""]}
          rows={students.map((s) => [
            s.studentCode, s.name, s.email, s.department || "—",
            <button key="del" className="text-red-600 text-sm hover:underline" onClick={() => handleDelete(s.id)}>Xóa</button>,
          ])}
        />
      ) : tab === "professors" ? (
        <DataTable
          headers={["Họ tên", "Email", "Khoa", ""]}
          rows={professors.map((p) => [
            p.name, p.email, p.department || "—",
            <button key="del" className="text-red-600 text-sm hover:underline" onClick={() => handleDelete(p.id)}>Xóa</button>,
          ])}
        />
      ) : (
        <div className="space-y-3">
          {courses.map((c) => {
            const course = c as { id: string; code: string; name: string; credits: number; department: string; sections: { schedule: string; professor: { name: string } | null }[] };
            return (
              <div key={course.id} className="card p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-semibold">{course.code}</span>
                      <Badge color="blue">{course.credits} TC</Badge>
                    </div>
                    <p className="font-medium">{course.name}</p>
                    <p className="text-sm text-slate-500">{course.department}</p>
                    {course.sections.map((s, i) => (
                      <p key={i} className="text-xs text-slate-400 mt-1">
                        {s.schedule} · GV: {s.professor?.name || "Chưa phân công"}
                      </p>
                    ))}
                  </div>
                  <button className="text-red-600 text-sm hover:underline" onClick={() => handleDelete(course.id)}>Xóa</button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </AppShell>
  );
}

function DataTable({ headers, rows }: { headers: string[]; rows: (string | React.ReactNode)[][] }) {
  return (
    <div className="card overflow-hidden">
      <table className="w-full text-sm">
        <thead className="bg-amber-100 border-b border-amber-200">
          <tr>{headers.map((h) => <th key={h} className="text-left px-4 py-3 font-medium">{h}</th>)}</tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr><td colSpan={headers.length} className="px-4 py-8 text-center text-slate-500">Chưa có dữ liệu</td></tr>
          ) : rows.map((row, i) => (
            <tr key={i} className="border-b border-slate-100 hover:bg-slate-50">
              {row.map((cell, j) => <td key={j} className="px-4 py-3">{cell}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

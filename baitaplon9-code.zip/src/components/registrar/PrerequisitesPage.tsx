"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell, Alert } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";

type Course = { id: string; code: string; name: string; knowledgeBlock: string; prerequisites: string | null; plannedSemester: string | null; credits: number };

export function PrerequisitesPage({ user }: { user: SessionUser }) {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ text: string; type: "error" | "success" } | null>(null);
  const [editing, setEditing] = useState<string | null>(null);
  const [value, setValue] = useState("");

  const nav = navLinksForRole(user.role);

  const load = useCallback(async () => {
    const res = await fetch("/api/registrar/prerequisites");
    const data = await res.json();
    if (res.ok) setCourses(data.courses);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function save(courseId: string) {
    const res = await fetch("/api/registrar/prerequisites", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ courseId, prerequisites: value }),
    });
    if (res.ok) {
      setMessage({ text: "Đã cập nhật tiên quyết", type: "success" });
      setEditing(null);
      load();
    }
  }

  return (
    <AppShell user={user} title="Phòng Đào tạo — Điều kiện tiên quyết" nav={nav}>
      {message && <Alert message={message.text} type={message.type} />}
      <p className="text-sm text-slate-600 mb-4">Thiết lập môn học trước / tiên quyết cho từng học phần (Actor: Quản trị viên)</p>
      <p className="text-xs text-slate-400 mb-4">Ví dụ: <code>Tiên quyết(Cơ sở lập trình)</code> hoặc <code>Học trước(Tiếng anh cơ bản 1)</code></p>
      {loading ? <p>Đang tải...</p> : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm min-w-[800px]">
            <thead className="table-head">
              <tr>
                <th className="px-3 py-2 text-left">Mã HP</th>
                <th className="px-3 py-2 text-left">Tên học phần</th>
                <th className="px-3 py-2 text-left">Khối</th>
                <th className="px-3 py-2 text-left">Điều kiện tiên quyết</th>
                <th className="px-3 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {courses.map((c) => (
                <tr key={c.id} className="border-b hover:bg-slate-50">
                  <td className="px-3 py-2 font-mono">{c.code}</td>
                  <td className="px-3 py-2">{c.name}</td>
                  <td className="px-3 py-2">{c.knowledgeBlock}</td>
                  <td className="px-3 py-2">
                    {editing === c.id ? (
                      <input className="input text-xs" value={value} onChange={(e) => setValue(e.target.value)} />
                    ) : (
                      <span className="text-slate-600">{c.prerequisites || "—"}</span>
                    )}
                  </td>
                  <td className="px-3 py-2">
                    {editing === c.id ? (
                      <button className="text-primary-600 text-xs mr-2" onClick={() => save(c.id)}>Lưu</button>
                    ) : (
                      <button className="text-primary-600 text-xs" onClick={() => { setEditing(c.id); setValue(c.prerequisites || ""); }}>Sửa</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}

"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell, Alert, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";

type Course = {
  id: string;
  orderIndex: number;
  code: string;
  name: string;
  knowledgeBlock: string;
  credits: number;
  tuitionCredits: number;
  expectedSemester: string | null;
  prerequisites: string | null;
};

type Stats = {
  total: number;
  totalCredits: number;
  totalTuitionCredits: number;
  blocks: string[];
};

import { KNOWLEDGE_BLOCKS } from "@/lib/curriculum-plan";

const BLOCK_COLORS: Record<string, string> = {
  A1: "blue", B1: "green", C1: "yellow", C2: "gray", D1: "blue", "D2.1": "green", "D2.2": "green",
  E1: "blue", E2: "blue", F1: "yellow", "F2.1": "yellow", "F2.2": "yellow", "F2.3": "yellow", F3: "gray", TC: "yellow",
};

export function CurriculumPage({ user }: { user: SessionUser }) {
  const [courses, setCourses] = useState<Course[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [filter, setFilter] = useState("");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ text: string; type: "error" | "success" } | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    setLoading(true);
    const url = filter ? `/api/registrar/curriculum?block=${filter}` : "/api/registrar/curriculum";
    const res = await fetch(url);
    const data = await res.json();
    if (res.ok) {
      setCourses(data.courses);
      setStats(data.stats);
    }
    setLoading(false);
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setMessage(null);
    const res = await fetch("/api/registrar/curriculum", {
      method: editId ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(editId ? { id: editId, ...form } : form),
    });
    const data = await res.json();
    if (res.ok) {
      setMessage({ text: editId ? "Đã cập nhật!" : "Đã thêm học phần!", type: "success" });
      setShowForm(false);
      setEditId(null);
      setForm({});
      load();
    } else {
      setMessage({ text: data.error, type: "error" });
    }
  }

  async function handleSync() {
    if (!confirm("Đồng bộ CTĐT chuẩn vào hệ thống? (Không xóa đăng ký hiện có)")) return;
    setSyncing(true);
    setMessage(null);
    const res = await fetch("/api/registrar/curriculum/sync", { method: "POST" });
    const data = await res.json();
    setSyncing(false);
    if (res.ok) {
      setMessage({ text: data.message, type: "success" });
      load();
    } else {
      setMessage({ text: data.error || "Đồng bộ thất bại", type: "error" });
    }
  }

  async function handleDelete(id: string) {
    if (!confirm("Xóa học phần này khỏi CTĐT?")) return;
    const res = await fetch(`/api/registrar/curriculum?id=${id}`, { method: "DELETE" });
    if (res.ok) { setMessage({ text: "Đã xóa", type: "success" }); load(); }
  }

  function startEdit(c: Course) {
    setEditId(c.id);
    setForm({
      code: c.code, name: c.name, credits: String(c.credits),
      tuitionCredits: String(c.tuitionCredits), knowledgeBlock: c.knowledgeBlock,
      expectedSemester: c.expectedSemester || "", prerequisites: c.prerequisites || "",
      orderIndex: String(c.orderIndex),
    });
    setShowForm(true);
  }

  const filtered = courses.filter((c) =>
    !search || c.code.toLowerCase().includes(search.toLowerCase()) ||
    c.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AppShell
      user={user}
      title="Giáo vụ — Chương trình đào tạo"
      nav={navLinksForRole(user.role)}
    >
      {message && <Alert message={message.text} type={message.type} />}

      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
          <div className="card p-3"><p className="text-xs text-slate-500">Tổng HP</p><p className="text-xl font-bold">{stats.total}</p></div>
          <div className="card p-3"><p className="text-xs text-slate-500">Tổng tín chỉ HP</p><p className="text-xl font-bold">{stats.totalCredits}</p></div>
          <div className="card p-3"><p className="text-xs text-slate-500">Tổng tín học phí</p><p className="text-xl font-bold">{stats.totalTuitionCredits.toFixed(1)}</p></div>
          <div className="card p-3"><p className="text-xs text-slate-500">Khối KT</p><p className="text-xl font-bold">{stats.blocks.join(", ")}</p></div>
        </div>
      )}

      <div className="flex flex-wrap gap-2 mb-4">
        <input className="input max-w-xs" placeholder="Tìm mã/tên HP..." value={search} onChange={(e) => setSearch(e.target.value)} />
        <select className="input max-w-[140px]" value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="">Tất cả khối</option>
          {stats?.blocks.map((b) => <option key={b} value={b}>{b}</option>)}
        </select>
        <button className="btn-secondary text-sm" disabled={syncing} onClick={handleSync}>
          {syncing ? "Đang đồng bộ..." : "Đồng bộ CTĐT"}
        </button>
        <button className="btn-primary text-sm" onClick={() => { setShowForm(!showForm); setEditId(null); setForm({}); }}>
          {showForm ? "Đóng" : "+ Thêm HP"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSave} className="card p-4 mb-4 grid sm:grid-cols-3 gap-3">
          <div><label className="label">STT</label><input className="input" type="number" value={form.orderIndex || ""} onChange={(e) => setForm({ ...form, orderIndex: e.target.value })} /></div>
          <div><label className="label">Mã HP *</label><input className="input" required value={form.code || ""} onChange={(e) => setForm({ ...form, code: e.target.value })} /></div>
          <div><label className="label">Tên học phần *</label><input className="input" required value={form.name || ""} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><label className="label">Khối KT</label>
            <select className="input" value={form.knowledgeBlock || "A1"} onChange={(e) => setForm({ ...form, knowledgeBlock: e.target.value })}>
              {KNOWLEDGE_BLOCKS.map((b) => <option key={b} value={b}>{b}</option>)}
            </select>
          </div>
          <div><label className="label">Tín HP *</label><input className="input" type="number" required value={form.credits || ""} onChange={(e) => setForm({ ...form, credits: e.target.value })} /></div>
          <div><label className="label">Tín học phí</label><input className="input" type="number" step="0.25" value={form.tuitionCredits || ""} onChange={(e) => setForm({ ...form, tuitionCredits: e.target.value })} /></div>
          <div><label className="label">HK dự kiến</label><input className="input" placeholder="2024_2025_HK1" value={form.expectedSemester || ""} onChange={(e) => setForm({ ...form, expectedSemester: e.target.value })} /></div>
          <div className="sm:col-span-2"><label className="label">Điều kiện ràng buộc</label><input className="input" value={form.prerequisites || ""} onChange={(e) => setForm({ ...form, prerequisites: e.target.value })} /></div>
          <div className="sm:col-span-3"><button type="submit" className="btn-primary">{editId ? "Cập nhật" : "Thêm mới"}</button></div>
        </form>
      )}

      {loading ? (
        <p className="text-slate-500">Đang tải...</p>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm min-w-[900px]">
            <thead className="table-head">
              <tr>
                <th className="px-3 py-2 text-left w-10">STT</th>
                <th className="px-3 py-2 text-left">Mã HP</th>
                <th className="px-3 py-2 text-left">Tên học phần</th>
                <th className="px-3 py-2 text-center">Khối KT</th>
                <th className="px-3 py-2 text-center">Tín HP</th>
                <th className="px-3 py-2 text-center">Tín học phí</th>
                <th className="px-3 py-2 text-left">Điều kiện</th>
                <th className="px-3 py-2 text-left">HK dự kiến</th>
                <th className="px-3 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((c) => (
                <tr key={c.id} className="border-b border-amber-100 hover:bg-amber-50 even:bg-amber-50/40">
                  <td className="px-3 py-2 text-slate-500">{c.orderIndex}</td>
                  <td className="px-3 py-2 font-mono font-medium text-primary-700">{c.code}</td>
                  <td className="px-3 py-2">{c.name}</td>
                  <td className="px-3 py-2 text-center"><Badge color={BLOCK_COLORS[c.knowledgeBlock] || "gray"}>{c.knowledgeBlock}</Badge></td>
                  <td className="px-3 py-2 text-center">{c.credits}</td>
                  <td className="px-3 py-2 text-center">{c.tuitionCredits}</td>
                  <td className="px-3 py-2 text-xs text-slate-500 max-w-[180px] truncate" title={c.prerequisites || ""}>{c.prerequisites || "—"}</td>
                  <td className="px-3 py-2 text-xs">{c.expectedSemester?.replace(/_/g, " ") || "—"}</td>
                  <td className="px-3 py-2 whitespace-nowrap">
                    <button className="text-primary-600 text-xs mr-2 hover:underline" onClick={() => startEdit(c)}>Sửa</button>
                    <button className="text-red-600 text-xs hover:underline" onClick={() => handleDelete(c.id)}>Xóa</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}

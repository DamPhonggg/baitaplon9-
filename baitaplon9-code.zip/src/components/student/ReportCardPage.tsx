"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";

type Record = {
  id: string;
  grade: number;
  section: {
    semester: string;
    course: { code: string; name: string; credits: number };
    professor: { name: string } | null;
  };
};

export function StudentReportCardPage({ user }: { user: SessionUser }) {
  const [records, setRecords] = useState<Record[]>([]);
  const [gpa, setGpa] = useState(0);
  const [totalCredits, setTotalCredits] = useState(0);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const res = await fetch("/api/student/report-card");
    const data = await res.json();
    if (res.ok) {
      setRecords(data.enrollments);
      setGpa(data.gpa);
      setTotalCredits(data.totalCredits);
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  function gradeColor(grade: number) {
    if (grade >= 8.5) return "green";
    if (grade >= 7) return "blue";
    if (grade >= 5.5) return "yellow";
    return "gray";
  }

  return (
    <AppShell
      user={user}
      title="Sinh viên — Bảng điểm"
      nav={navLinksForRole(user.role)}
    >
      <div className="grid sm:grid-cols-2 gap-4 mb-6">
        <div className="card p-4">
          <p className="text-sm text-slate-500">GPA tích lũy</p>
          <p className="text-3xl font-bold text-primary-700">{gpa.toFixed(2)}</p>
        </div>
        <div className="card p-4">
          <p className="text-sm text-slate-500">Tổng tín chỉ đã hoàn thành</p>
          <p className="text-3xl font-bold text-primary-700">{totalCredits}</p>
        </div>
      </div>

      <h2 className="text-lg font-semibold mb-4">Kết quả học tập</h2>
      {loading ? (
        <p className="text-slate-500">Đang tải...</p>
      ) : records.length === 0 ? (
        <div className="card p-8 text-center text-slate-500">Chưa có điểm số</div>
      ) : (
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-amber-100 border-b border-amber-200">
              <tr>
                <th className="text-left px-4 py-3 font-medium">Mã HP</th>
                <th className="text-left px-4 py-3 font-medium">Tên học phần</th>
                <th className="text-center px-4 py-3 font-medium">TC</th>
                <th className="text-center px-4 py-3 font-medium">Điểm</th>
                <th className="text-left px-4 py-3 font-medium">Học kỳ</th>
              </tr>
            </thead>
            <tbody>
              {records.map((r) => (
                <tr key={r.id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="px-4 py-3 font-mono font-medium">{r.section.course.code}</td>
                  <td className="px-4 py-3">{r.section.course.name}</td>
                  <td className="px-4 py-3 text-center">{r.section.course.credits}</td>
                  <td className="px-4 py-3 text-center">
                    <Badge color={gradeColor(r.grade)}>{r.grade.toFixed(1)}</Badge>
                  </td>
                  <td className="px-4 py-3 text-slate-500">{r.section.semester}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}

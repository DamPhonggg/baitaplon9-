"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";

type Plan = {
  id: string;
  actualSemester: string | null;
  status: string;
  course: {
    orderIndex: number;
    code: string;
    name: string;
    knowledgeBlock: string;
    credits: number;
    tuitionCredits: number;
    expectedSemester: string | null;
    prerequisites: string | null;
  };
};

const STATUS_LABEL: Record<string, { label: string; color: string }> = {
  PLANNED: { label: "Chưa học", color: "gray" },
  IN_PROGRESS: { label: "Đang học", color: "yellow" },
  COMPLETED: { label: "Hoàn thành", color: "green" },
};

export function StudentStudyPlanPage({ user }: { user: SessionUser }) {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [stats, setStats] = useState<{ total: number; completed: number; completedCredits: number } | null>(null);
  const [filter, setFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editSemester, setEditSemester] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    const url = filter ? `/api/student/study-plan?block=${filter}` : "/api/student/study-plan";
    const res = await fetch(url);
    const data = await res.json();
    if (res.ok) {
      setPlans(data.plans);
      setStats(data.stats);
    }
    setLoading(false);
  }, [filter]);

  useEffect(() => { load(); }, [load]);

  async function saveActualSemester(planId: string) {
    await fetch("/api/student/study-plan", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        planId,
        actualSemester: editSemester || null,
        status: editSemester ? "COMPLETED" : "PLANNED",
      }),
    });
    setEditingId(null);
    load();
  }

  const blocks = Array.from(new Set(plans.map((p) => p.course.knowledgeBlock))).sort();

  return (
    <AppShell
      user={user}
      title="Chương trình học của tôi"
      nav={navLinksForRole(user.role)}
    >
      {stats && (
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="card p-3"><p className="text-xs text-slate-500">Tổng HP trong CTĐT</p><p className="text-2xl font-bold">{stats.total}</p></div>
          <div className="card p-3"><p className="text-xs text-slate-500">Đã hoàn thành</p><p className="text-2xl font-bold text-green-600">{stats.completed}</p></div>
          <div className="card p-3"><p className="text-xs text-slate-500">Tín chỉ tích lũy</p><p className="text-2xl font-bold text-primary-700">{stats.completedCredits}</p></div>
        </div>
      )}

      <select className="input max-w-[140px] mb-4" value={filter} onChange={(e) => setFilter(e.target.value)}>
        <option value="">Tất cả khối</option>
        {blocks.map((b) => <option key={b} value={b}>{b}</option>)}
      </select>

      {loading ? (
        <p className="text-slate-500">Đang tải...</p>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm min-w-[950px]">
            <thead className="table-head">
              <tr>
                <th className="px-3 py-2 text-left w-10">STT</th>
                <th className="px-3 py-2 text-left">Mã HP</th>
                <th className="px-3 py-2 text-left">Tên học phần</th>
                <th className="px-3 py-2 text-center">Khối</th>
                <th className="px-3 py-2 text-center">Tín HP</th>
                <th className="px-3 py-2 text-center">Tín HP phí</th>
                <th className="px-3 py-2 text-left">HK dự kiến</th>
                <th className="px-3 py-2 text-left">HK thực tế</th>
                <th className="px-3 py-2 text-center">Trạng thái</th>
              </tr>
            </thead>
            <tbody>
              {plans.map((p) => {
                const st = STATUS_LABEL[p.status] || STATUS_LABEL.PLANNED;
                const isEditing = editingId === p.id;
                return (
                  <tr key={p.id} className={`border-b border-slate-100 even:bg-slate-50 ${p.status === "COMPLETED" ? "bg-green-50/50" : ""}`}>
                    <td className="px-3 py-2 text-slate-500">{p.course.orderIndex}</td>
                    <td className="px-3 py-2 font-mono font-medium">{p.course.code}</td>
                    <td className="px-3 py-2">{p.course.name}</td>
                    <td className="px-3 py-2 text-center"><Badge color="blue">{p.course.knowledgeBlock}</Badge></td>
                    <td className="px-3 py-2 text-center">{p.course.credits}</td>
                    <td className="px-3 py-2 text-center">{p.course.tuitionCredits}</td>
                    <td className="px-3 py-2 text-xs">{p.course.expectedSemester?.replace(/_/g, " ") || "—"}</td>
                    <td className="px-3 py-2">
                      {isEditing ? (
                        <div className="flex gap-1">
                          <input className="input py-1 text-xs w-32" placeholder="2024_2025_HK1" value={editSemester} onChange={(e) => setEditSemester(e.target.value)} />
                          <button className="text-xs text-primary-600" onClick={() => saveActualSemester(p.id)}>Lưu</button>
                        </div>
                      ) : (
                        <button className="text-xs text-slate-600 hover:text-primary-600" onClick={() => { setEditingId(p.id); setEditSemester(p.actualSemester || ""); }}>
                          {p.actualSemester?.replace(/_/g, " ") || "—"}
                        </button>
                      )}
                    </td>
                    <td className="px-3 py-2 text-center"><Badge color={st.color}>{st.label}</Badge></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}

"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { AppShell, Alert, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";
import { formatVND } from "@/lib/tuition";

type Section = {
  id: string;
  schedule: string;
  room: string | null;
  capacity: number;
  enrolledCount: number;
  isEnrolled: boolean;
  eligible: boolean;
  ineligibleReason?: string;
  categoryLabel: string;
  course: {
    code: string;
    name: string;
    credits: number;
    tuitionCredits: number;
    courseCategory: string;
    prerequisites: string | null;
  };
  professor: { name: string } | null;
};

type SemesterOption = {
  plannedSemester: string;
  sectionSemester: string;
  label: string;
};

type Registration = {
  plannedSemester: string;
  label: string;
  sectionSemester: string;
  minCredits: number;
  maxCredits: number;
  creditsOk: boolean;
};

type CurriculumCourse = {
  code: string;
  name: string;
  credits: number;
  status: string;
  prereqMet: boolean;
};

type Enrollment = {
  id: string;
  section: {
    schedule: string;
    course: { code: string; name: string; credits: number; tuitionCredits: number };
  };
};

type TuitionInfo = {
  ratePerCredit: number;
  totalAmount: number;
  invoiceId: string;
  status: string;
};

const CAT_COLOR: Record<string, string> = {
  THE_CHAT: "yellow",
  KIEN_THUC: "blue",
  CHUYEN_NGANH: "green",
};

export function StudentEnrollPage({ user }: { user: SessionUser }) {
  const [sections, setSections] = useState<Section[]>([]);
  const [myEnrollments, setMyEnrollments] = useState<Enrollment[]>([]);
  const [curriculumCourses, setCurriculumCourses] = useState<CurriculumCourse[]>([]);
  const [registration, setRegistration] = useState<Registration | null>(null);
  const [semesterOptions, setSemesterOptions] = useState<SemesterOption[]>([]);
  const [selectedPlanned, setSelectedPlanned] = useState<string>("Y3_HK1");
  const [totalCredits, setTotalCredits] = useState(0);
  const [totalTuitionCredits, setTotalTuitionCredits] = useState(0);
  const [tuition, setTuition] = useState<TuitionInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ text: string; type: "error" | "success" } | null>(null);

  const load = useCallback(async (planned: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/student/enroll?planned=${encodeURIComponent(planned)}`);
      const data = await res.json();
      if (res.ok) {
        setSections(data.sections);
        setMyEnrollments(data.myEnrollments);
        setCurriculumCourses(data.curriculumCourses);
        setRegistration(data.registration);
        setSemesterOptions(data.semesterOptions ?? []);
        setSelectedPlanned(data.registration.plannedSemester);
        setTotalCredits(data.totalCredits);
        setTotalTuitionCredits(data.totalTuitionCredits ?? 0);
        setTuition(data.tuition ?? null);
      } else {
        setMessage({ text: data.error || "Không tải được dữ liệu đăng ký", type: "error" });
      }
    } catch {
      setMessage({ text: "Không thể kết nối server. Hãy refresh trang hoặc chạy lại npm run dev.", type: "error" });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(selectedPlanned); }, [load, selectedPlanned]);

  function handleSemesterChange(planned: string) {
    setMessage(null);
    setSelectedPlanned(planned);
  }

  async function enroll(sectionId: string) {
    setMessage(null);
    const res = await fetch("/api/student/enroll", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sectionId, plannedSemester: selectedPlanned }),
    });
    const data = await res.json();
    if (res.ok) {
      setMessage({ text: "Đăng ký thành công!", type: "success" });
      load(selectedPlanned);
    } else {
      setMessage({ text: data.error, type: "error" });
    }
  }

  async function drop(enrollmentId: string) {
    setMessage(null);
    const res = await fetch(`/api/student/enroll?id=${enrollmentId}`, { method: "DELETE" });
    const data = await res.json();
    if (res.ok) {
      setMessage({ text: "Đã hủy đăng ký", type: "success" });
      load(selectedPlanned);
    } else {
      setMessage({ text: data.error, type: "error" });
    }
  }

  const grouped = useMemo(() => {
    const groups: Record<string, Section[]> = {};
    for (const s of sections) {
      const key = s.course.courseCategory;
      if (!groups[key]) groups[key] = [];
      groups[key].push(s);
    }
    return groups;
  }, [sections]);

  const creditPercent = registration
    ? Math.min(100, (totalCredits / registration.maxCredits) * 100)
    : 0;

  return (
    <AppShell
      user={user}
      title="Sinh viên — Đăng ký học phần"
      nav={navLinksForRole(user.role)}
    >
      {message && <Alert message={message.text} type={message.type} />}

      {registration && (
        <div className="card p-4 mb-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <label htmlFor="semester-select" className="block text-sm font-medium text-slate-600 mb-1">
                Chọn học kỳ đăng ký
              </label>
              <select
                id="semester-select"
                className="input text-base font-semibold min-w-[220px]"
                value={selectedPlanned}
                onChange={(e) => handleSemesterChange(e.target.value)}
              >
                {(semesterOptions.length > 0 ? semesterOptions : [{ plannedSemester: selectedPlanned, label: registration.label, sectionSemester: registration.sectionSemester }]).map((opt) => (
                  <option key={opt.plannedSemester} value={opt.plannedSemester}>
                    {opt.label}
                  </option>
                ))}
              </select>
              <p className="text-sm text-slate-500 mt-1">
                Kỳ hệ thống: {registration.sectionSemester.replace(/_/g, " ")}
              </p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-primary-700">
                {totalCredits} / {registration.maxCredits} TC
              </p>
              <p className="text-xs text-slate-500">Tối thiểu {registration.minCredits} TC</p>
            </div>
          </div>
          <div className="mt-3 h-2 bg-amber-100 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all ${
                totalCredits > registration.maxCredits ? "bg-red-500" :
                totalCredits < registration.minCredits ? "bg-primary-300" : "bg-primary-500"
              }`}
              style={{ width: `${creditPercent}%` }}
            />
          </div>
          {totalCredits > 0 && totalCredits < registration.minCredits && (
            <p className="text-xs text-yellow-700 mt-2">Cần đăng ký thêm {registration.minCredits - totalCredits} TC nữa</p>
          )}
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {loading ? (
            <p className="text-slate-500">Đang tải...</p>
          ) : sections.length === 0 ? (
            <div className="card p-8 text-center text-amber-800/70">
              <p className="font-medium mb-1">Chưa có lớp mở cho học kỳ này</p>
              <p className="text-sm">Phòng Đào tạo cần mở lớp học phần tại mục &quot;Mở lớp học phần&quot;.</p>
            </div>
          ) : (
            Object.entries(grouped).map(([cat, items]) => (
              <div key={cat}>
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Badge color={CAT_COLOR[cat] || "gray"}>{items[0]?.categoryLabel}</Badge>
                  <span className="text-slate-500 text-sm font-normal">{items.length} lớp</span>
                </h3>
                <div className="space-y-3">
                  {items.map((s) => (
                    <div key={s.id} className={`card p-4 ${s.isEnrolled ? "border-green-300 bg-green-50/30" : ""}`}>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <span className="font-mono font-semibold text-primary-700">{s.course.code}</span>
                            <Badge color="blue">{s.course.credits} TC</Badge>
                            {s.isEnrolled && <Badge color="green">Đã đăng ký</Badge>}
                            {!s.eligible && !s.isEnrolled && (
                              <Badge color="gray">Không đủ ĐK</Badge>
                            )}
                          </div>
                          <p className="font-medium">{s.course.name}</p>
                          {s.course.prerequisites && (
                            <p className="text-xs text-slate-400 mt-1">{s.course.prerequisites}</p>
                          )}
                          <p className="text-sm text-slate-500 mt-1">
                            {s.schedule} · {s.room || "—"} · GV: {s.professor?.name || "Chưa phân công"}
                          </p>
                          <p className="text-xs text-slate-400 mt-1">
                            {s.enrolledCount}/{s.capacity} sinh viên · {s.course.tuitionCredits} tín học phí
                          </p>
                          {!s.eligible && !s.isEnrolled && s.ineligibleReason && (
                            <p className="text-xs text-red-600 mt-1">{s.ineligibleReason}</p>
                          )}
                        </div>
                        <div>
                          {s.isEnrolled ? (
                            <button
                              className="btn-danger text-sm"
                              onClick={() => {
                                const e = myEnrollments.find((x) => x.section.course.code === s.course.code);
                                if (e) drop(e.id);
                              }}
                            >
                              Hủy
                            </button>
                          ) : (
                            <button
                              className="btn-primary text-sm"
                              disabled={!s.eligible}
                              onClick={() => enroll(s.id)}
                            >
                              Đăng ký
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))
          )}
        </div>

        <div className="space-y-4">
          <div className="card p-4 sticky top-24">
            <h3 className="font-semibold mb-3">Đã đăng ký kỳ này</h3>
            <p className="text-2xl font-bold text-primary-700 mb-1">{totalCredits} tín chỉ</p>
            {myEnrollments.length === 0 ? (
              <p className="text-sm text-slate-500">Chưa đăng ký môn nào</p>
            ) : (
              <ul className="space-y-2 mb-4">
                {myEnrollments.map((e) => (
                  <li key={e.id} className="text-sm border-b border-slate-100 pb-2">
                    <span className="font-mono font-medium">{e.section.course.code}</span>
                    <p className="text-slate-600">{e.section.course.name}</p>
                    <p className="text-xs text-slate-400">
                      {e.section.schedule} · {e.section.course.tuitionCredits} tín HP
                    </p>
                  </li>
                ))}
              </ul>
            )}

            <div className="border-t border-slate-100 pt-4">
              <h4 className="font-semibold text-sm mb-2">Học phí kỳ này</h4>
              <p className="text-xs text-slate-500 mb-1">
                {totalTuitionCredits} tín học phí × {formatVND(tuition?.ratePerCredit ?? 500_000)}/TC
              </p>
              <p className="text-xl font-bold text-primary-700">
                {formatVND(tuition?.totalAmount ?? 0)}
              </p>
              {tuition && totalTuitionCredits > 0 && (
                <div className="mt-3">
                  {tuition.status === "PAID" ? (
                    <Badge color="green">Đã thanh toán</Badge>
                  ) : (
                    <Badge color="yellow">Chưa thanh toán</Badge>
                  )}
                </div>
              )}
            </div>
          </div>

          {curriculumCourses.length > 0 && (
            <div className="card p-4">
              <h3 className="font-semibold mb-3 text-sm">Môn trong CTĐT — kỳ này</h3>
              <ul className="space-y-2">
                {curriculumCourses.map((c) => (
                  <li key={c.code} className="text-xs flex items-start justify-between gap-2">
                    <span>
                      <span className="font-mono font-medium">{c.code}</span>
                      <span className="text-slate-500 ml-1">({c.credits} TC)</span>
                    </span>
                    <Badge color={
                      c.status === "COMPLETED" ? "green" :
                      c.status === "IN_PROGRESS" ? "yellow" :
                      c.prereqMet ? "blue" : "gray"
                    }>
                      {c.status === "COMPLETED" ? "Xong" :
                       c.status === "IN_PROGRESS" ? "Đang học" :
                       c.prereqMet ? "Có thể ĐK" : "Chưa đủ ĐK"}
                    </Badge>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}

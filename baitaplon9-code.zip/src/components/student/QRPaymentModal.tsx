"use client";

import Image from "next/image";
import { formatVND } from "@/lib/tuition";
import { PAYMENT_CONFIG, buildTransferContent } from "@/lib/payment-config";

type Props = {
  open: boolean;
  amount: number;
  studentCode: string | null;
  semester: string;
  paying: boolean;
  onClose: () => void;
  onConfirm: () => void;
};

export function QRPaymentModal({
  open,
  amount,
  studentCode,
  semester,
  paying,
  onClose,
  onConfirm,
}: Props) {
  if (!open) return null;

  const transferContent = buildTransferContent(studentCode, semester);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
      <div
        className="card w-full max-w-md p-6 bg-white"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-lg">Thanh toán qua VietQR</h3>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-xl leading-none"
            aria-label="Đóng"
          >
            ×
          </button>
        </div>

        <div className="flex justify-center mb-4">
          <div className="bg-white rounded-xl p-3 border border-slate-200 shadow-sm">
            <Image
              src={PAYMENT_CONFIG.qrImagePath}
              alt="Mã QR thanh toán VietQR"
              width={240}
              height={240}
              className="rounded-lg"
              priority
            />
          </div>
        </div>

        <div className="space-y-2 text-sm mb-5">
          <div className="flex justify-between">
            <span className="text-slate-500">Ngân hàng</span>
            <span className="font-medium text-right">{PAYMENT_CONFIG.bankName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Số tài khoản</span>
            <span className="font-mono font-medium">{PAYMENT_CONFIG.accountNumber}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Chủ tài khoản</span>
            <span className="font-medium text-right">{PAYMENT_CONFIG.accountName}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Số tiền</span>
            <span className="font-bold text-primary-700">{formatVND(amount)}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-slate-500 shrink-0">Nội dung CK</span>
            <span className="font-mono font-medium text-right break-all">{transferContent}</span>
          </div>
        </div>

        <p className="text-xs text-slate-500 mb-4">
          Quét mã QR bằng app ngân hàng (VietQR / Napas 247), kiểm tra số tiền và nội dung chuyển khoản, sau đó bấm xác nhận.
        </p>

        <div className="flex gap-2">
          <button type="button" className="btn-secondary flex-1" onClick={onClose} disabled={paying}>
            Hủy
          </button>
          <button type="button" className="btn-primary flex-1" onClick={onConfirm} disabled={paying}>
            {paying ? "Đang xử lý..." : "Đã chuyển khoản"}
          </button>
        </div>
      </div>
    </div>
  );
}

"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell, Alert, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";

type Enrollment = {
  id: string;
  section: { id: string; schedule: string; course: { id: string; code: string; name: string } };
};

type AltSection = { id: string; schedule: string; room: string | null; enrolledCount: number; capacity: number };

type SemesterOption = { plannedSemester: string; label: string };

export function ChangeSectionPage({ user }: { user: SessionUser }) {
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [alternatives, setAlternatives] = useState<Record<string, AltSection[]>>({});
  const [semesterOptions, setSemesterOptions] = useState<SemesterOption[]>([]);
  const [selectedPlanned, setSelectedPlanned] = useState("Y3_HK1");
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ text: string; type: "error" | "success" } | null>(null);

  const nav = navLinksForRole(user.role);

  const load = useCallback(async (planned: string) => {
    setLoading(true);
    const res = await fetch(`/api/student/enroll?planned=${encodeURIComponent(planned)}`);
    const data = await res.json();
    if (res.ok) {
      setEnrollments(data.myEnrollments);
      setSemesterOptions(data.semesterOptions ?? []);
      setSelectedPlanned(data.registration.plannedSemester);
      const alts: Record<string, AltSection[]> = {};
      for (const e of data.myEnrollments as Enrollment[]) {
        const sameCourse = (data.sections as { id: string; course: { id: string }; schedule: string; room: string | null; enrolledCount: number; capacity: number }[])
          .filter((s) => s.course.id === e.section.course.id && s.id !== e.section.id);
        alts[e.id] = sameCourse;
      }
      setAlternatives(alts);
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(selectedPlanned); }, [load, selectedPlanned]);

  async function changeSection(enrollmentId: string, newSectionId: string) {
    setMessage(null);
    const res = await fetch("/api/student/change-section", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ enrollmentId, newSectionId }),
    });
    const data = await res.json();
    if (res.ok) { setMessage({ text: "Đổi lớp thành công!", type: "success" }); load(selectedPlanned); }
    else setMessage({ text: data.error, type: "error" });
  }

  async function drop(id: string) {
    const res = await fetch(`/api/student/enroll?id=${id}`, { method: "DELETE" });
    if (res.ok) { setMessage({ text: "Đã hủy đăng ký", type: "success" }); load(selectedPlanned); }
  }

  return (
    <AppShell user={user} title="Sinh viên — Hủy/Đổi lớp học phần" nav={nav}>
      {message && <Alert message={message.text} type={message.type} />}
      <p className="text-sm text-slate-600 mb-4">Hủy hoặc đổi sang lớp khác cùng học phần (Actor: Sinh viên)</p>
      <div className="card p-4 mb-4">
        <label htmlFor="change-semester" className="block text-sm font-medium text-slate-600 mb-1">
          Chọn học kỳ
        </label>
        <select
          id="change-semester"
          className="input min-w-[220px]"
          value={selectedPlanned}
          onChange={(e) => { setMessage(null); setSelectedPlanned(e.target.value); }}
        >
          {semesterOptions.map((opt) => (
            <option key={opt.plannedSemester} value={opt.plannedSemester}>{opt.label}</option>
          ))}
        </select>
      </div>
      {loading ? <p>Đang tải...</p> : enrollments.length === 0 ? (
        <div className="card p-8 text-center text-slate-500">Chưa có lớp đăng ký trong kỳ này</div>
      ) : (
        <div className="space-y-4">
          {enrollments.map((e) => (
            <div key={e.id} className="card p-4">
              <div className="flex justify-between items-start mb-3">
                <div>
                  <span className="font-mono font-semibold">{e.section.course.code}</span>
                  <p className="font-medium">{e.section.course.name}</p>
                  <p className="text-sm text-slate-500">Lớp hiện tại: {e.section.schedule}</p>
                </div>
                <button className="btn-danger text-sm" onClick={() => drop(e.id)}>Hủy đăng ký</button>
              </div>
              {(alternatives[e.id] ?? []).length > 0 && (
                <div>
                  <p className="text-xs text-slate-500 mb-2">Đổi sang lớp khác:</p>
                  <div className="flex flex-wrap gap-2">
                    {alternatives[e.id].map((alt) => (
                      <button key={alt.id} className="btn-secondary text-xs" disabled={alt.enrolledCount >= alt.capacity}
                        onClick={() => changeSection(e.id, alt.id)}>
                        {alt.schedule} · {alt.room || "—"} ({alt.enrolledCount}/{alt.capacity})
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}

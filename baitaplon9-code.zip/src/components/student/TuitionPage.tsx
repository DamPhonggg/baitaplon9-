"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell, Alert, Badge } from "@/components/AppShell";
import { QRPaymentModal } from "@/components/student/QRPaymentModal";
import { SessionUser, navLinksForRole } from "@/lib/types";
import { DEFAULT_PLANNED_SEMESTER } from "@/lib/enrollment-rules";
import { formatVND } from "@/lib/tuition";
import { buildTransferContent } from "@/lib/payment-config";

type SemesterOption = { plannedSemester: string; label: string; sectionSemester: string };

type Invoice = {
  id: string;
  semester: string;
  tuitionCredits: number;
  totalAmount: number;
  status: string;
  note: string | null;
  payments: { method: string; reference: string | null; paidAt: string; amount: number }[];
};

export function StudentTuitionPage({ user }: { user: SessionUser }) {
  const [semesterOptions, setSemesterOptions] = useState<SemesterOption[]>([]);
  const [selectedPlanned, setSelectedPlanned] = useState(DEFAULT_PLANNED_SEMESTER);
  const [label, setLabel] = useState("");
  const [sectionSemester, setSectionSemester] = useState("");
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [totalPaid, setTotalPaid] = useState(0);
  const [ratePerCredit, setRatePerCredit] = useState(500_000);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ text: string; type: "error" | "success" } | null>(null);
  const [payingInvoiceId, setPayingInvoiceId] = useState<string | null>(null);

  const nav = navLinksForRole(user.role);

  const load = useCallback(async (planned: string) => {
    setLoading(true);
    const res = await fetch(`/api/student/tuition?planned=${encodeURIComponent(planned)}`);
    const data = await res.json();
    if (res.ok) {
      setSemesterOptions(data.semesterOptions ?? []);
      setSelectedPlanned(data.plannedSemester);
      setLabel(data.label);
      setSectionSemester(data.sectionSemester);
      setInvoice(data.invoice);
      setTotalPaid(data.totalPaid ?? 0);
      setRatePerCredit(data.ratePerCredit ?? 500_000);
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(selectedPlanned); }, [load, selectedPlanned]);

  async function confirmQrPayment() {
    if (!payingInvoiceId) return;
    const inv = invoice?.id === payingInvoiceId ? invoice : null;
    if (!inv) return;

    setMessage(null);
    const reference = buildTransferContent(user.studentCode, inv.semester);
    const res = await fetch("/api/student/tuition", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ invoiceId: payingInvoiceId, method: "VIETQR", reference }),
    });
    const data = await res.json();
    if (res.ok) {
      setMessage({ text: "Thanh toán VietQR thành công!", type: "success" });
      setPayingInvoiceId(null);
      load(selectedPlanned);
    } else {
      setMessage({ text: data.error, type: "error" });
    }
  }

  const semesterPaid = invoice?.payments.reduce((s, p) => s + p.amount, 0) ?? 0;

  return (
    <AppShell user={user} title="Sinh viên — Thanh toán học phí" nav={nav}>
      {message && <Alert message={message.text} type={message.type} />}

      <div className="card p-4 mb-4 bg-primary-50 border-primary-200">
        <p className="text-sm text-amber-900/70">Tổng tiền đã thanh toán (tất cả học kỳ)</p>
        <p className="text-3xl font-bold text-primary-700">{formatVND(totalPaid)}</p>
      </div>

      <div className="card p-4 mb-6">
        <label htmlFor="tuition-semester" className="label">Chọn học kỳ</label>
        <select
          id="tuition-semester"
          className="input max-w-xs font-semibold"
          value={selectedPlanned}
          onChange={(e) => { setMessage(null); setSelectedPlanned(e.target.value); }}
        >
          {(semesterOptions.length > 0 ? semesterOptions : [{ plannedSemester: selectedPlanned, label, sectionSemester }]).map((opt) => (
            <option key={opt.plannedSemester} value={opt.plannedSemester}>{opt.label}</option>
          ))}
        </select>
        {sectionSemester && (
          <p className="text-sm text-amber-800/70 mt-1">
            Kỳ hệ thống: {sectionSemester.replace(/_/g, " ")}
          </p>
        )}
      </div>

      {loading ? (
        <p className="text-amber-800/70">Đang tải...</p>
      ) : !invoice || invoice.totalAmount === 0 ? (
        <div className="card p-8 text-center text-amber-800/70">
          Chưa có học phí cho kỳ <strong>{label}</strong>.
          <p className="text-sm mt-2">Đăng ký học phần trong kỳ này để hệ thống tính học phí.</p>
        </div>
      ) : (
        <div className="card p-5">
          <div className="flex flex-wrap justify-between items-start gap-3">
            <div>
              <p className="text-sm text-amber-800/70">{label}</p>
              <p className="text-2xl font-bold text-primary-700 mt-1">{formatVND(invoice.totalAmount)}</p>
              <p className="text-xs text-amber-700/60 mt-1">
                {invoice.tuitionCredits} tín học phí × {formatVND(ratePerCredit)}/TC
              </p>
              {invoice.note && <p className="text-xs text-amber-700/60 mt-1">{invoice.note}</p>}
            </div>
            <Badge color={invoice.status === "PAID" ? "green" : "yellow"}>
              {invoice.status === "PAID" ? "Đã thanh toán" : "Chưa thanh toán"}
            </Badge>
          </div>

          {semesterPaid > 0 && (
            <p className="text-sm text-emerald-700 mt-3">
              Đã thanh toán kỳ này: <strong>{formatVND(semesterPaid)}</strong>
            </p>
          )}

          {invoice.status !== "PAID" && invoice.totalAmount > 0 && (
            <div className="flex gap-2 mt-4">
              <button className="btn-primary text-sm" onClick={() => setPayingInvoiceId(invoice.id)}>
                Thanh toán qua mã QR
              </button>
            </div>
          )}

          {invoice.payments.length > 0 && (
            <div className="mt-4 pt-4 border-t border-amber-100">
              <h4 className="text-xs font-semibold text-amber-800/70 mb-2">Lịch sử thanh toán kỳ này</h4>
              {invoice.payments.map((p, i) => (
                <p key={i} className="text-xs text-emerald-700">
                  {new Date(p.paidAt).toLocaleDateString("vi-VN")} — {formatVND(p.amount)} — {p.method} — {p.reference}
                </p>
              ))}
            </div>
          )}
        </div>
      )}

      <QRPaymentModal
        open={!!payingInvoiceId}
        amount={invoice?.totalAmount ?? 0}
        studentCode={user.studentCode}
        semester={invoice?.semester ?? ""}
        paying={false}
        onClose={() => setPayingInvoiceId(null)}
        onConfirm={confirmQrPayment}
      />
    </AppShell>
  );
}

"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";
import { gradeFormulaLabel } from "@/lib/grades";
import { DEFAULT_PLANNED_SEMESTER } from "@/lib/enrollment-rules";

type SemesterOption = { plannedSemester: string; label: string; sectionSemester: string };

type ClassItem = {
  enrollmentId: string;
  status: string;
  gradeCC1: number | null;
  gradeCC2: number | null;
  gradeGK: number | null;
  gradeCK: number | null;
  finalGrade: number | null;
  section: {
    id: string;
    semester: string;
    schedule: string;
    room: string | null;
    course: { code: string; name: string; credits: number };
    professor: { name: string; email: string } | null;
  };
};

export function StudentClassesPage({ user }: { user: SessionUser }) {
  const [semesterOptions, setSemesterOptions] = useState<SemesterOption[]>([]);
  const [selectedPlanned, setSelectedPlanned] = useState(DEFAULT_PLANNED_SEMESTER);
  const [data, setData] = useState<{
    label: string;
    semester: string;
    classes: ClassItem[];
    totalCredits: number;
  } | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async (planned: string) => {
    setLoading(true);
    const res = await fetch(`/api/student/classes?planned=${encodeURIComponent(planned)}`);
    const json = await res.json();
    if (res.ok) {
      setData(json);
      setSemesterOptions(json.semesterOptions ?? []);
      setSelectedPlanned(json.plannedSemester);
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(selectedPlanned); }, [load, selectedPlanned]);

  return (
    <AppShell user={user} title="Sinh viên — Lớp học của tôi" nav={navLinksForRole(user.role)}>
      <div className="card p-4 mb-6">
        <label htmlFor="classes-semester" className="label">Chọn học kỳ</label>
        <select
          id="classes-semester"
          className="input max-w-xs font-semibold"
          value={selectedPlanned}
          onChange={(e) => setSelectedPlanned(e.target.value)}
        >
          {(semesterOptions.length > 0 ? semesterOptions : [{ plannedSemester: selectedPlanned, label: data?.label ?? "", sectionSemester: data?.semester ?? "" }]).map((opt) => (
            <option key={opt.plannedSemester} value={opt.plannedSemester}>{opt.label}</option>
          ))}
        </select>
        {data && (
          <p className="text-sm text-amber-800/70 mt-1">
            Kỳ hệ thống: {data.semester.replace(/_/g, " ")}
          </p>
        )}
      </div>

      {data && (
        <div className="card p-4 mb-6 flex flex-wrap justify-between gap-3">
          <div>
            <h2 className="font-semibold">{data.label}</h2>
            <p className="text-sm text-amber-800/70">{data.semester.replace(/_/g, " ")}</p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-primary-700">{data.classes.length} lớp</p>
            <p className="text-xs text-slate-500">{data.totalCredits} tín chỉ</p>
          </div>
        </div>
      )}

      {loading ? (
        <p className="text-slate-500">Đang tải...</p>
      ) : !data || data.classes.length === 0 ? (
        <div className="card p-8 text-center text-slate-500">
          Chưa đăng ký lớp nào trong kỳ này. Vào <strong>Đăng ký học phần</strong> để chọn lớp.
        </div>
      ) : (
        <div className="space-y-4">
          {data.classes.map((c) => (
            <div key={c.enrollmentId} className="card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono font-semibold text-primary-700">{c.section.course.code}</span>
                    <Badge color="blue">{c.section.course.credits} TC</Badge>
                    <Badge color={c.status === "COMPLETED" ? "green" : "yellow"}>
                      {c.status === "COMPLETED" ? "Đã có điểm" : "Đang học"}
                    </Badge>
                  </div>
                  <p className="font-medium mt-1">{c.section.course.name}</p>
                </div>
                {c.finalGrade != null && (
                  <div className="text-right">
                    <p className="text-xs text-slate-500">ĐHP</p>
                    <p className="text-2xl font-bold text-primary-700">{c.finalGrade.toFixed(1)}</p>
                  </div>
                )}
              </div>

              <div className="grid sm:grid-cols-2 gap-2 text-sm text-slate-600">
                <p>Lịch: {c.section.schedule}</p>
                <p>Phòng: {c.section.room || "—"}</p>
                <p>Giảng viên: {c.section.professor?.name || "Chưa phân công"}</p>
                <p>Học kỳ: {c.section.semester.replace(/_/g, " ")}</p>
              </div>

              {(c.gradeCC1 != null || c.gradeGK != null) && (
                <div className="mt-4 pt-3 border-t border-slate-100">
                  <p className="text-xs text-slate-500 mb-2">{gradeFormulaLabel()}</p>
                  <div className="flex flex-wrap gap-3 text-sm">
                    <span>CC1: {c.gradeCC1?.toFixed(1) ?? "—"}</span>
                    <span>CC2: {c.gradeCC2?.toFixed(1) ?? "—"}</span>
                    <span>GK: {c.gradeGK?.toFixed(1) ?? "—"}</span>
                    <span>CK: {c.gradeCK?.toFixed(1) ?? "—"}</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}

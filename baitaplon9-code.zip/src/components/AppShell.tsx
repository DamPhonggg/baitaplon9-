"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { SessionUser } from "@/lib/types";
import { ROLE_LABELS } from "@/lib/types";

type Props = {
  user: SessionUser;
  children: React.ReactNode;
  nav: { href: string; label: string }[];
  title: string;
};

export function AppShell({ user, children, nav, title }: Props) {
  const router = useRouter();

  async function logout() {
    await fetch("/api/auth/login", { method: "DELETE" });
    router.push("/login");
    router.refresh();
  }

  const roleLabel = ROLE_LABELS[user.role] ?? user.role;

  return (
    <div className="min-h-screen flex flex-col bg-amber-50">
      <header className="bg-white border-b border-amber-200 sticky top-0 z-10 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div>
            <h1 className="font-bold text-primary-700">{title}</h1>
            <p className="text-xs text-amber-700/70">
              {user.name} · {roleLabel}
              {user.studentCode && ` · ${user.studentCode}`}
            </p>
          </div>
          <button onClick={logout} className="btn-secondary text-sm">
            Đăng xuất
          </button>
        </div>
        <nav className="max-w-6xl mx-auto px-4 flex gap-1 pb-0">
          {nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="px-4 py-2 text-sm font-medium text-amber-800/80 hover:text-primary-700 border-b-2 border-transparent hover:border-primary-400"
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </header>
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-6">{children}</main>
    </div>
  );
}

export function Alert({ message, type = "error" }: { message: string; type?: "error" | "success" }) {
  const styles = type === "error" ? "bg-red-50 border-red-200 text-red-700" : "bg-primary-50 border-primary-200 text-primary-800";
  return <div className={`text-sm border rounded-lg px-4 py-3 mb-4 ${styles}`}>{message}</div>;
}

export function Badge({ children, color = "blue" }: { children: React.ReactNode; color?: string }) {
  const colors: Record<string, string> = {
    blue: "bg-amber-100 text-amber-900",
    green: "bg-emerald-100 text-emerald-800",
    yellow: "bg-primary-100 text-primary-800",
    gray: "bg-amber-50 text-amber-800 border border-amber-100",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${colors[color] || colors.blue}`}>
      {children}
    </span>
  );
}

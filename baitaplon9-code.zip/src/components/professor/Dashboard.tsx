"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { AppShell, Alert, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";
import { calculateCourseGrade, gradeFormulaLabel } from "@/lib/grades";
import { DEFAULT_PLANNED_SEMESTER } from "@/lib/enrollment-rules";

type Section = {
  id: string;
  schedule: string;
  room: string | null;
  course: { code: string; name: string; credits: number };
  _count?: { enrollments: number };
};

type Enrollment = {
  id: string;
  grade: number | null;
  gradeCC1: number | null;
  gradeCC2: number | null;
  gradeGK: number | null;
  gradeCK: number | null;
  student: { id: string; name: string; studentCode: string | null };
};

type GradeRow = {
  cc1: string;
  cc2: string;
  gk: string;
  ck: string;
};

const EMPTY_ROW: GradeRow = { cc1: "", cc2: "", gk: "", ck: "" };

function parseScore(value: string): number | null {
  if (value.trim() === "") return null;
  const n = parseFloat(value);
  return Number.isNaN(n) ? null : n;
}

function rowFromEnrollment(e: Enrollment): GradeRow {
  return {
    cc1: e.gradeCC1?.toString() ?? "",
    cc2: e.gradeCC2?.toString() ?? "",
    gk: e.gradeGK?.toString() ?? "",
    ck: e.gradeCK?.toString() ?? "",
  };
}

type SemesterOption = { plannedSemester: string; label: string; sectionSemester: string };

export function ProfessorDashboard({ user }: { user: SessionUser }) {
  const [available, setAvailable] = useState<Section[]>([]);
  const [teaching, setTeaching] = useState<Section[]>([]);
  const [semesterOptions, setSemesterOptions] = useState<SemesterOption[]>([]);
  const [selectedPlanned, setSelectedPlanned] = useState(DEFAULT_PLANNED_SEMESTER);
  const [registrationLabel, setRegistrationLabel] = useState("");
  const [sectionSemester, setSectionSemester] = useState("");
  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [grades, setGrades] = useState<Record<string, GradeRow>>({});
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ text: string; type: "error" | "success" } | null>(null);

  const loadSections = useCallback(async (planned: string) => {
    setLoading(true);
    const res = await fetch(`/api/professor/sections?planned=${encodeURIComponent(planned)}`);
    const data = await res.json();
    if (res.ok) {
      setAvailable(data.available);
      setTeaching(data.teaching);
      setSemesterOptions(data.semesterOptions ?? []);
      setSelectedPlanned(data.plannedSemester);
      setRegistrationLabel(data.label);
      setSectionSemester(data.semester);
      setSelectedSection(null);
      setEnrollments([]);
      setGrades({});
    }
    setLoading(false);
  }, []);

  useEffect(() => { loadSections(selectedPlanned); }, [loadSections, selectedPlanned]);

  function handleSemesterChange(planned: string) {
    setMessage(null);
    setSelectedPlanned(planned);
  }

  async function selectSection(sectionId: string) {
    setMessage(null);
    const res = await fetch("/api/professor/sections", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sectionId, plannedSemester: selectedPlanned }),
    });
    const data = await res.json();
    if (res.ok) {
      setMessage({ text: "Đã chọn môn dạy!", type: "success" });
      loadSections(selectedPlanned);
    } else {
      setMessage({ text: data.error, type: "error" });
    }
  }

  async function loadStudents(sectionId: string) {
    setSelectedSection(sectionId);
    const res = await fetch(`/api/professor/grades?sectionId=${sectionId}`);
    const data = await res.json();
    if (res.ok) {
      setEnrollments(data.enrollments);
      const g: Record<string, GradeRow> = {};
      data.enrollments.forEach((e: Enrollment) => {
        g[e.id] = rowFromEnrollment(e);
      });
      setGrades(g);
    }
  }

  function updateGrade(enrollmentId: string, field: keyof GradeRow, value: string) {
    setGrades((prev) => ({
      ...prev,
      [enrollmentId]: { ...prev[enrollmentId], [field]: value },
    }));
  }

  const computedGrades = useMemo(() => {
    const result: Record<string, number | null> = {};
    for (const [id, row] of Object.entries(grades)) {
      result[id] = calculateCourseGrade({
        cc1: parseScore(row.cc1),
        cc2: parseScore(row.cc2),
        gk: parseScore(row.gk),
        ck: parseScore(row.ck),
      });
    }
    return result;
  }, [grades]);

  async function submitGrades() {
    if (!selectedSection) return;
    setMessage(null);

    const gradeList = Object.entries(grades).map(([enrollmentId, row]) => ({
      enrollmentId,
      cc1: parseScore(row.cc1),
      cc2: parseScore(row.cc2),
      gk: parseScore(row.gk),
      ck: parseScore(row.ck),
    }));

    const res = await fetch("/api/professor/grades", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sectionId: selectedSection, grades: gradeList }),
    });
    const data = await res.json();
    if (res.ok) {
      setMessage({ text: "Đã lưu điểm thành công!", type: "success" });
      loadStudents(selectedSection);
    } else {
      setMessage({ text: data.error, type: "error" });
    }
  }

  return (
    <AppShell
      user={user}
      title="Giảng viên — Nhập điểm học phần"
      nav={navLinksForRole(user.role)}
    >
      {message && <Alert message={message.text} type={message.type} />}

      <div className="card p-4 mb-6">
        <label htmlFor="prof-semester" className="label">Chọn học kỳ</label>
        <select
          id="prof-semester"
          className="input max-w-xs font-semibold"
          value={selectedPlanned}
          onChange={(e) => handleSemesterChange(e.target.value)}
        >
          {(semesterOptions.length > 0 ? semesterOptions : [{ plannedSemester: selectedPlanned, label: registrationLabel, sectionSemester }]).map((opt) => (
            <option key={opt.plannedSemester} value={opt.plannedSemester}>{opt.label}</option>
          ))}
        </select>
        {sectionSemester && (
          <p className="text-sm text-amber-800/70 mt-1">
            Kỳ hệ thống: {sectionSemester.replace(/_/g, " ")}
          </p>
        )}
      </div>

      {loading ? (
        <p className="text-slate-500">Đang tải...</p>
      ) : (
        <div className="grid lg:grid-cols-2 gap-6">
          <div>
            <h2 className="text-lg font-semibold mb-3">Lớp đang dạy</h2>
            {teaching.length === 0 ? (
              <div className="card p-4 text-sm text-slate-500">Chưa có lớp nào</div>
            ) : (
              <div className="space-y-2">
                {teaching.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => loadStudents(s.id)}
                    className={`card p-4 w-full text-left hover:border-primary-300 transition-colors ${
                      selectedSection === s.id ? "border-primary-500 ring-1 ring-primary-500" : ""
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-semibold">{s.course.code}</span>
                      <Badge color="green">{s._count?.enrollments ?? 0} SV</Badge>
                    </div>
                    <p className="text-sm">{s.course.name}</p>
                    <p className="text-xs text-slate-500">{s.schedule} · {s.room}</p>
                  </button>
                ))}
              </div>
            )}

            <h2 className="text-lg font-semibold mb-3 mt-6">Lớp có thể nhận dạy</h2>
            {available.length === 0 ? (
              <div className="card p-4 text-sm text-slate-500">Không còn lớp trống</div>
            ) : (
              <div className="space-y-2">
                {available.map((s) => (
                  <div key={s.id} className="card p-4 flex items-center justify-between">
                    <div>
                      <span className="font-mono font-semibold">{s.course.code}</span>
                      <p className="text-sm">{s.course.name}</p>
                      <p className="text-xs text-slate-500">{s.schedule}</p>
                    </div>
                    <button className="btn-primary text-sm" onClick={() => selectSection(s.id)}>
                      Nhận dạy
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <h2 className="text-lg font-semibold mb-2">Nhập điểm thành phần</h2>
            <p className="text-xs text-slate-500 mb-3">{gradeFormulaLabel()}</p>
            {!selectedSection ? (
              <div className="card p-8 text-center text-slate-500">Chọn lớp để nhập điểm</div>
            ) : enrollments.length === 0 ? (
              <div className="card p-8 text-center text-slate-500">Lớp chưa có sinh viên</div>
            ) : (
              <div className="card overflow-x-auto">
                <table className="w-full text-sm min-w-[640px]">
                  <thead className="bg-amber-100 border-b border-amber-200">
                    <tr>
                      <th className="text-left px-3 py-2">MSSV</th>
                      <th className="text-left px-3 py-2">Họ tên</th>
                      <th className="text-center px-2 py-2 w-16">CC1</th>
                      <th className="text-center px-2 py-2 w-16">CC2</th>
                      <th className="text-center px-2 py-2 w-16">GK</th>
                      <th className="text-center px-2 py-2 w-16">CK</th>
                      <th className="text-center px-2 py-2 w-16">ĐHP</th>
                    </tr>
                  </thead>
                  <tbody>
                    {enrollments.map((e) => {
                      const row = grades[e.id] ?? EMPTY_ROW;
                      const finalGrade = computedGrades[e.id];
                      return (
                        <tr key={e.id} className="border-b border-slate-100">
                          <td className="px-3 py-2 font-mono text-xs">{e.student.studentCode}</td>
                          <td className="px-3 py-2">{e.student.name}</td>
                          {(["cc1", "cc2", "gk", "ck"] as const).map((field) => (
                            <td key={field} className="px-2 py-2">
                              <input
                                type="number"
                                min="0"
                                max="10"
                                step="0.1"
                                className="input text-center py-1 px-1 w-full"
                                value={row[field]}
                                onChange={(ev) => updateGrade(e.id, field, ev.target.value)}
                              />
                            </td>
                          ))}
                          <td className="px-2 py-2 text-center font-semibold text-primary-700">
                            {finalGrade != null ? finalGrade.toFixed(1) : "—"}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
                <div className="p-4 border-t">
                  <button className="btn-primary" onClick={submitGrades}>
                    Lưu điểm
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </AppShell>
  );
}

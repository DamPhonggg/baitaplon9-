"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { AppShell, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";
import { DEFAULT_PLANNED_SEMESTER } from "@/lib/enrollment-rules";

type SemesterOption = { plannedSemester: string; label: string; sectionSemester: string };

type TeachingSection = {
  id: string;
  schedule: string;
  room: string | null;
  course: { code: string; name: string; credits: number };
  _count: { enrollments: number };
  enrollments: {
    id: string;
    student: { studentCode: string | null; name: string };
  }[];
};

type AvailableSection = {
  id: string;
  schedule: string;
  room: string | null;
  course: { code: string; name: string; credits: number };
};

export function ProfessorClassesPage({ user }: { user: SessionUser }) {
  const [semesterOptions, setSemesterOptions] = useState<SemesterOption[]>([]);
  const [selectedPlanned, setSelectedPlanned] = useState(DEFAULT_PLANNED_SEMESTER);
  const [label, setLabel] = useState("");
  const [semester, setSemester] = useState("");
  const [teaching, setTeaching] = useState<TeachingSection[]>([]);
  const [available, setAvailable] = useState<AvailableSection[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<string | null>(null);

  const load = useCallback(async (planned: string) => {
    setLoading(true);
    const res = await fetch(`/api/professor/sections?planned=${encodeURIComponent(planned)}`);
    const data = await res.json();
    if (res.ok) {
      setLabel(data.label);
      setSemester(data.semester);
      setSemesterOptions(data.semesterOptions ?? []);
      setSelectedPlanned(data.plannedSemester);
      setTeaching(data.teaching);
      setAvailable(data.available);
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(selectedPlanned); }, [load, selectedPlanned]);

  async function acceptSection(sectionId: string) {
    setMessage(null);
    const res = await fetch("/api/professor/sections", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sectionId, plannedSemester: selectedPlanned }),
    });
    const data = await res.json();
    if (res.ok) {
      setMessage("Đã nhận dạy lớp thành công");
      load(selectedPlanned);
    } else {
      setMessage(data.error);
    }
  }

  return (
    <AppShell user={user} title="Giảng viên — Lớp học" nav={navLinksForRole(user.role)}>
      {message && (
        <div className="text-sm border rounded-lg px-4 py-3 mb-4 bg-green-50 border-green-200 text-green-700">
          {message}
        </div>
      )}

      {label && (
        <div className="card p-4 mb-6">
          <label htmlFor="prof-classes-semester" className="label">Chọn học kỳ</label>
          <select
            id="prof-classes-semester"
            className="input max-w-xs font-semibold mb-1"
            value={selectedPlanned}
            onChange={(e) => { setMessage(null); setSelectedPlanned(e.target.value); }}
          >
            {semesterOptions.map((opt) => (
              <option key={opt.plannedSemester} value={opt.plannedSemester}>{opt.label}</option>
            ))}
          </select>
          <p className="text-sm text-amber-800/70">{semester.replace(/_/g, " ")}</p>
        </div>
      )}

      {loading ? (
        <p className="text-slate-500">Đang tải...</p>
      ) : (
        <div className="grid lg:grid-cols-2 gap-6">
          <div>
            <h3 className="font-semibold mb-3">Lớp đang phụ trách ({teaching.length})</h3>
            {teaching.length === 0 ? (
              <div className="card p-6 text-center text-slate-500 text-sm">Chưa có lớp được phân công</div>
            ) : (
              <div className="space-y-3">
                {teaching.map((s) => (
                  <div key={s.id} className="card p-4">
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <span className="font-mono font-semibold text-primary-700">{s.course.code}</span>
                      <Badge color="green">{s._count.enrollments} SV</Badge>
                    </div>
                    <p className="text-sm font-medium">{s.course.name}</p>
                    <p className="text-xs text-slate-500 mt-1">{s.schedule} · {s.room || "—"}</p>
                    {s.enrollments.length > 0 && (
                      <ul className="mt-3 text-xs text-slate-600 space-y-1 border-t pt-2">
                        {s.enrollments.map((e) => (
                          <li key={e.id}>
                            {e.student.studentCode} — {e.student.name}
                          </li>
                        ))}
                      </ul>
                    )}
                    <Link href="/professor" className="inline-block mt-3 text-sm text-primary-600 hover:underline">
                      Nhập điểm →
                    </Link>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <h3 className="font-semibold mb-3">Lớp chưa có giảng viên ({available.length})</h3>
            {available.length === 0 ? (
              <div className="card p-6 text-center text-slate-500 text-sm">Không còn lớp trống</div>
            ) : (
              <div className="space-y-2">
                {available.map((s) => (
                  <div key={s.id} className="card p-4 flex items-center justify-between gap-3">
                    <div>
                      <span className="font-mono font-semibold">{s.course.code}</span>
                      <p className="text-sm">{s.course.name}</p>
                      <p className="text-xs text-slate-500">{s.schedule}</p>
                    </div>
                    <button className="btn-primary text-sm shrink-0" onClick={() => acceptSection(s.id)}>
                      Nhận dạy
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </AppShell>
  );
}

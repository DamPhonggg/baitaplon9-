"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";
import { CATEGORY_LABELS, CourseCategory } from "@/lib/curriculum-plan";

type SemesterData = {
  key: string;
  label: string;
  credits: number;
  valid: boolean;
  byCategory: Record<CourseCategory, number>;
  courses: { code: string; name: string; credits: number; courseCategory: CourseCategory; knowledgeBlock: string }[];
};

type ScheduleData = {
  semesters: SemesterData[];
  categories: Record<CourseCategory, { count: number; credits: number }>;
  rules: { min: number; max: number };
  allValid: boolean;
};

const CAT_COLOR: Record<CourseCategory, string> = {
  THE_CHAT: "yellow",
  KIEN_THUC: "blue",
  CHUYEN_NGANH: "green",
};

export function SemesterSchedulePage({ user }: { user: SessionUser }) {
  const [data, setData] = useState<ScheduleData | null>(null);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<"semester" | "category">("semester");

  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/curriculum/schedule");
    const json = await res.json();
    if (res.ok) setData(json);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const isRegistrar = user.role === "REGISTRAR";
  const nav = navLinksForRole(user.role);

  return (
    <AppShell user={user} title="Phân chia học kỳ CTĐT" nav={nav}>
      {data && (
        <>
          <div className="grid sm:grid-cols-4 gap-3 mb-6">
            {(Object.keys(CATEGORY_LABELS) as CourseCategory[]).map((cat) => (
              <div key={cat} className="card p-4">
                <Badge color={CAT_COLOR[cat]}>{CATEGORY_LABELS[cat]}</Badge>
                <p className="text-2xl font-bold mt-2">{data.categories[cat].credits} TC</p>
                <p className="text-xs text-slate-500">{data.categories[cat].count} học phần</p>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-3 mb-4">
            <p className="text-sm text-slate-600">
              Quy tắc: <strong>{data.rules.min}–{data.rules.max}</strong> tín chỉ / học kỳ · 4 năm × 3 kỳ
            </p>
            {data.allValid ? (
              <Badge color="green">Tất cả HK hợp lệ</Badge>
            ) : (
              <Badge color="yellow">Có HK cần điều chỉnh</Badge>
            )}
          </div>
        </>
      )}

      {loading ? (
        <p className="text-slate-500">Đang tải...</p>
      ) : !data ? (
        <p className="text-red-600">Không tải được dữ liệu</p>
      ) : (
        <div className="space-y-4">
          {data.semesters.map((sem) => (
            <div key={sem.key} className={`card overflow-hidden ${!sem.valid && sem.courses.length > 0 ? "border-red-300" : ""}`}>
              <div className="flex items-center justify-between px-4 py-3 table-head rounded-t-xl">
                <div>
                  <h3 className="font-semibold">{sem.label}</h3>
                  <p className="text-xs text-slate-300 mt-0.5">
                    Thể chất {sem.byCategory.THE_CHAT} · Kiến thức {sem.byCategory.KIEN_THUC} · Chuyên ngành {sem.byCategory.CHUYEN_NGANH}
                  </p>
                </div>
                <div className="text-right">
                  <span className={`text-lg font-bold ${sem.valid || sem.courses.length === 0 ? "text-green-300" : "text-red-300"}`}>
                    {sem.credits} TC
                  </span>
                  {sem.courses.length > 0 && !sem.valid && (
                    <p className="text-xs text-red-300">Ngoài giới hạn {data.rules.min}–{data.rules.max}</p>
                  )}
                </div>
              </div>

              {sem.courses.length === 0 ? (
                <p className="px-4 py-3 text-sm text-slate-400 italic">Không có học phần (kỳ nghỉ / hoàn thành CTĐT)</p>
              ) : (
                <table className="w-full text-sm">
                  <thead className="bg-amber-100 border-b border-amber-200">
                    <tr>
                      <th className="text-left px-4 py-2">Mã HP</th>
                      <th className="text-left px-4 py-2">Tên học phần</th>
                      <th className="text-center px-4 py-2">Nhóm</th>
                      <th className="text-center px-4 py-2">Khối</th>
                      <th className="text-center px-4 py-2">TC</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sem.courses.map((c) => (
                      <tr key={c.code} className="border-b border-slate-100 hover:bg-slate-50">
                        <td className="px-4 py-2 font-mono text-primary-700">{c.code}</td>
                        <td className="px-4 py-2">{c.name}</td>
                        <td className="px-4 py-2 text-center">
                          <Badge color={CAT_COLOR[c.courseCategory]}>{CATEGORY_LABELS[c.courseCategory]}</Badge>
                        </td>
                        <td className="px-4 py-2 text-center text-slate-500">{c.knowledgeBlock}</td>
                        <td className="px-4 py-2 text-center font-medium">{c.credits}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          ))}
        </div>
      )}
    </AppShell>
  );
}

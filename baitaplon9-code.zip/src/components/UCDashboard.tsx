"use client";

import Link from "next/link";
import { AppShell } from "@/components/AppShell";
import { SessionUser, ucLinksForRole, navLinksForRole, ROLE_LABELS } from "@/lib/types";

export function UCHomePage({ user, title }: { user: SessionUser; title: string }) {
  const links = ucLinksForRole(user.role);
  const groups = links.reduce<Record<string, typeof links>>((acc, link) => {
    if (!acc[link.group]) acc[link.group] = [];
    acc[link.group].push(link);
    return acc;
  }, {});

  return (
    <AppShell user={user} title={title} nav={navLinksForRole(user.role)}>
      <div className="mb-6">
        <h2 className="text-xl font-bold">Chức năng quản lý</h2>
        <p className="text-sm text-slate-500">{ROLE_LABELS[user.role]} — {links.length} chức năng</p>
      </div>
      <div className="grid md:grid-cols-2 gap-6">
        {Object.entries(groups).map(([group, items]) => (
          <div key={group} className="card p-5">
            <h3 className="font-semibold text-primary-700 mb-4">{group}</h3>
            <ul className="space-y-2">
              {items.map((item) => (
                <li key={item.path}>
                  <Link href={item.path} className="flex items-center gap-3 p-3 rounded-lg hover:bg-amber-50 border border-amber-100">
                    <span className="text-sm">{item.name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </AppShell>
  );
}

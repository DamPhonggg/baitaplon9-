"use client";

import { useCallback, useEffect, useState } from "react";
import { AppShell, Alert, Badge } from "@/components/AppShell";
import { SessionUser, navLinksForRole } from "@/lib/types";
import { formatVND } from "@/lib/tuition";

type Invoice = {
  id: string; semester: string; tuitionCredits: number; totalAmount: number; status: string; note: string | null;
  student: { name: string; studentCode: string | null };
};

export function FinanceTuitionPage({ user }: { user: SessionUser }) {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [semester, setSemester] = useState("");
  const [rate, setRate] = useState(500000);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState<{ text: string; type: "error" | "success" } | null>(null);

  const nav = navLinksForRole(user.role);

  const load = useCallback(async () => {
    const res = await fetch("/api/finance/tuition");
    const data = await res.json();
    if (res.ok) { setInvoices(data.invoices); setSemester(data.semester); setRate(data.ratePerCredit); }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function calculateAll() {
    setMessage(null);
    const res = await fetch("/api/finance/tuition", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
    const data = await res.json();
    if (res.ok) { setMessage({ text: `Đã tính học phí cho ${data.count} sinh viên`, type: "success" }); load(); }
    else setMessage({ text: data.error, type: "error" });
  }

  const total = invoices.reduce((s, i) => s + i.totalAmount, 0);
  const paid = invoices.filter((i) => i.status === "PAID").length;

  return (
    <AppShell user={user} title="Phòng Tài chính — Tính học phí theo tín chỉ" nav={nav}>
      {message && <Alert message={message.text} type={message.type} />}
      <p className="text-sm text-slate-600 mb-4">Học phí = Số tín học phí × {formatVND(rate)}/TC · Tự cập nhật khi sinh viên đăng ký</p>
      <div className="flex gap-3 mb-4">
        <button className="btn-primary text-sm" onClick={calculateAll}>Tính học phí tất cả SV</button>
        <span className="text-sm text-slate-500 self-center">Kỳ: {semester?.replace(/_/g, " ")}</span>
      </div>
      <div className="grid grid-cols-3 gap-3 mb-6">
        <div className="card p-3"><p className="text-xs text-slate-500">Tổng hóa đơn</p><p className="text-xl font-bold">{invoices.length}</p></div>
        <div className="card p-3"><p className="text-xs text-slate-500">Đã thanh toán</p><p className="text-xl font-bold text-green-600">{paid}</p></div>
        <div className="card p-3"><p className="text-xs text-slate-500">Tổng tiền</p><p className="text-xl font-bold">{formatVND(total)}</p></div>
      </div>
      {loading ? <p>Đang tải...</p> : (
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="table-head">
              <tr>
                <th className="px-3 py-2 text-left">MSSV</th>
                <th className="px-3 py-2 text-left">Họ tên</th>
                <th className="px-3 py-2 text-center">Tín HP</th>
                <th className="px-3 py-2 text-right">Số tiền</th>
                <th className="px-3 py-2 text-center">TT</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((i) => (
                <tr key={i.id} className="border-b">
                  <td className="px-3 py-2 font-mono">{i.student.studentCode}</td>
                  <td className="px-3 py-2">{i.student.name}</td>
                  <td className="px-3 py-2 text-center">{i.tuitionCredits}</td>
                  <td className="px-3 py-2 text-right font-medium">{formatVND(i.totalAmount)}</td>
                  <td className="px-3 py-2 text-center"><Badge color={i.status === "PAID" ? "green" : "yellow"}>{i.status === "PAID" ? "Đã TT" : "Chưa TT"}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AppShell>
  );
}

export const GRADE_WEIGHTS = {
  cc1: 0.05,
  cc2: 0.05,
  gk: 0.3,
  ck: 0.6,
} as const;

export type GradeComponents = {
  cc1: number | null;
  cc2: number | null;
  gk: number | null;
  ck: number | null;
};

export function validateGradeComponent(score: number) {
  return score >= 0 && score <= 10;
}

export function calculateCourseGrade(components: GradeComponents): number | null {
  const { cc1, cc2, gk, ck } = components;
  if (cc1 == null || cc2 == null || gk == null || ck == null) return null;
  if (![cc1, cc2, gk, ck].every(validateGradeComponent)) return null;

  const raw =
    cc1 * GRADE_WEIGHTS.cc1 +
    cc2 * GRADE_WEIGHTS.cc2 +
    gk * GRADE_WEIGHTS.gk +
    ck * GRADE_WEIGHTS.ck;

  return Math.round(raw * 10) / 10;
}

export function gradeFormulaLabel() {
  return "ĐHP = CC1×5% + CC2×5% + GK×30% + CK×60%";
}

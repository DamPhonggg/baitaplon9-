import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { prisma } from "./db";
import { SessionUser, UserRole } from "./types";

const SESSION_COOKIE = "session_user_id";
const SESSION_MAX_AGE = 60 * 60 * 24 * 7; // 7 days

export type { SessionUser };

export async function login(emailOrCode: string, password: string): Promise<SessionUser | null> {
  const input = emailOrCode.trim();
  const user = await prisma.user.findFirst({
    where: {
      OR: [
        { email: input.toLowerCase() },
        { studentCode: input.toUpperCase() },
      ],
    },
  });
  if (!user) return null;

  const valid = await bcrypt.compare(password, user.passwordHash);
  if (!valid) return null;

  if (user.role === "STUDENT") {
    const planCount = await prisma.studentStudyPlan.count({ where: { studentId: user.id } });
    if (planCount === 0) {
      const courses = await prisma.course.findMany({ select: { id: true } });
      for (const course of courses) {
        await prisma.studentStudyPlan.upsert({
          where: { studentId_courseId: { studentId: user.id, courseId: course.id } },
          create: { studentId: user.id, courseId: course.id, status: "PLANNED" },
          update: {},
        });
      }
    }
  }

  cookies().set(SESSION_COOKIE, user.id, {
    httpOnly: true,
    sameSite: "lax",
    maxAge: SESSION_MAX_AGE,
    path: "/",
  });

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role as UserRole,
    studentCode: user.studentCode,
    department: user.department,
  };
}

export function logout() {
  cookies().delete(SESSION_COOKIE);
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const userId = cookies().get(SESSION_COOKIE)?.value;
  if (!userId) return null;

  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) return null;

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role as UserRole,
    studentCode: user.studentCode,
    department: user.department,
  };
}

export async function requireRole(roles: UserRole[]): Promise<SessionUser> {
  const user = await getSessionUser();
  if (!user) throw new AuthError("Chưa đăng nhập");
  if (!roles.includes(user.role)) throw new AuthError("Không có quyền truy cập");
  return user;
}

export class AuthError extends Error {
  status = 401;
  constructor(message: string) {
    super(message);
    this.name = "AuthError";
  }
}

export function roleDashboard(role: UserRole): string {
  switch (role) {
    case "STUDENT":
      return "/student";
    case "PROFESSOR":
      return "/professor/classes";
    case "REGISTRAR":
      return "/registrar/sections";
    case "FINANCE":
      return "/finance";
  }
}

export function schedulesConflict(a: string, b: string): boolean {
  const parse = (s: string) => {
    const [dayPart, timePart] = s.split(" ");
    const day = dayPart.trim();
    const [start, end] = timePart.split("-").map((t) => t.trim());
    return { day, start, end };
  };

  try {
    const sa = parse(a);
    const sb = parse(b);
    if (sa.day !== sb.day) return false;
    return sa.start < sb.end && sb.start < sa.end;
  } catch {
    return false;
  }
}

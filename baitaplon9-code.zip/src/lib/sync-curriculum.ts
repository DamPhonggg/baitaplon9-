import { prisma } from "@/lib/db";
import { CURRICULUM_CSE, categoryFromBlock, plannedToExpected } from "@/lib/curriculum-plan";

export const KNOWLEDGE_CATEGORIES = [
  { code: "A1", name: "Giáo dục đại cương", groupType: "KIEN_THUC", minCredits: 45, description: "Môn đại cương, chính trị, ngoại ngữ" },
  { code: "B1", name: "Cơ sở ngành", groupType: "KIEN_THUC", minCredits: 40, description: "Kiến thức cơ sở CNTT" },
  { code: "C1", name: "Bổ trợ kinh tế - xã hội", groupType: "KIEN_THUC", minCredits: 5, description: "Quản trị, kinh tế" },
  { code: "C2", name: "Kỹ năng mềm", groupType: "KIEN_THUC", minCredits: 2, description: "Kỹ năng đàm phán" },
  { code: "D1", name: "Chuyên ngành cốt lõi", groupType: "CHUYEN_NGANH", minCredits: 30, description: "Môn chuyên ngành chính" },
  { code: "D2.1", name: "Chuyên ngành tự chọn", groupType: "CHUYEN_NGANH", minCredits: 2, description: "Môn tự chọn" },
  { code: "D2.2", name: "Chuyên ngành tự chọn nâng cao", groupType: "CHUYEN_NGANH", minCredits: 3, description: "Môn tự chọn chuyên sâu" },
  { code: "E1", name: "Thực tập tốt nghiệp", groupType: "CHUYEN_NGANH", minCredits: 4, description: "Thực tập tốt nghiệp" },
  { code: "E2", name: "Đồ án tốt nghiệp", groupType: "CHUYEN_NGANH", minCredits: 10, description: "ĐATN" },
  { code: "F1", name: "Giáo dục quốc phòng - an ninh", groupType: "THE_CHAT", minCredits: 8, description: "GDQP-AN" },
  { code: "F2.1", name: "Thể dục tự chọn — Chạy", groupType: "THE_CHAT", minCredits: 1, description: "Chạy 1" },
  { code: "F2.2", name: "Thể dục tự chọn — Aerobic, bóng chuyền", groupType: "THE_CHAT", minCredits: 1, description: "Aerobic, bóng chuyền" },
  { code: "F2.3", name: "Thể dục tự chọn — Bóng đá, bóng rổ, cầu lông", groupType: "THE_CHAT", minCredits: 1, description: "Bóng đá, bóng rổ, cầu lông" },
  { code: "F3", name: "Ngoại ngữ bổ trợ", groupType: "KIEN_THUC", minCredits: 4, description: "Tiếng Anh bổ trợ" },
  { code: "TC", name: "Giáo dục thể chất", groupType: "THE_CHAT", minCredits: 4, description: "GDTC 1, 2" },
] as const;

export async function syncCurriculumFromSource() {
  for (const cat of KNOWLEDGE_CATEGORIES) {
    await prisma.knowledgeCategory.upsert({
      where: { code: cat.code },
      create: { ...cat },
      update: { name: cat.name, groupType: cat.groupType, minCredits: cat.minCredits, description: cat.description },
    });
  }

  let created = 0;
  let updated = 0;

  for (const item of CURRICULUM_CSE) {
    const data = {
      name: item.name,
      credits: item.credits,
      tuitionCredits: item.tuitionCredits,
      knowledgeBlock: item.knowledgeBlock,
      courseCategory: item.courseCategory ?? categoryFromBlock(item.knowledgeBlock),
      plannedSemester: item.plannedSemester,
      expectedSemester: plannedToExpected(item.plannedSemester),
      prerequisites: item.prerequisites ?? null,
      orderIndex: item.orderIndex,
      department: "CNTT",
    };

    const existing = await prisma.course.findUnique({ where: { code: item.code } });
    if (existing) {
      await prisma.course.update({ where: { code: item.code }, data });
      updated++;
    } else {
      await prisma.course.create({ data: { code: item.code, ...data } });
      created++;
    }
  }

  const students = await prisma.user.findMany({ where: { role: "STUDENT" }, select: { id: true } });
  const courses = await prisma.course.findMany({ select: { id: true } });

  for (const student of students) {
    for (const course of courses) {
      await prisma.studentStudyPlan.upsert({
        where: { studentId_courseId: { studentId: student.id, courseId: course.id } },
        create: { studentId: student.id, courseId: course.id, status: "PLANNED" },
        update: {},
      });
    }
  }

  return {
    total: CURRICULUM_CSE.length,
    created,
    updated,
    categories: KNOWLEDGE_CATEGORIES.length,
  };
}

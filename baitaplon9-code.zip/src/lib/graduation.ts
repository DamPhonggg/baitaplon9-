export const GRADUATION_MIN_CREDITS = 120;
export const GRADUATION_MIN_GPA = 2.0;

export type GraduationCheck = {
  studentId: string;
  studentName: string;
  studentCode: string | null;
  totalCredits: number;
  requiredCredits: number;
  creditsMet: boolean;
  gpa: number;
  minGpa: number;
  gpaMet: boolean;
  completedCourses: number;
  totalCourses: number;
  coursesMet: boolean;
  eligible: boolean;
  missingCourses: { code: string; name: string }[];
};

export function computeGpa(
  records: { grade: number; credits: number }[]
): number {
  if (records.length === 0) return 0;
  const total = records.reduce((s, r) => s + r.grade * r.credits, 0);
  const credits = records.reduce((s, r) => s + r.credits, 0);
  return credits > 0 ? Math.round((total / credits) * 100) / 100 : 0;
}

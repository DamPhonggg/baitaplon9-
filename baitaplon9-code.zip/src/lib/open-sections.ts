import { prisma } from "@/lib/db";
import { CURRICULUM_CSE, plannedToExpected } from "@/lib/curriculum-plan";

function defaultSchedule(orderIndex: number) {
  const day = (orderIndex % 5) + 2;
  const start = 7 + (orderIndex % 3) * 2;
  return `T${day} ${start}:00-${start + 2}:00`;
}

export async function ensureOpenSectionsForCurriculum() {
  const professors = await prisma.user.findMany({
    where: { role: "PROFESSOR" },
    select: { id: true, email: true },
    orderBy: { email: "asc" },
  });
  const profCse = professors[0]?.id ?? null;
  const profOther = professors[1]?.id ?? profCse;

  let created = 0;
  let skipped = 0;

  for (const item of CURRICULUM_CSE) {
    const course = await prisma.course.findUnique({ where: { code: item.code } });
    if (!course) continue;

    const semester = plannedToExpected(item.plannedSemester);
    const existing = await prisma.courseSection.findFirst({
      where: { courseId: course.id, semester },
    });
    if (existing) {
      skipped++;
      continue;
    }

    const professorId = course.code.startsWith("CSE")
      ? profCse
      : course.code.startsWith("FFS") || course.code.startsWith("FEL") || course.code.startsWith("GDTC")
        ? profOther
        : profCse;

    await prisma.courseSection.create({
      data: {
        courseId: course.id,
        professorId,
        semester,
        capacity: 40,
        isOpen: true,
        schedule: defaultSchedule(course.orderIndex),
        room: `A${100 + course.orderIndex}`,
      },
    });
    created++;
  }

  return { created, skipped, total: CURRICULUM_CSE.length };
}

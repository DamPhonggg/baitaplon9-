export type UserRole = "STUDENT" | "PROFESSOR" | "REGISTRAR" | "FINANCE";
export type EnrollmentStatus = "REGISTERED" | "COMPLETED" | "DROPPED";

export type SessionUser = {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  studentCode: string | null;
  department: string | null;
};

export const ROLE_LABELS: Record<UserRole, string> = {
  STUDENT: "Sinh viên",
  PROFESSOR: "Giảng viên",
  REGISTRAR: "Phòng Đào tạo",
  FINANCE: "Phòng Tài chính",
};

export const UC_MODULES = {
  group1: {
    title: "Quản lý Danh mục & Học phần",
    items: [
      { id: "UC1.1", name: "Quản lý danh mục môn học", roles: ["REGISTRAR"] as UserRole[], path: "/registrar/categories" },
      { id: "UC1.2", name: "Thiết lập điều kiện tiên quyết", roles: ["REGISTRAR"] as UserRole[], path: "/registrar/prerequisites" },
      { id: "UC1.3", name: "Xem chương trình đào tạo", roles: ["STUDENT", "PROFESSOR"] as UserRole[], path: "/student/curriculum" },
      { id: "—", name: "Quản lý SV/GV", roles: ["REGISTRAR"] as UserRole[], path: "/registrar/users" },
      { id: "—", name: "Chương trình & Lộ trình", roles: ["REGISTRAR"] as UserRole[], path: "/registrar/curriculum" },
    ],
  },
  group2: {
    title: "Đăng ký tín chỉ",
    items: [
      { id: "UC2.1", name: "Mở lớp học phần dự kiến", roles: ["REGISTRAR"] as UserRole[], path: "/registrar/sections" },
      { id: "UC2.2", name: "Đăng ký học phần trực tuyến", roles: ["STUDENT"] as UserRole[], path: "/student" },
      { id: "UC2.3", name: "Hủy/Đổi lớp học phần", roles: ["STUDENT"] as UserRole[], path: "/student/change-section" },
    ],
  },
  group3: {
    title: "Quản lý Kết quả học tập",
    items: [
      { id: "UC3.1", name: "Nhập điểm học phần", roles: ["PROFESSOR"] as UserRole[], path: "/professor" },
      { id: "UC3.2", name: "Tra cứu điểm tích lũy (GPA)", roles: ["STUDENT"] as UserRole[], path: "/student/report-card" },
      { id: "UC3.3", name: "Xét điều kiện tốt nghiệp", roles: ["REGISTRAR"] as UserRole[], path: "/registrar/graduation" },
    ],
  },
  group4: {
    title: "Quản lý Học phí",
    items: [
      { id: "UC4.1", name: "Tính toán học phí theo tín chỉ", roles: ["FINANCE"] as UserRole[], path: "/finance" },
      { id: "UC4.2", name: "Thanh toán học phí trực tuyến", roles: ["STUDENT"] as UserRole[], path: "/student/tuition" },
    ],
  },
} as const;

export function ucLinksForRole(role: UserRole) {
  const links: { id: string; name: string; path: string; group: string }[] = [];
  for (const [, group] of Object.entries(UC_MODULES)) {
    for (const item of group.items) {
      if (item.roles.includes(role)) {
        const path = role === "PROFESSOR" && item.id === "UC1.3" ? "/professor/curriculum" : item.path;
        links.push({ id: item.id, name: item.name, path, group: group.title });
      }
    }
  }
  return links;
}

const STUDENT_NAV = [
  { href: "/student", label: "Đăng ký học phần" },
  { href: "/student/classes", label: "Lớp học của tôi" },
  { href: "/student/change-section", label: "Hủy/Đổi lớp" },
  { href: "/student/curriculum", label: "Chương trình học" },
  { href: "/student/report-card", label: "Bảng điểm" },
  { href: "/student/tuition", label: "Thanh toán học phí" },
] as const;

const PROFESSOR_NAV = [
  { href: "/professor/classes", label: "Lớp học" },
  { href: "/professor", label: "Nhập điểm" },
  { href: "/professor/curriculum", label: "Chương trình học" },
] as const;

const REGISTRAR_ADMIN_NAV = [
  { href: "/registrar", label: "Tổng quan" },
  { href: "/registrar/categories", label: "Danh mục môn học" },
  { href: "/registrar/prerequisites", label: "Tiên quyết" },
  { href: "/registrar/users", label: "Quản lý SV/GV" },
  { href: "/registrar/curriculum", label: "Chương trình học" },
  { href: "/registrar/schedule", label: "Phân chia học kỳ" },
  { href: "/registrar/graduation", label: "Xét tốt nghiệp" },
  { href: "/registrar/sections", label: "Mở lớp học phần" },
] as const;

const REGISTRAR_SECTIONS_NAV = [
  { href: "/registrar/sections", label: "Mở lớp học phần" },
  { href: "/registrar", label: "Quản lý CTĐT" },
] as const;

export type NavVariant = "sections";

export function navLinksForRole(role: UserRole, variant?: NavVariant): { href: string; label: string }[] {
  if (role === "STUDENT") return [...STUDENT_NAV];
  if (role === "PROFESSOR") return [...PROFESSOR_NAV];
  if (role === "REGISTRAR" && variant === "sections") return [...REGISTRAR_SECTIONS_NAV];
  if (role === "REGISTRAR") return [...REGISTRAR_ADMIN_NAV];
  return ucLinksForRole(role).map((l) => ({ href: l.path, label: l.name }));
}

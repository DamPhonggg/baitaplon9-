import {
  CATEGORY_LABELS,
  MAX_CREDITS_PER_SEMESTER,
  MIN_CREDITS_PER_SEMESTER,
  SEMESTER_LABELS,
  SEMESTER_ORDER,
  plannedToExpected,
} from "./curriculum-plan";
import { prisma } from "./db";

/** Kỳ đăng ký mặc định */
export const DEFAULT_PLANNED_SEMESTER = "Y3_HK1";

export function resolveRegistration(plannedSemester: string) {
  return {
    plannedSemester,
    sectionSemester: plannedToExpected(plannedSemester),
    label: SEMESTER_LABELS[plannedSemester] ?? plannedSemester,
  };
}

/** @deprecated dùng resolveRegistration — giữ cho tương thích */
export const CURRENT_REGISTRATION = resolveRegistration(DEFAULT_PLANNED_SEMESTER);

export function getSemesterOptions() {
  return SEMESTER_ORDER.map((key) => ({
    plannedSemester: key,
    sectionSemester: plannedToExpected(key),
    label: SEMESTER_LABELS[key],
  }));
}

export type EligibilityResult = {
  eligible: boolean;
  reason?: string;
};

/** Trích tên môn từ chuỗi điều kiện: "Tiên quyết(A, B)" → ["A", "B"] */
export function parsePrerequisiteNames(prerequisites?: string | null): string[] {
  if (!prerequisites) return [];
  const names: string[] = [];
  const regex = /\(([^)]+)\)/g;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(prerequisites)) !== null) {
    match[1].split(",").forEach((n) => names.push(n.trim()));
  }
  return names;
}

export function checkPrerequisites(
  prerequisites: string | null | undefined,
  completedCourseNames: Set<string>
): EligibilityResult {
  const required = parsePrerequisiteNames(prerequisites);
  if (required.length === 0) return { eligible: true };

  const missing = required.filter((name) => !completedCourseNames.has(name));
  if (missing.length > 0) {
    return { eligible: false, reason: `Thiếu môn tiên quyết: ${missing.join(", ")}` };
  }
  return { eligible: true };
}

export function checkEnrollmentEligibility(params: {
  studyPlanStatus: string | null;
  registrationPlannedSemester: string;
  coursePlannedSemester: string | null;
  prerequisites: string | null;
  completedCourseNames: Set<string>;
  currentCredits: number;
  courseCredits: number;
  isAlreadyRegistered: boolean;
  isCompleted: boolean;
  capacityFull: boolean;
}): EligibilityResult {
  const {
    studyPlanStatus,
    registrationPlannedSemester,
    coursePlannedSemester,
    prerequisites,
    completedCourseNames,
    currentCredits,
    courseCredits,
    isAlreadyRegistered,
    isCompleted,
    capacityFull,
  } = params;

  if (!studyPlanStatus) {
    return { eligible: false, reason: "Không có trong CTĐT" };
  }
  if (isCompleted || studyPlanStatus === "COMPLETED") {
    return { eligible: false, reason: "Đã hoàn thành môn này" };
  }
  if (coursePlannedSemester !== registrationPlannedSemester) {
    const semLabel = coursePlannedSemester
      ? SEMESTER_LABELS[coursePlannedSemester] ?? coursePlannedSemester
      : "—";
    return { eligible: false, reason: `Dự kiến học kỳ ${semLabel}, không phải kỳ đang chọn` };
  }
  if (isAlreadyRegistered) {
    return { eligible: false, reason: "Đã đăng ký" };
  }
  if (capacityFull) {
    return { eligible: false, reason: "Lớp đã đầy" };
  }

  const prereq = checkPrerequisites(prerequisites, completedCourseNames);
  if (!prereq.eligible) return prereq;

  if (currentCredits + courseCredits > MAX_CREDITS_PER_SEMESTER) {
    return {
      eligible: false,
      reason: `Vượt quá ${MAX_CREDITS_PER_SEMESTER} tín chỉ/kỳ (hiện ${currentCredits} TC)`,
    };
  }

  return { eligible: true };
}

export { CATEGORY_LABELS, MIN_CREDITS_PER_SEMESTER, MAX_CREDITS_PER_SEMESTER, SEMESTER_ORDER, SEMESTER_LABELS };

export async function getCompletedCourseNames(studentId: string): Promise<Set<string>> {
  const [completedPlans, completedEnrollments] = await Promise.all([
    prisma.studentStudyPlan.findMany({
      where: { studentId, status: "COMPLETED" },
      include: { course: { select: { name: true } } },
    }),
    prisma.enrollment.findMany({
      where: { studentId, status: "COMPLETED", grade: { not: null } },
      include: { section: { include: { course: { select: { name: true } } } } },
    }),
  ]);
  const names = new Set<string>();
  completedPlans.forEach((p) => names.add(p.course.name));
  completedEnrollments.forEach((e) => names.add(e.section.course.name));
  return names;
}

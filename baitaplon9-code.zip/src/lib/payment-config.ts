export const PAYMENT_CONFIG = {
  bankName: "Ngân hàng TMCP Quân đội (MBBank)",
  accountNumber: "0123456789",
  accountName: "TRUONG DAI HOC DEMO",
  qrImagePath: "/vietqr-payment.png",
} as const;

export function buildTransferContent(studentCode: string | null, semester: string) {
  const code = studentCode || "SV";
  const term = semester.replace(/_/g, "");
  return `HP ${code} ${term}`.slice(0, 25);
}

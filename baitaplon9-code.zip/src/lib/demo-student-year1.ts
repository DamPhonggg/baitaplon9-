import { calculateCourseGrade } from "@/lib/grades";
import { prisma } from "@/lib/db";
import { plannedToExpected } from "@/lib/curriculum-plan";

/** SV001 — đã hoàn thành 3 kỳ Năm 1, mỗi kỳ 13 tín chỉ, ĐHP = 6.5 */
export const SV1_YEAR1_SEMESTERS: Record<string, string[]> = {
  Y1_HK1: [
    "FFS702001", // 2
    "FEL702075", // 2
    "GDTC702001", // 2
    "CSE703107", // 3
    "CSE703024", // 3
    "FFS701072", // 1 — Chạy 1
  ],
  Y1_HK2: [
    "FFS703013", // 3
    "FFS703007", // 3
    "FEL703076", // 3
    "FEL704000", // 4
  ],
  Y1_HK3: [
    "FEL703077", // 3
    "CSE703006", // 3
    "GDTC702002", // 2
    "CSE703029", // 3
    "CSE702106", // 2
  ],
};

export const DEMO_FINAL_GRADE = 6.5;

export function demoGradeComponents(finalGrade = DEMO_FINAL_GRADE) {
  return {
    gradeCC1: finalGrade,
    gradeCC2: finalGrade,
    gradeGK: finalGrade,
    gradeCK: finalGrade,
    grade: calculateCourseGrade({
      cc1: finalGrade,
      cc2: finalGrade,
      gk: finalGrade,
      ck: finalGrade,
    }),
  };
}

export async function setupSv1Year1Completed(studentEmail = "sv1@university.edu") {
  const student = await prisma.user.findFirst({
    where: { OR: [{ email: studentEmail }, { studentCode: "SV001" }], role: "STUDENT" },
  });
  if (!student) throw new Error(`Không tìm thấy sinh viên ${studentEmail}`);

  await prisma.enrollment.deleteMany({ where: { studentId: student.id } });
  await prisma.tuitionPayment.deleteMany({ where: { invoice: { studentId: student.id } } });
  await prisma.tuitionInvoice.deleteMany({ where: { studentId: student.id } });

  await prisma.studentStudyPlan.updateMany({
    where: { studentId: student.id },
    data: { status: "PLANNED", actualSemester: null },
  });

  const grades = demoGradeComponents();
  let enrollmentCount = 0;
  let creditTotal = 0;

  for (const [plannedSemester, codes] of Object.entries(SV1_YEAR1_SEMESTERS)) {
    const sectionSemester = plannedToExpected(plannedSemester);

    for (const code of codes) {
      const course = await prisma.course.findUnique({ where: { code } });
      if (!course) throw new Error(`Không tìm thấy HP ${code}`);

      creditTotal += course.credits;

      let section = await prisma.courseSection.findFirst({
        where: { courseId: course.id, semester: sectionSemester },
      });
      if (!section && course.plannedSemester) {
        section = await prisma.courseSection.findFirst({
          where: {
            courseId: course.id,
            semester: plannedToExpected(course.plannedSemester),
          },
        });
      }
      if (!section) {
        throw new Error(`Chưa có lớp cho ${code}. Chạy: npm run db:open-sections`);
      }

      if (!section.professorId) {
        const prof = await prisma.user.findFirst({ where: { role: "PROFESSOR" } });
        if (prof) {
          section = await prisma.courseSection.update({
            where: { id: section.id },
            data: { professorId: prof.id },
          });
        }
      }

      await prisma.enrollment.create({
        data: {
          studentId: student.id,
          sectionId: section.id,
          status: "COMPLETED",
          ...grades,
        },
      });

      await prisma.studentStudyPlan.update({
        where: { studentId_courseId: { studentId: student.id, courseId: course.id } },
        data: { status: "COMPLETED", actualSemester: sectionSemester },
      });

      enrollmentCount++;
    }
  }

  return {
    studentEmail: student.email,
    studentCode: student.studentCode,
    enrollmentCount,
    creditTotal,
    gpa: DEMO_FINAL_GRADE,
  };
}

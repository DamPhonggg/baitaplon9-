export {
  CATEGORY_LABELS,
  SEMESTER_LABELS,
  SEMESTER_ORDER,
  MIN_CREDITS_PER_SEMESTER,
  MAX_CREDITS_PER_SEMESTER,
  CURRICULUM_CSE,
  KNOWLEDGE_BLOCKS,
  buildSemesterPlan,
  buildCategorySummary,
  plannedToExpected,
  categoryFromBlock,
} from "../../prisma/curriculum-data";

export type { CurriculumItem, CourseCategory, SemesterSummary } from "../../prisma/curriculum-data";

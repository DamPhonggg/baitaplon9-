import { prisma } from "./db";
import { GRADUATION_MIN_CREDITS, GRADUATION_MIN_GPA } from "./graduation";

export { GRADUATION_MIN_CREDITS, GRADUATION_MIN_GPA };

export const TUITION_RATE_PER_CREDIT = 500_000; // VND

export function calculateTuition(tuitionCredits: number, rate = TUITION_RATE_PER_CREDIT) {
  return tuitionCredits * rate;
}

export function formatVND(amount: number) {
  return new Intl.NumberFormat("vi-VN", { style: "currency", currency: "VND" }).format(amount);
}

export async function syncTuitionInvoice(studentId: string, semester: string) {
  const enrollments = await prisma.enrollment.findMany({
    where: { studentId, status: "REGISTERED", section: { semester } },
    include: { section: { include: { course: true } } },
  });

  const tuitionCredits = enrollments.reduce((s, e) => s + e.section.course.tuitionCredits, 0);
  const totalAmount = calculateTuition(tuitionCredits);

  const existing = await prisma.tuitionInvoice.findUnique({
    where: { studentId_semester: { studentId, semester } },
    include: { payments: true },
  });

  const paidAmount = existing?.payments.reduce((s, p) => s + p.amount, 0) ?? 0;
  const status =
    totalAmount > 0 && paidAmount >= totalAmount ? "PAID" : "UNPAID";

  return prisma.tuitionInvoice.upsert({
    where: { studentId_semester: { studentId, semester } },
    create: {
      studentId,
      semester,
      tuitionCredits,
      amountPerCredit: TUITION_RATE_PER_CREDIT,
      totalAmount,
      status,
      note: `${enrollments.length} học phần đăng ký`,
    },
    update: {
      tuitionCredits,
      totalAmount,
      status,
      note: `${enrollments.length} học phần đăng ký`,
    },
  });
}

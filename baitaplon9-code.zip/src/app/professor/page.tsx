import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { ProfessorDashboard } from "@/components/professor/Dashboard";

export default async function ProfessorPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "PROFESSOR") redirect("/");

  return <ProfessorDashboard user={user} />;
}

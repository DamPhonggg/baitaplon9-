import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { SemesterSchedulePage } from "@/components/curriculum/SemesterSchedulePage";

export default async function ProfessorCurriculumPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "PROFESSOR") redirect("/");
  return <SemesterSchedulePage user={user} />;
}

import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { ProfessorClassesPage } from "@/components/professor/ClassesPage";

export default async function Page() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "PROFESSOR") redirect("/");
  return <ProfessorClassesPage user={user} />;
}

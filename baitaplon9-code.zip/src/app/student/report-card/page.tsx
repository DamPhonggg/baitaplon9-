import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { StudentReportCardPage } from "@/components/student/ReportCardPage";

export default async function ReportCardPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "STUDENT") redirect("/");

  return <StudentReportCardPage user={user} />;
}

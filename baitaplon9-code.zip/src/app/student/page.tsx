import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { StudentEnrollPage } from "@/components/student/EnrollPage";

export default async function StudentPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "STUDENT") redirect("/");

  return <StudentEnrollPage user={user} />;
}

import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { ChangeSectionPage } from "@/components/student/ChangeSectionPage";

export default async function Page() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "STUDENT") redirect("/");
  return <ChangeSectionPage user={user} />;
}

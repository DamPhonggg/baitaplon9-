import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { StudentTuitionPage } from "@/components/student/TuitionPage";

export default async function Page() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "STUDENT") redirect("/");
  return <StudentTuitionPage user={user} />;
}

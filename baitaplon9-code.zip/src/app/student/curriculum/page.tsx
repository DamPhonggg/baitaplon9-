import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { StudentStudyPlanPage } from "@/components/student/StudyPlanPage";

export default async function StudentCurriculumPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "STUDENT") redirect("/");

  return <StudentStudyPlanPage user={user} />;
}

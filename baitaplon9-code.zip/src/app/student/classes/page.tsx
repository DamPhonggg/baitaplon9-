import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { StudentClassesPage } from "@/components/student/ClassesPage";

export default async function Page() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "STUDENT") redirect("/");
  return <StudentClassesPage user={user} />;
}

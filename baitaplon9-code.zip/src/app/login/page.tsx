"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import Link from "next/link";

const DEMO_ACCOUNTS = [
  { label: "Sinh viên", email: "sv1@university.edu" },
  { label: "Giảng viên", email: "gv1@university.edu" },
  { label: "Phòng Đào tạo", email: "giaovu@university.edu" },
  { label: "Phòng Tài chính", email: "taichinh@university.edu" },
];

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Đăng nhập thất bại");
        return;
      }

      const role = data.user.role;
      const paths: Record<string, string> = {
        STUDENT: "/student",
        PROFESSOR: "/professor/classes",
        REGISTRAR: "/registrar/sections",
        FINANCE: "/finance",
      };
      router.push(paths[role] || "/");
      router.refresh();
    } catch {
      setError("Không thể kết nối server");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-gradient-to-br from-amber-50 via-white to-primary-100">
      <div className="card w-full max-w-md p-8 shadow-md border-amber-200">
        <div className="text-center mb-6">
          <h1 className="text-2xl font-bold text-amber-950">Đăng nhập</h1>
          <p className="text-sm text-amber-700/70 mt-1">Hệ thống Đăng ký Tín chỉ</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="label">Email hoặc MSSV</label>
            <input
              type="text"
              className="input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="sv1@university.edu hoặc SV001"
              required
            />
          </div>
          <div>
            <label className="label">Mật khẩu</label>
            <input
              type="password"
              className="input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••"
              required
            />
          </div>

          {error && (
            <div className="text-sm text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
              {error}
            </div>
          )}

          <button type="submit" className="btn-primary w-full" disabled={loading}>
            {loading ? "Đang đăng nhập..." : "Đăng nhập"}
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-amber-200">
          <p className="text-xs text-amber-700/70 mb-3 text-center">Tài khoản demo (mật khẩu: 123456)</p>
          <div className="space-y-2">
            {DEMO_ACCOUNTS.map((acc) => (
              <button
                key={acc.email}
                type="button"
                className="w-full text-left text-sm px-3 py-2 rounded-lg hover:bg-amber-50 border border-amber-200"
                onClick={() => {
                  setEmail(acc.email);
                  setPassword("123456");
                }}
              >
                <span className="font-medium">{acc.label}:</span>{" "}
                <span className="text-slate-600">{acc.email}</span>
              </button>
            ))}
          </div>
        </div>

        <p className="text-center mt-4">
          <Link href="/" className="text-sm text-primary-600 hover:underline">
            ← Về trang chủ
          </Link>
        </p>
      </div>
    </div>
  );
}

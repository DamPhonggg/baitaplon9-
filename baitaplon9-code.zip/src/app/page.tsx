import Link from "next/link";
import { redirect } from "next/navigation";
import { getSessionUser, roleDashboard } from "@/lib/auth";

export default async function HomePage() {
  const user = await getSessionUser();
  if (user) redirect(roleDashboard(user.role));

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-amber-50 to-white">
      <header className="bg-white border-b border-amber-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold text-primary-700">Đăng ký Tín chỉ</h1>
          <Link href="/login" className="btn-primary">
            Đăng nhập
          </Link>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center px-4">
        <div className="max-w-2xl text-center">
          <h2 className="text-4xl font-bold text-amber-950 mb-4">
            Hệ thống Đăng ký Học phần
          </h2>
          <p className="text-lg text-amber-800/80 mb-8">
            Nền tảng quản lý đăng ký tín chỉ cho sinh viên, giảng viên và giáo vụ.
          </p>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 text-left mb-8">
            <div className="card p-5">
              <h3 className="font-semibold mb-1">Sinh viên</h3>
              <p className="text-sm text-slate-600">UC 1.3, 2.2, 2.3, 3.2, 4.2</p>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold mb-1">Giảng viên</h3>
              <p className="text-sm text-slate-600">UC 1.3, 3.1</p>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold mb-1">Phòng Đào tạo</h3>
              <p className="text-sm text-slate-600">UC 1.1, 1.2, 2.1, 3.3</p>
            </div>
            <div className="card p-5">
              <h3 className="font-semibold mb-1">Phòng Tài chính</h3>
              <p className="text-sm text-slate-600">UC 4.1</p>
            </div>
          </div>

          <Link href="/login" className="btn-primary mt-8 inline-flex text-base px-6 py-3">
            Bắt đầu →
          </Link>
        </div>
      </main>
    </div>
  );
}

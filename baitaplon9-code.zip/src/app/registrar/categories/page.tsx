import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { CategoriesPage } from "@/components/registrar/CategoriesPage";

export default async function Page() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "REGISTRAR") redirect("/");
  return <CategoriesPage user={user} />;
}

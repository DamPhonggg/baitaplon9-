import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { CurriculumPage } from "@/components/registrar/CurriculumPage";

export default async function RegistrarCurriculumPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "REGISTRAR") redirect("/");

  return <CurriculumPage user={user} />;
}

import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { PrerequisitesPage } from "@/components/registrar/PrerequisitesPage";

export default async function Page() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "REGISTRAR") redirect("/");
  return <PrerequisitesPage user={user} />;
}

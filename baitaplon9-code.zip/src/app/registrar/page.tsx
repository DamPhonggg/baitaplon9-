import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { UCHomePage } from "@/components/UCDashboard";

export default async function RegistrarPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "REGISTRAR") redirect("/");

  return <UCHomePage user={user} title="Phòng Đào tạo — Quản lý CTĐT" />;
}

import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { GraduationPage } from "@/components/registrar/GraduationPage";

export default async function Page() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "REGISTRAR") redirect("/");
  return <GraduationPage user={user} />;
}

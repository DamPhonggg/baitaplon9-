import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { OpenSectionsPage } from "@/components/registrar/OpenSectionsPage";

export default async function Page() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "REGISTRAR") redirect("/");
  return <OpenSectionsPage user={user} />;
}

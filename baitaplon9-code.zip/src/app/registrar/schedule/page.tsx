import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { SemesterSchedulePage } from "@/components/curriculum/SemesterSchedulePage";

export default async function RegistrarSchedulePage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "REGISTRAR") redirect("/");

  return <SemesterSchedulePage user={user} />;
}

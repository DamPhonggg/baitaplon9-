import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { RegistrarDashboard } from "@/components/registrar/Dashboard";

export default async function RegistrarUsersPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "REGISTRAR") redirect("/");

  return <RegistrarDashboard user={user} />;
}

import { NextRequest } from "next/server";
import { login, logout } from "@/lib/auth";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json();
    if (!email || !password) return jsonError("Email và mật khẩu là bắt buộc");

    const user = await login(email, password);
    if (!user) return jsonError("Email hoặc mật khẩu không đúng", 401);

    return jsonOk({ user });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE() {
  logout();
  return jsonOk({ message: "Đã đăng xuất" });
}

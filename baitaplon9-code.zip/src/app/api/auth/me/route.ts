import { getSessionUser } from "@/lib/auth";
import { handleApiError, jsonOk } from "@/lib/api-utils";

export async function GET() {
  try {
    const user = await getSessionUser();
    return jsonOk({ user });
  } catch (error) {
    return handleApiError(error);
  }
}

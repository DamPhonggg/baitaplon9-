import { NextRequest } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";
import { calculateCourseGrade, validateGradeComponent } from "@/lib/grades";

export async function GET(req: NextRequest) {
  try {
    const user = await requireRole(["PROFESSOR"]);
    const { searchParams } = new URL(req.url);
    const sectionId = searchParams.get("sectionId");
    if (!sectionId) return jsonError("Thiếu sectionId");

    const section = await prisma.courseSection.findFirst({
      where: { id: sectionId, professorId: user.id },
    });
    if (!section) return jsonError("Không có quyền truy cập lớp này", 403);

    const enrollments = await prisma.enrollment.findMany({
      where: { sectionId, status: { in: ["REGISTERED", "COMPLETED"] } },
      include: { student: { select: { id: true, name: true, studentCode: true, email: true } } },
      orderBy: { student: { studentCode: "asc" } },
    });

    return jsonOk({ enrollments });
  } catch (error) {
    return handleApiError(error);
  }
}

type GradeInput = {
  enrollmentId: string;
  cc1?: number | null;
  cc2?: number | null;
  gk?: number | null;
  ck?: number | null;
};

export async function PUT(req: NextRequest) {
  try {
    const user = await requireRole(["PROFESSOR"]);
    const { sectionId, grades } = await req.json() as {
      sectionId: string;
      grades: GradeInput[];
    };

    if (!sectionId || !grades?.length) return jsonError("Thiếu dữ liệu");

    const section = await prisma.courseSection.findFirst({
      where: { id: sectionId, professorId: user.id },
      include: { course: true },
    });
    if (!section) return jsonError("Không có quyền nhập điểm lớp này", 403);

    for (const g of grades) {
      const components = [
        { key: "cc1", value: g.cc1 },
        { key: "cc2", value: g.cc2 },
        { key: "gk", value: g.gk },
        { key: "ck", value: g.ck },
      ] as const;

      for (const { key, value } of components) {
        if (value != null && !validateGradeComponent(value)) {
          return jsonError(`Điểm ${key.toUpperCase()} phải từ 0 đến 10`);
        }
      }

      const finalGrade = calculateCourseGrade({
        cc1: g.cc1 ?? null,
        cc2: g.cc2 ?? null,
        gk: g.gk ?? null,
        ck: g.ck ?? null,
      });

      const enrollment = await prisma.enrollment.update({
        where: { id: g.enrollmentId },
        data: {
          gradeCC1: g.cc1 ?? null,
          gradeCC2: g.cc2 ?? null,
          gradeGK: g.gk ?? null,
          gradeCK: g.ck ?? null,
          grade: finalGrade,
          status: finalGrade != null ? "COMPLETED" : "REGISTERED",
        },
      });

      if (finalGrade != null) {
        await prisma.studentStudyPlan.updateMany({
          where: { studentId: enrollment.studentId, courseId: section.courseId },
          data: {
            status: "COMPLETED",
            actualSemester: section.semester,
          },
        });
      }
    }

    return jsonOk({ message: "Đã lưu điểm" });
  } catch (error) {
    return handleApiError(error);
  }
}

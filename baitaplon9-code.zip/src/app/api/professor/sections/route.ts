import { NextRequest } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import {
  DEFAULT_PLANNED_SEMESTER,
  SEMESTER_ORDER,
  getSemesterOptions,
  resolveRegistration,
} from "@/lib/enrollment-rules";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";

function parsePlannedSemester(req: NextRequest) {
  const planned = new URL(req.url).searchParams.get("planned") ?? DEFAULT_PLANNED_SEMESTER;
  if (!SEMESTER_ORDER.includes(planned)) return null;
  return planned;
}

export async function GET(req: NextRequest) {
  try {
    const user = await requireRole(["PROFESSOR"]);
    const plannedParam = parsePlannedSemester(req);
    if (!plannedParam) return jsonError("Học kỳ không hợp lệ", 400);

    const { plannedSemester, sectionSemester, label } = resolveRegistration(plannedParam);

    const available = await prisma.courseSection.findMany({
      where: { semester: sectionSemester, professorId: null, isOpen: true },
      include: { course: true },
      orderBy: { course: { code: "asc" } },
    });

    const teaching = await prisma.courseSection.findMany({
      where: { semester: sectionSemester, professorId: user.id },
      include: {
        course: true,
        professor: { select: { name: true } },
        enrollments: {
          where: { status: { in: ["REGISTERED", "COMPLETED"] } },
          include: {
            student: { select: { id: true, name: true, studentCode: true } },
          },
          orderBy: { student: { studentCode: "asc" } },
        },
        _count: { select: { enrollments: { where: { status: { in: ["REGISTERED", "COMPLETED"] } } } } },
      },
      orderBy: { course: { code: "asc" } },
    });

    return jsonOk({
      semester: sectionSemester,
      plannedSemester,
      label,
      semesterOptions: getSemesterOptions(),
      available,
      teaching,
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireRole(["PROFESSOR"]);
    const { sectionId, plannedSemester: plannedParam } = await req.json();
    if (!sectionId) return jsonError("Thiếu sectionId");

    const plannedSemester =
      plannedParam && SEMESTER_ORDER.includes(plannedParam) ? plannedParam : DEFAULT_PLANNED_SEMESTER;
    const registration = resolveRegistration(plannedSemester);

    const section = await prisma.courseSection.findUnique({ where: { id: sectionId } });
    if (!section) return jsonError("Lớp không tồn tại", 404);
    if (section.semester !== registration.sectionSemester) {
      return jsonError("Lớp không thuộc học kỳ đang chọn");
    }
    if (section.professorId) return jsonError("Lớp đã có giảng viên");

    const updated = await prisma.courseSection.update({
      where: { id: sectionId },
      data: { professorId: user.id },
      include: { course: true },
    });

    return jsonOk({ section: updated });
  } catch (error) {
    return handleApiError(error);
  }
}

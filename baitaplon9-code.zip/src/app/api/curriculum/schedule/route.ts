import { requireRole } from "@/lib/auth";
import {
  buildCategorySummary,
  buildSemesterPlan,
  CATEGORY_LABELS,
  MAX_CREDITS_PER_SEMESTER,
  MIN_CREDITS_PER_SEMESTER,
  SEMESTER_LABELS,
} from "@/lib/curriculum-plan";
import { prisma } from "@/lib/db";
import { handleApiError, jsonOk } from "@/lib/api-utils";

export async function GET() {
  try {
    await requireRole(["REGISTRAR", "STUDENT"]);

    const courses = await prisma.course.findMany({ orderBy: { orderIndex: "asc" } });

    const mapped = courses.map((c) => ({
      orderIndex: c.orderIndex,
      code: c.code,
      name: c.name,
      knowledgeBlock: c.knowledgeBlock,
      courseCategory: c.courseCategory as "THE_CHAT" | "KIEN_THUC" | "CHUYEN_NGANH",
      credits: c.credits,
      tuitionCredits: c.tuitionCredits,
      prerequisites: c.prerequisites ?? undefined,
      plannedSemester: c.plannedSemester ?? "Y1_HK1",
    }));

    const semesters = buildSemesterPlan(mapped);
    const categories = buildCategorySummary(mapped);

    return jsonOk({
      semesters,
      categories,
      categoryLabels: CATEGORY_LABELS,
      semesterLabels: SEMESTER_LABELS,
      rules: { min: MIN_CREDITS_PER_SEMESTER, max: MAX_CREDITS_PER_SEMESTER },
      allValid: semesters.every((s) => s.valid || s.courses.length === 0),
    });
  } catch (error) {
    return handleApiError(error);
  }
}

import { NextRequest } from "next/server";
import { requireRole, schedulesConflict } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { checkEnrollmentEligibility, getCompletedCourseNames } from "@/lib/enrollment-rules";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";

export async function POST(req: NextRequest) {
  try {
    const user = await requireRole(["STUDENT"]);
    const { enrollmentId, newSectionId } = await req.json();
    if (!enrollmentId || !newSectionId) return jsonError("Thiếu enrollmentId hoặc newSectionId");

    const current = await prisma.enrollment.findFirst({
      where: { id: enrollmentId, studentId: user.id, status: "REGISTERED" },
      include: { section: { include: { course: true } } },
    });
    if (!current) return jsonError("Không tìm thấy đăng ký hiện tại", 404);

    const newSection = await prisma.courseSection.findUnique({
      where: { id: newSectionId },
      include: {
        course: true,
        enrollments: { where: { status: "REGISTERED" } },
      },
    });
    if (!newSection) return jsonError("Lớp mới không tồn tại", 404);
    if (!newSection.isOpen) return jsonError("Lớp chưa mở đăng ký");
    if (newSection.courseId !== current.section.courseId) {
      return jsonError("Chỉ được đổi sang lớp cùng học phần");
    }
    if (newSection.id === current.sectionId) return jsonError("Đã ở lớp này");

    if (!newSection.course.plannedSemester) return jsonError("Học phần chưa có học kỳ dự kiến");

    const [plan, completedNames, myEnrollments] = await Promise.all([
      prisma.studentStudyPlan.findUnique({
        where: { studentId_courseId: { studentId: user.id, courseId: newSection.courseId } },
      }),
      getCompletedCourseNames(user.id),
      prisma.enrollment.findMany({
        where: {
          studentId: user.id,
          status: "REGISTERED",
          section: { semester: newSection.semester },
          id: { not: enrollmentId },
        },
        include: { section: { include: { course: true } } },
      }),
    ]);

    const currentCredits = myEnrollments.reduce((s, e) => s + e.section.course.credits, 0);

    const eligibility = checkEnrollmentEligibility({
      studyPlanStatus: plan?.status ?? null,
      registrationPlannedSemester: newSection.course.plannedSemester,
      coursePlannedSemester: newSection.course.plannedSemester,
      prerequisites: newSection.course.prerequisites,
      completedCourseNames: completedNames,
      currentCredits,
      courseCredits: newSection.course.credits,
      isAlreadyRegistered: false,
      isCompleted: plan?.status === "COMPLETED",
      capacityFull: newSection.enrollments.length >= newSection.capacity,
    });

    if (!eligibility.eligible) return jsonError(eligibility.reason ?? "Không đủ điều kiện");

    for (const e of myEnrollments) {
      if (schedulesConflict(e.section.schedule, newSection.schedule)) {
        return jsonError(`Trùng lịch với ${e.section.schedule}`);
      }
    }

    await prisma.enrollment.update({
      where: { id: enrollmentId },
      data: { status: "DROPPED" },
    });

    const enrollment = await prisma.enrollment.create({
      data: { studentId: user.id, sectionId: newSectionId, status: "REGISTERED" },
      include: { section: { include: { course: true } } },
    });

    return jsonOk({ enrollment, message: "Đổi lớp thành công" });
  } catch (error) {
    return handleApiError(error);
  }
}

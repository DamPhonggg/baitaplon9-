import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { handleApiError, jsonOk } from "@/lib/api-utils";

export async function GET() {
  try {
    const user = await requireRole(["STUDENT"]);

    const enrollments = await prisma.enrollment.findMany({
      where: {
        studentId: user.id,
        status: { in: ["COMPLETED", "REGISTERED"] },
        grade: { not: null },
      },
      include: {
        section: { include: { course: true, professor: { select: { name: true } } } },
      },
      orderBy: { section: { semester: "desc" } },
    });

    const completed = enrollments.filter((e) => e.grade !== null);
    const totalCredits = completed.reduce((sum, e) => sum + e.section.course.credits, 0);
    const gpa =
      completed.length > 0
        ? completed.reduce((sum, e) => sum + (e.grade ?? 0) * e.section.course.credits, 0) / totalCredits
        : 0;

    return jsonOk({ enrollments: completed, gpa: Math.round(gpa * 100) / 100, totalCredits });
  } catch (error) {
    return handleApiError(error);
  }
}

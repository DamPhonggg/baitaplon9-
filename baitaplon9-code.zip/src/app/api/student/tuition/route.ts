import { NextRequest } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";
import { buildTransferContent } from "@/lib/payment-config";
import {
  DEFAULT_PLANNED_SEMESTER,
  SEMESTER_ORDER,
  getSemesterOptions,
  resolveRegistration,
} from "@/lib/enrollment-rules";
import { syncTuitionInvoice, TUITION_RATE_PER_CREDIT } from "@/lib/tuition";

function parsePlannedSemester(req: NextRequest) {
  const planned = new URL(req.url).searchParams.get("planned") ?? DEFAULT_PLANNED_SEMESTER;
  if (!SEMESTER_ORDER.includes(planned)) return null;
  return planned;
}

export async function GET(req: NextRequest) {
  try {
    const user = await requireRole(["STUDENT"]);
    const plannedParam = parsePlannedSemester(req);
    if (!plannedParam) return jsonError("Học kỳ không hợp lệ", 400);

    const { plannedSemester, sectionSemester, label } = resolveRegistration(plannedParam);

    const invoice = await syncTuitionInvoice(user.id, sectionSemester);
    const invoiceWithPayments = await prisma.tuitionInvoice.findUnique({
      where: { id: invoice.id },
      include: { payments: { orderBy: { paidAt: "desc" } } },
    });

    const paidAgg = await prisma.tuitionPayment.aggregate({
      where: { invoice: { studentId: user.id } },
      _sum: { amount: true },
    });

    return jsonOk({
      plannedSemester,
      sectionSemester,
      label,
      semesterOptions: getSemesterOptions(),
      invoice: invoiceWithPayments,
      ratePerCredit: TUITION_RATE_PER_CREDIT,
      totalPaid: paidAgg._sum.amount ?? 0,
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireRole(["STUDENT"]);
    const { invoiceId, method, reference } = await req.json();
    if (!invoiceId || !method) return jsonError("Thiếu thông tin thanh toán");

    const invoice = await prisma.tuitionInvoice.findFirst({
      where: { id: invoiceId, studentId: user.id },
    });
    if (!invoice) return jsonError("Hóa đơn không tồn tại", 404);
    if (invoice.status === "PAID") return jsonError("Hóa đơn đã thanh toán");

    const payment = await prisma.tuitionPayment.create({
      data: {
        invoiceId,
        amount: invoice.totalAmount,
        method,
        reference: reference || buildTransferContent(user.studentCode, invoice.semester),
      },
    });

    await prisma.tuitionInvoice.update({
      where: { id: invoiceId },
      data: { status: "PAID" },
    });

    return jsonOk({ payment, message: "Thanh toán thành công" });
  } catch (error) {
    return handleApiError(error);
  }
}

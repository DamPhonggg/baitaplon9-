import { NextRequest } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import {
  DEFAULT_PLANNED_SEMESTER,
  SEMESTER_ORDER,
  getSemesterOptions,
  resolveRegistration,
} from "@/lib/enrollment-rules";
import { calculateCourseGrade } from "@/lib/grades";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";

function parsePlannedSemester(req: NextRequest) {
  const planned = new URL(req.url).searchParams.get("planned") ?? DEFAULT_PLANNED_SEMESTER;
  if (!SEMESTER_ORDER.includes(planned)) return null;
  return planned;
}

export async function GET(req: NextRequest) {
  try {
    const user = await requireRole(["STUDENT"]);
    const plannedParam = parsePlannedSemester(req);
    if (!plannedParam) return jsonError("Học kỳ không hợp lệ", 400);

    const { plannedSemester, sectionSemester, label } = resolveRegistration(plannedParam);

    const enrollments = await prisma.enrollment.findMany({
      where: {
        studentId: user.id,
        status: { in: ["REGISTERED", "COMPLETED"] },
        OR: [
          { section: { semester: sectionSemester } },
          {
            section: {
              course: {
                studyPlans: {
                  some: {
                    studentId: user.id,
                    actualSemester: sectionSemester,
                  },
                },
              },
            },
          },
        ],
      },
      include: {
        section: {
          include: {
            course: true,
            professor: { select: { name: true, email: true } },
          },
        },
      },
      orderBy: { section: { course: { code: "asc" } } },
    });

    const classes = enrollments.map((e) => ({
      enrollmentId: e.id,
      status: e.status,
      grade: e.grade,
      gradeCC1: e.gradeCC1,
      gradeCC2: e.gradeCC2,
      gradeGK: e.gradeGK,
      gradeCK: e.gradeCK,
      finalGrade:
        e.grade ??
        calculateCourseGrade({
          cc1: e.gradeCC1,
          cc2: e.gradeCC2,
          gk: e.gradeGK,
          ck: e.gradeCK,
        }),
      section: {
        id: e.section.id,
        semester: e.section.semester,
        schedule: e.section.schedule,
        room: e.section.room,
        isOpen: e.section.isOpen,
        course: e.section.course,
        professor: e.section.professor,
      },
    }));

    return jsonOk({
      semester: sectionSemester,
      plannedSemester,
      label,
      semesterOptions: getSemesterOptions(),
      classes,
      totalCredits: classes.reduce((s, c) => s + c.section.course.credits, 0),
    });
  } catch (error) {
    return handleApiError(error);
  }
}

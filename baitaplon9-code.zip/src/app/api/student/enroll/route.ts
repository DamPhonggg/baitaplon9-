import { NextRequest } from "next/server";
import { requireRole, schedulesConflict } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";
import {
  CATEGORY_LABELS,
  DEFAULT_PLANNED_SEMESTER,
  MAX_CREDITS_PER_SEMESTER,
  MIN_CREDITS_PER_SEMESTER,
  SEMESTER_ORDER,
  checkEnrollmentEligibility,
  checkPrerequisites,
  getCompletedCourseNames,
  getSemesterOptions,
  resolveRegistration,
} from "@/lib/enrollment-rules";
import { syncTuitionInvoice, TUITION_RATE_PER_CREDIT, calculateTuition } from "@/lib/tuition";

function parsePlannedSemester(req: NextRequest) {
  const planned = new URL(req.url).searchParams.get("planned") ?? DEFAULT_PLANNED_SEMESTER;
  if (!SEMESTER_ORDER.includes(planned)) return null;
  return planned;
}

export async function GET(req: NextRequest) {
  try {
    const user = await requireRole(["STUDENT"]);
    const plannedParam = parsePlannedSemester(req);
    if (!plannedParam) return jsonError("Học kỳ không hợp lệ", 400);

    const { plannedSemester, sectionSemester, label } = resolveRegistration(plannedParam);

    const [sections, myEnrollments, studyPlans, completedNames] = await Promise.all([
      prisma.courseSection.findMany({
        where: {
          semester: sectionSemester,
          course: { plannedSemester },
          isOpen: true,
        },
        include: {
          course: true,
          professor: { select: { name: true } },
          _count: { select: { enrollments: { where: { status: "REGISTERED" } } } },
        },
        orderBy: [{ course: { courseCategory: "asc" } }, { course: { orderIndex: "asc" } }],
      }),
      prisma.enrollment.findMany({
        where: { studentId: user.id, status: "REGISTERED", section: { semester: sectionSemester } },
        include: { section: { include: { course: true } } },
      }),
      prisma.studentStudyPlan.findMany({
        where: { studentId: user.id },
        include: { course: true },
      }),
      getCompletedCourseNames(user.id),
    ]);

    const planByCourseId = new Map(studyPlans.map((p) => [p.courseId, p]));
    const enrolledSectionIds = new Set(myEnrollments.map((e) => e.sectionId));
    const enrolledCourseIds = new Set(myEnrollments.map((e) => e.section.courseId));
    const totalCredits = myEnrollments.reduce((sum, e) => sum + e.section.course.credits, 0);
    const totalTuitionCredits = myEnrollments.reduce((sum, e) => sum + e.section.course.tuitionCredits, 0);

    const invoice = await syncTuitionInvoice(user.id, sectionSemester);

    const data = sections.map((s) => {
      const plan = planByCourseId.get(s.courseId);
      const enrolledCount = s._count.enrollments;
      const isEnrolled = enrolledSectionIds.has(s.id);
      const sameCourseEnrolled = enrolledCourseIds.has(s.courseId);

      const eligibility = checkEnrollmentEligibility({
        studyPlanStatus: plan?.status ?? null,
        registrationPlannedSemester: plannedSemester,
        coursePlannedSemester: s.course.plannedSemester,
        prerequisites: s.course.prerequisites,
        completedCourseNames: completedNames,
        currentCredits: totalCredits,
        courseCredits: s.course.credits,
        isAlreadyRegistered: isEnrolled || sameCourseEnrolled,
        isCompleted: plan?.status === "COMPLETED",
        capacityFull: enrolledCount >= s.capacity,
      });

      return {
        id: s.id,
        schedule: s.schedule,
        room: s.room,
        capacity: s.capacity,
        enrolledCount,
        isEnrolled,
        sameCourseEnrolled,
        course: {
          id: s.course.id,
          code: s.course.code,
          name: s.course.name,
          credits: s.course.credits,
          tuitionCredits: s.course.tuitionCredits,
          courseCategory: s.course.courseCategory,
          knowledgeBlock: s.course.knowledgeBlock,
          plannedSemester: s.course.plannedSemester,
          prerequisites: s.course.prerequisites,
        },
        professor: s.professor,
        eligible: eligibility.eligible,
        ineligibleReason: eligibility.reason,
        categoryLabel: CATEGORY_LABELS[s.course.courseCategory as keyof typeof CATEGORY_LABELS] ?? s.course.courseCategory,
      };
    });

    const curriculumCourses = studyPlans
      .filter((p) => p.course.plannedSemester === plannedSemester)
      .map((p) => ({
        code: p.course.code,
        name: p.course.name,
        credits: p.course.credits,
        status: p.status,
        prerequisites: p.course.prerequisites,
        prereqMet: checkPrerequisites(p.course.prerequisites, completedNames).eligible,
      }));

    return jsonOk({
      sections: data,
      myEnrollments,
      totalCredits,
      totalTuitionCredits,
      tuition: {
        ratePerCredit: TUITION_RATE_PER_CREDIT,
        totalAmount: calculateTuition(totalTuitionCredits),
        invoiceId: invoice.id,
        status: invoice.status,
      },
      registration: {
        plannedSemester,
        sectionSemester,
        label,
        minCredits: MIN_CREDITS_PER_SEMESTER,
        maxCredits: MAX_CREDITS_PER_SEMESTER,
        creditsOk: totalCredits >= MIN_CREDITS_PER_SEMESTER && totalCredits <= MAX_CREDITS_PER_SEMESTER,
      },
      curriculumCourses,
      semesterOptions: getSemesterOptions(),
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await requireRole(["STUDENT"]);
    const { sectionId, plannedSemester: plannedParam } = await req.json();
    if (!sectionId) return jsonError("Thiếu sectionId");

    const plannedSemester =
      plannedParam && SEMESTER_ORDER.includes(plannedParam) ? plannedParam : DEFAULT_PLANNED_SEMESTER;
    const registration = resolveRegistration(plannedSemester);

    const section = await prisma.courseSection.findUnique({
      where: { id: sectionId },
      include: { course: true, enrollments: { where: { status: "REGISTERED" } } },
    });
    if (!section) return jsonError("Lớp học phần không tồn tại", 404);

    if (section.semester !== registration.sectionSemester) {
      return jsonError("Lớp không thuộc học kỳ đang chọn");
    }
    if (section.course.plannedSemester !== registration.plannedSemester) {
      return jsonError("Môn không thuộc học kỳ dự kiến đang chọn");
    }

    const [plan, completedNames, myEnrollments] = await Promise.all([
      prisma.studentStudyPlan.findUnique({
        where: { studentId_courseId: { studentId: user.id, courseId: section.courseId } },
      }),
      getCompletedCourseNames(user.id),
      prisma.enrollment.findMany({
        where: { studentId: user.id, status: "REGISTERED", section: { semester: section.semester } },
        include: { section: { include: { course: true } } },
      }),
    ]);

    const currentCredits = myEnrollments.reduce((sum, e) => sum + e.section.course.credits, 0);

    const existing = await prisma.enrollment.findUnique({
      where: { studentId_sectionId: { studentId: user.id, sectionId } },
    });

    const eligibility = checkEnrollmentEligibility({
      studyPlanStatus: plan?.status ?? null,
      registrationPlannedSemester: registration.plannedSemester,
      coursePlannedSemester: section.course.plannedSemester,
      prerequisites: section.course.prerequisites,
      completedCourseNames: completedNames,
      currentCredits,
      courseCredits: section.course.credits,
      isAlreadyRegistered: existing?.status === "REGISTERED",
      isCompleted: plan?.status === "COMPLETED",
      capacityFull: section.enrollments.length >= section.capacity,
    });

    if (!eligibility.eligible) return jsonError(eligibility.reason ?? "Không đủ điều kiện đăng ký");

    for (const e of myEnrollments) {
      if (schedulesConflict(e.section.schedule, section.schedule)) {
        return jsonError(`Trùng lịch với ${e.section.schedule}`);
      }
    }

    const enrollment = await prisma.enrollment.upsert({
      where: { studentId_sectionId: { studentId: user.id, sectionId } },
      create: { studentId: user.id, sectionId, status: "REGISTERED" },
      update: { status: "REGISTERED", grade: null, gradeCC1: null, gradeCC2: null, gradeGK: null, gradeCK: null },
      include: { section: { include: { course: true } } },
    });

    if (plan && plan.status === "PLANNED") {
      await prisma.studentStudyPlan.update({
        where: { id: plan.id },
        data: { status: "IN_PROGRESS" },
      });
    }

    await syncTuitionInvoice(user.id, section.semester);

    return jsonOk({ enrollment }, 201);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const user = await requireRole(["STUDENT"]);
    const { searchParams } = new URL(req.url);
    const enrollmentId = searchParams.get("id");
    if (!enrollmentId) return jsonError("Thiếu id");

    const enrollment = await prisma.enrollment.findFirst({
      where: { id: enrollmentId, studentId: user.id, status: "REGISTERED" },
      include: { section: true },
    });
    if (!enrollment) return jsonError("Không tìm thấy đăng ký", 404);

    await prisma.enrollment.update({
      where: { id: enrollmentId },
      data: { status: "DROPPED" },
    });

    const otherActive = await prisma.enrollment.findFirst({
      where: {
        studentId: user.id,
        status: "REGISTERED",
        section: { courseId: enrollment.section.courseId },
      },
    });

    if (!otherActive) {
      await prisma.studentStudyPlan.updateMany({
        where: {
          studentId: user.id,
          courseId: enrollment.section.courseId,
          status: "IN_PROGRESS",
        },
        data: { status: "PLANNED" },
      });
    }

    await syncTuitionInvoice(user.id, enrollment.section.semester);

    return jsonOk({ message: "Đã hủy đăng ký" });
  } catch (error) {
    return handleApiError(error);
  }
}

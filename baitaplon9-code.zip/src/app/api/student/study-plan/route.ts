import { NextRequest } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";

export async function GET(req: NextRequest) {
  try {
    const user = await requireRole(["REGISTRAR", "STUDENT"]);
    const { searchParams } = new URL(req.url);
    const studentId = searchParams.get("studentId");
    const block = searchParams.get("block");

    const targetId = user.role === "STUDENT" ? user.id : studentId;
    if (!targetId) return jsonError("Thiếu studentId");

    const plans = await prisma.studentStudyPlan.findMany({
      where: {
        studentId: targetId,
        ...(block ? { course: { knowledgeBlock: block } } : {}),
      },
      include: { course: true },
      orderBy: { course: { orderIndex: "asc" } },
    });

    const completed = plans.filter((p) => p.status === "COMPLETED").length;
    const completedCredits = plans
      .filter((p) => p.status === "COMPLETED")
      .reduce((s, p) => s + p.course.credits, 0);

    return jsonOk({
      plans: plans.map((p) => ({
        id: p.id,
        courseId: p.courseId,
        actualSemester: p.actualSemester,
        status: p.status,
        course: p.course,
      })),
      stats: { total: plans.length, completed, completedCredits },
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(req: NextRequest) {
  try {
    const user = await requireRole(["REGISTRAR", "STUDENT"]);
    const { planId, actualSemester, status } = await req.json();
    if (!planId) return jsonError("Thiếu planId");

    const plan = await prisma.studentStudyPlan.findUnique({ where: { id: planId } });
    if (!plan) return jsonError("Không tìm thấy", 404);
    if (user.role === "STUDENT" && plan.studentId !== user.id) {
      return jsonError("Không có quyền", 403);
    }

    const updated = await prisma.studentStudyPlan.update({
      where: { id: planId },
      data: {
        ...(actualSemester !== undefined && { actualSemester: actualSemester || null }),
        ...(status && { status }),
      },
      include: { course: true },
    });

    return jsonOk({ plan: updated });
  } catch (error) {
    return handleApiError(error);
  }
}

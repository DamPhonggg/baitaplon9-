import { NextRequest } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";

export async function GET() {
  try {
    await requireRole(["REGISTRAR"]);
    const categories = await prisma.knowledgeCategory.findMany({ orderBy: { code: "asc" } });
    const courseCounts = await prisma.course.groupBy({
      by: ["knowledgeBlock"],
      _count: { id: true },
    });
    const countMap = Object.fromEntries(courseCounts.map((c) => [c.knowledgeBlock, c._count.id]));
    return jsonOk({
      categories: categories.map((c) => ({ ...c, courseCount: countMap[c.code] ?? 0 })),
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { code, name, description, groupType, minCredits } = await req.json();
    if (!code || !name || !groupType) return jsonError("Thiếu thông tin bắt buộc");
    const category = await prisma.knowledgeCategory.create({
      data: { code, name, description, groupType, minCredits: Number(minCredits) || 0 },
    });
    return jsonOk({ category }, 201);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { id, code, name, description, groupType, minCredits } = await req.json();
    if (!id) return jsonError("Thiếu id");
    const category = await prisma.knowledgeCategory.update({
      where: { id },
      data: {
        ...(code && { code }),
        ...(name && { name }),
        ...(description !== undefined && { description }),
        ...(groupType && { groupType }),
        ...(minCredits !== undefined && { minCredits: Number(minCredits) }),
      },
    });
    return jsonOk({ category });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const id = new URL(req.url).searchParams.get("id");
    if (!id) return jsonError("Thiếu id");
    await prisma.knowledgeCategory.delete({ where: { id } });
    return jsonOk({ message: "Đã xóa" });
  } catch (error) {
    return handleApiError(error);
  }
}

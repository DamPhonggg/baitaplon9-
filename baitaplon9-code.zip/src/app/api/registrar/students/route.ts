import { NextRequest } from "next/server";
import bcrypt from "bcryptjs";
import { Prisma } from "@prisma/client";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";

async function initStudentStudyPlan(studentId: string) {
  const courses = await prisma.course.findMany({ select: { id: true } });
  for (const course of courses) {
    await prisma.studentStudyPlan.upsert({
      where: { studentId_courseId: { studentId, courseId: course.id } },
      create: { studentId, courseId: course.id, status: "PLANNED" },
      update: {},
    });
  }
}

export async function GET() {
  try {
    await requireRole(["REGISTRAR"]);
    const students = await prisma.user.findMany({
      where: { role: "STUDENT" },
      select: { id: true, email: true, name: true, studentCode: true, department: true, createdAt: true },
      orderBy: { studentCode: "asc" },
    });
    return jsonOk({ students });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { email, password, name, studentCode, department } = await req.json();
    const normalizedEmail = String(email || "").trim().toLowerCase();
    const normalizedCode = String(studentCode || "").trim().toUpperCase();

    if (!normalizedEmail || !password || !name || !normalizedCode) {
      return jsonError("Thiếu thông tin bắt buộc");
    }

    const passwordHash = await bcrypt.hash(String(password), 10);
    const student = await prisma.user.create({
      data: {
        email: normalizedEmail,
        passwordHash,
        name: String(name).trim(),
        studentCode: normalizedCode,
        department: department ? String(department).trim() : null,
        role: "STUDENT",
      },
    });

    await initStudentStudyPlan(student.id);

    return jsonOk({
      student: {
        id: student.id,
        email: normalizedEmail,
        name: student.name,
        studentCode: normalizedCode,
        department: student.department,
      },
    }, 201);
  } catch (error) {
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
      return jsonError("Email hoặc MSSV đã tồn tại");
    }
    return handleApiError(error);
  }
}

export async function PUT(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { id, email, name, studentCode, department, password } = await req.json();
    if (!id) return jsonError("Thiếu id");

    const data: Record<string, string> = {};
    if (email) data.email = email;
    if (name) data.name = name;
    if (studentCode) data.studentCode = studentCode;
    if (department) data.department = department;
    if (password) data.passwordHash = await bcrypt.hash(password, 10);

    const student = await prisma.user.update({ where: { id }, data });
    return jsonOk({ student: { id: student.id, email: student.email, name: student.name } });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return jsonError("Thiếu id");

    await prisma.user.delete({ where: { id } });
    return jsonOk({ message: "Đã xóa sinh viên" });
  } catch (error) {
    return handleApiError(error);
  }
}

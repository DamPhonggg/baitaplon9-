import { NextRequest } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";

export async function GET(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { searchParams } = new URL(req.url);
    const block = searchParams.get("block");

    const courses = await prisma.course.findMany({
      where: block ? { knowledgeBlock: block } : undefined,
      orderBy: { orderIndex: "asc" },
    });

    const stats = {
      total: courses.length,
      totalCredits: courses.reduce((s, c) => s + c.credits, 0),
      totalTuitionCredits: courses.reduce((s, c) => s + c.tuitionCredits, 0),
      blocks: Array.from(new Set(courses.map((c) => c.knowledgeBlock))).sort(),
    };

    return jsonOk({ courses, stats });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const body = await req.json();
    const { code, name, credits, tuitionCredits, knowledgeBlock, expectedSemester, prerequisites, orderIndex } = body;

    if (!code || !name || credits === undefined) return jsonError("Thiếu thông tin bắt buộc");

    const maxOrder = await prisma.course.aggregate({ _max: { orderIndex: true } });
    const course = await prisma.course.create({
      data: {
        code,
        name,
        credits: Number(credits),
        tuitionCredits: Number(tuitionCredits) || Number(credits),
        knowledgeBlock: knowledgeBlock || "A1",
        expectedSemester: expectedSemester || null,
        prerequisites: prerequisites || null,
        orderIndex: orderIndex ? Number(orderIndex) : (maxOrder._max.orderIndex ?? 0) + 1,
        department: "CNTT",
      },
    });

    // Tạo kế hoạch học tập cho tất cả sinh viên
    const students = await prisma.user.findMany({ where: { role: "STUDENT" } });
    for (const s of students) {
      await prisma.studentStudyPlan.create({
        data: { studentId: s.id, courseId: course.id },
      });
    }

    return jsonOk({ course }, 201);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { id, ...fields } = await req.json();
    if (!id) return jsonError("Thiếu id");

    const data: Record<string, unknown> = {};
    if (fields.code) data.code = fields.code;
    if (fields.name) data.name = fields.name;
    if (fields.credits !== undefined) data.credits = Number(fields.credits);
    if (fields.tuitionCredits !== undefined) data.tuitionCredits = Number(fields.tuitionCredits);
    if (fields.knowledgeBlock) data.knowledgeBlock = fields.knowledgeBlock;
    if (fields.expectedSemester !== undefined) data.expectedSemester = fields.expectedSemester || null;
    if (fields.prerequisites !== undefined) data.prerequisites = fields.prerequisites || null;
    if (fields.orderIndex !== undefined) data.orderIndex = Number(fields.orderIndex);

    const course = await prisma.course.update({ where: { id }, data });
    return jsonOk({ course });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return jsonError("Thiếu id");

    await prisma.course.delete({ where: { id } });
    return jsonOk({ message: "Đã xóa học phần" });
  } catch (error) {
    return handleApiError(error);
  }
}

import { requireRole } from "@/lib/auth";
import { handleApiError, jsonOk } from "@/lib/api-utils";
import { syncCurriculumFromSource } from "@/lib/sync-curriculum";

export async function POST() {
  try {
    await requireRole(["REGISTRAR"]);
    const result = await syncCurriculumFromSource();
    return jsonOk({
      message: `Đã đồng bộ ${result.total} học phần (${result.created} mới, ${result.updated} cập nhật)`,
      ...result,
    });
  } catch (error) {
    return handleApiError(error);
  }
}

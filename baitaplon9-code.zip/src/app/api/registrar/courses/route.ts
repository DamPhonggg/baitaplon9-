import { NextRequest } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";
import { CURRENT_REGISTRATION } from "@/lib/enrollment-rules";

export async function GET() {
  try {
    await requireRole(["REGISTRAR"]);
    const courses = await prisma.course.findMany({
      include: {
        sections: {
          include: { professor: { select: { name: true } } },
        },
      },
      orderBy: { code: "asc" },
    });
    return jsonOk({ courses });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const body = await req.json();
    const { code, name, credits, department, description, section } = body;

    if (!code || !name || !credits || !department) return jsonError("Thiếu thông tin học phần");

    const course = await prisma.course.create({
      data: { code, name, credits: Number(credits), department, description },
    });

    if (section) {
      await prisma.courseSection.create({
        data: {
          courseId: course.id,
          semester: section.semester || CURRENT_REGISTRATION.sectionSemester,
          capacity: Number(section.capacity) || 40,
          schedule: section.schedule,
          room: section.room,
        },
      });
    }

    return jsonOk({ course }, 201);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { id, code, name, credits, department, description } = await req.json();
    if (!id) return jsonError("Thiếu id");

    const course = await prisma.course.update({
      where: { id },
      data: {
        ...(code && { code }),
        ...(name && { name }),
        ...(credits && { credits: Number(credits) }),
        ...(department && { department }),
        ...(description !== undefined && { description }),
      },
    });
    return jsonOk({ course });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return jsonError("Thiếu id");

    await prisma.course.delete({ where: { id } });
    return jsonOk({ message: "Đã xóa học phần" });
  } catch (error) {
    return handleApiError(error);
  }
}

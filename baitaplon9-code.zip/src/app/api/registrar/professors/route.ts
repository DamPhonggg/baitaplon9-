import { NextRequest } from "next/server";
import bcrypt from "bcryptjs";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";

export async function GET() {
  try {
    await requireRole(["REGISTRAR"]);
    const professors = await prisma.user.findMany({
      where: { role: "PROFESSOR" },
      select: { id: true, email: true, name: true, department: true, createdAt: true },
      orderBy: { name: "asc" },
    });
    return jsonOk({ professors });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { email, password, name, department } = await req.json();
    if (!email || !password || !name) return jsonError("Thiếu thông tin bắt buộc");

    const passwordHash = await bcrypt.hash(password, 10);
    const professor = await prisma.user.create({
      data: { email, passwordHash, name, department, role: "PROFESSOR" },
    });
    return jsonOk({ professor: { id: professor.id, email, name, department } }, 201);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { id, email, name, department, password } = await req.json();
    if (!id) return jsonError("Thiếu id");

    const data: Record<string, string> = {};
    if (email) data.email = email;
    if (name) data.name = name;
    if (department) data.department = department;
    if (password) data.passwordHash = await bcrypt.hash(password, 10);

    const professor = await prisma.user.update({ where: { id }, data });
    return jsonOk({ professor: { id: professor.id, email: professor.email, name: professor.name } });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function DELETE(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return jsonError("Thiếu id");

    await prisma.user.delete({ where: { id } });
    return jsonOk({ message: "Đã xóa giảng viên" });
  } catch (error) {
    return handleApiError(error);
  }
}

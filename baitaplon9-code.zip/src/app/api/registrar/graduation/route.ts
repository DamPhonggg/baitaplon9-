import { NextRequest } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import {
  GRADUATION_MIN_CREDITS,
  GRADUATION_MIN_GPA,
  GraduationCheck,
  computeGpa,
} from "@/lib/graduation";
import { handleApiError, jsonOk } from "@/lib/api-utils";

async function checkStudent(studentId: string): Promise<GraduationCheck> {
  const student = await prisma.user.findUnique({ where: { id: studentId } });
  if (!student) throw new Error("Sinh viên không tồn tại");

  const plans = await prisma.studentStudyPlan.findMany({
    where: { studentId },
    include: { course: true },
  });

  const completed = plans.filter((p) => p.status === "COMPLETED");
  const missing = plans
    .filter((p) => p.status !== "COMPLETED")
    .map((p) => ({ code: p.course.code, name: p.course.name }));

  const gradeRecords = await prisma.enrollment.findMany({
    where: { studentId, status: "COMPLETED", grade: { not: null } },
    include: { section: { include: { course: true } } },
  });

  const gpaRecords = gradeRecords.map((e) => ({
    grade: e.grade!,
    credits: e.section.course.credits,
  }));

  const totalCredits = completed.reduce((s, p) => s + p.course.credits, 0);
  const gpa = computeGpa(gpaRecords);

  return {
    studentId,
    studentName: student.name,
    studentCode: student.studentCode,
    totalCredits,
    requiredCredits: GRADUATION_MIN_CREDITS,
    creditsMet: totalCredits >= GRADUATION_MIN_CREDITS,
    gpa,
    minGpa: GRADUATION_MIN_GPA,
    gpaMet: gpa >= GRADUATION_MIN_GPA,
    completedCourses: completed.length,
    totalCourses: plans.length,
    coursesMet: missing.length === 0,
    eligible: totalCredits >= GRADUATION_MIN_CREDITS && gpa >= GRADUATION_MIN_GPA && missing.length === 0,
    missingCourses: missing.slice(0, 10),
  };
}

export async function GET(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const studentId = new URL(req.url).searchParams.get("studentId");

    if (studentId) {
      return jsonOk({ check: await checkStudent(studentId) });
    }

    const students = await prisma.user.findMany({
      where: { role: "STUDENT" },
      select: { id: true, name: true, studentCode: true },
      orderBy: { studentCode: "asc" },
    });

    const checks = await Promise.all(students.map((s) => checkStudent(s.id)));
    return jsonOk({ checks, rules: { minCredits: GRADUATION_MIN_CREDITS, minGpa: GRADUATION_MIN_GPA } });
  } catch (error) {
    return handleApiError(error);
  }
}

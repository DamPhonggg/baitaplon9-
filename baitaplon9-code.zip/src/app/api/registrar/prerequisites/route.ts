import { NextRequest } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";

export async function GET() {
  try {
    await requireRole(["REGISTRAR"]);
    const courses = await prisma.course.findMany({
      orderBy: { orderIndex: "asc" },
      select: {
        id: true, code: true, name: true, knowledgeBlock: true,
        prerequisites: true, plannedSemester: true, credits: true,
      },
    });
    return jsonOk({ courses });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { courseId, prerequisites } = await req.json();
    if (!courseId) return jsonError("Thiếu courseId");
    const course = await prisma.course.update({
      where: { id: courseId },
      data: { prerequisites: prerequisites || null },
    });
    return jsonOk({ course });
  } catch (error) {
    return handleApiError(error);
  }
}

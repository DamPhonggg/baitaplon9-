import { NextRequest } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { plannedToExpected } from "@/lib/curriculum-plan";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";

export async function GET(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { searchParams } = new URL(req.url);
    const planned = searchParams.get("planned") || "Y3_HK1";
    const semester = searchParams.get("semester") || plannedToExpected(planned);

    const sections = await prisma.courseSection.findMany({
      where: { semester },
      include: {
        course: { select: { code: true, name: true, plannedSemester: true, credits: true } },
        professor: { select: { id: true, name: true } },
        _count: { select: { enrollments: { where: { status: { in: ["REGISTERED", "COMPLETED"] } } } } },
      },
      orderBy: [{ course: { orderIndex: "asc" } }, { schedule: "asc" }],
    });

    const allCourses = await prisma.course.findMany({
      select: { id: true, code: true, name: true, credits: true, plannedSemester: true },
      orderBy: { orderIndex: "asc" },
    });

    const plannedCourses = allCourses.filter((c) => c.plannedSemester === planned);
    const openedCourseIds = new Set(sections.map((s) => s.courseId));

    return jsonOk({
      plannedSemester: planned,
      sectionSemester: semester,
      sections,
      allCourses,
      plannedCourses,
      notYetOpened: plannedCourses.filter((c) => !openedCourseIds.has(c.id)),
    });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { courseId, courseCode, semester, schedule, room, capacity, professorId, isOpen } = await req.json();
    if (!semester || !schedule) return jsonError("Thiếu học kỳ hoặc lịch học");

    let course = courseId
      ? await prisma.course.findUnique({ where: { id: courseId } })
      : courseCode
        ? await prisma.course.findUnique({ where: { code: courseCode } })
        : null;

    if (!course) return jsonError("Học phần không tồn tại", 404);

    const existing = await prisma.courseSection.findFirst({
      where: { courseId: course.id, semester },
    });
    if (existing) return jsonError("Đã có lớp cho học phần này trong kỳ");

    const section = await prisma.courseSection.create({
      data: {
        courseId: course.id,
        semester,
        schedule,
        room: room || null,
        capacity: Number(capacity) || 40,
        professorId: professorId || null,
        isOpen: isOpen !== false,
      },
      include: { course: true, professor: { select: { id: true, name: true } } },
    });

    return jsonOk({ section }, 201);
  } catch (error) {
    return handleApiError(error);
  }
}

export async function PUT(req: NextRequest) {
  try {
    await requireRole(["REGISTRAR"]);
    const { sectionId, isOpen, capacity, professorId, schedule, room } = await req.json();
    if (!sectionId) return jsonError("Thiếu sectionId");

    const section = await prisma.courseSection.update({
      where: { id: sectionId },
      data: {
        ...(isOpen !== undefined && { isOpen }),
        ...(capacity !== undefined && { capacity: Number(capacity) }),
        ...(professorId !== undefined && { professorId: professorId || null }),
        ...(schedule && { schedule }),
        ...(room !== undefined && { room }),
      },
      include: { course: true },
    });

    return jsonOk({ section });
  } catch (error) {
    return handleApiError(error);
  }
}

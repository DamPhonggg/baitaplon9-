import { NextRequest } from "next/server";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { syncTuitionInvoice, TUITION_RATE_PER_CREDIT } from "@/lib/tuition";
import { CURRENT_REGISTRATION } from "@/lib/enrollment-rules";
import { handleApiError, jsonError, jsonOk } from "@/lib/api-utils";

export async function GET(req: NextRequest) {
  try {
    await requireRole(["FINANCE", "REGISTRAR"]);
    const semester = new URL(req.url).searchParams.get("semester") || CURRENT_REGISTRATION.sectionSemester;

    const invoices = await prisma.tuitionInvoice.findMany({
      where: { semester },
      include: {
        student: { select: { name: true, studentCode: true, email: true } },
        payments: true,
      },
      orderBy: { student: { studentCode: "asc" } },
    });

    return jsonOk({ invoices, semester, ratePerCredit: TUITION_RATE_PER_CREDIT });
  } catch (error) {
    return handleApiError(error);
  }
}

export async function POST(req: NextRequest) {
  try {
    await requireRole(["FINANCE"]);
    const { semester, studentId } = await req.json();
    const targetSemester = semester || CURRENT_REGISTRATION.sectionSemester;

    if (studentId) {
      const invoice = await syncTuitionInvoice(studentId, targetSemester);
      const withStudent = await prisma.tuitionInvoice.findUnique({
        where: { id: invoice.id },
        include: { student: { select: { name: true, studentCode: true } } },
      });
      return jsonOk({ invoice: withStudent });
    }

    const students = await prisma.user.findMany({ where: { role: "STUDENT" } });
    const results = [];
    for (const s of students) {
      const invoice = await syncTuitionInvoice(s.id, targetSemester);
      const withStudent = await prisma.tuitionInvoice.findUnique({
        where: { id: invoice.id },
        include: { student: { select: { name: true, studentCode: true } } },
      });
      if (withStudent) results.push(withStudent);
    }
    return jsonOk({ invoices: results, count: results.length });
  } catch (error) {
    return handleApiError(error);
  }
}

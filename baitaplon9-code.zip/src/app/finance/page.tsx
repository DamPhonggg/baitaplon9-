import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { FinanceTuitionPage } from "@/components/finance/TuitionPage";

export default async function FinancePage() {
  const user = await getSessionUser();
  if (!user) redirect("/login");
  if (user.role !== "FINANCE") redirect("/");
  return <FinanceTuitionPage user={user} />;
}

"use client";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="card p-8 max-w-md text-center">
        <h2 className="text-xl font-bold text-red-600 mb-2">Đã xảy ra lỗi</h2>
        <p className="text-sm text-slate-600 mb-4">{error.message || "Lỗi không xác định"}</p>
        <button onClick={reset} className="btn-primary">
          Thử lại
        </button>
      </div>
    </div>
  );
}
